// config/multerS3.js
const multer = require("multer");
const multerS3 = require("multer-s3");
const s3 = require("./s3");

// for csv - product
const path = require("path");
const fs = require("fs");


// Path to the uploads directory
const uploadsDir = path.join(__dirname, "../uploads");

// Check if the 'uploads' directory exists, if not, create it
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true }); // Create the directory recursively
}
// storageCsv configuration: Make sure the 'uploads' folder exists
// Disk storage configuration for Multer
const storageCsv = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadsDir); // Save file to 'uploads' directory
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname)); // Add timestamp to avoid file name conflicts
  },
});


// const upload = multer({
//   storage: multerS3({
//     s3: s3,
//     bucket: process.env.AWS_BUCKET_NAME,
//     // acl: "public-read",
//     metadata: function(req, file, cb) {
//       cb(null, { fieldName: file.fieldname });
//     },
//     key: function(req, file, cb) {
//       cb(null, Date.now().toString() + "-" + file.originalname);
//     },
//   }),
// });


const upload = multer({
  storage: multerS3({
    s3: s3,
    bucket: process.env.AWS_BUCKET_NAME,
    // Uncomment if you want files to be publicly accessible
    // acl: "public-read",
    metadata: function(req, file, cb) {
      // Set metadata including the file's field name
      cb(null, {
        fieldName: file.fieldname,
        ContentType: file.mimetype, // Set ContentType based on the file's mimetype
      });
    },
    key: function(req, file, cb) {
      // Generate a unique file key
      cb(null, Date.now().toString() + "-" + file.originalname);
    },
    contentType: multerS3.AUTO_CONTENT_TYPE, // Automatically detect the content type
  }),
});

const uploadCsvPro = multer({ storage: storageCsv });
module.exports = { upload, uploadCsvPro };
