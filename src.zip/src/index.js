"use strict";
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const dotenv = require("dotenv");
const bodyParser = require("body-parser");
// Load environment variables from .env file
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));


// Connect to MongoDB
mongoose
  .connect(process.env.MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("Connected to MongoDB");
  })
  .catch((error) => {
    console.error("Error connecting to MongoDB:", error);
  });

// Routes

// var cron = require('node-cron');

// cron.schedule('* * * * *', () => {
//   console.log('running a task every minute');
// });

const homeRoutes = require("./routes/home");
const authRoutes = require("./routes/auth");
const brandRoutes = require("./routes/brand");
const categoryRoutes = require("./routes/category");
const collectionRoutes = require("./routes/collection");

const subcategoryRoutes = require("./routes/subcategory");
const newsletterRoutes = require("./routes/newsletter");
const productRoutes = require("./routes/product");
const dashboardRoutes = require("./routes/dashboard");
const searchRoutes = require("./routes/search");
const userRoutes = require("./routes/user");
const cartRoutes = require("./routes/cart");
const couponCodeRoutes = require("./routes/coupon-code");
const productReviewRoutes = require("./routes/product-review");
const reviewRoutes = require("./routes/review");
const wishlistRoutes = require("./routes/wishlist");
const OrderRoutes = require("./routes/order");
const paymentRoutes = require("./routes/payment-response");

const delete_fileRoutes = require("./routes/file-delete");
const shopRoutes = require("./routes/shop");
const payment = require("./routes/payment");
const currency = require("./routes/currencies");
const compaign = require("./routes/compaign");
const notification = require("./routes/notification");
const fileRoutes = require("./routes/fileRoutes");
const sizeRoutes = require("./routes/size");
const colorRoutes = require("./routes/colors");
const roomRoutes = require("./routes/room");
const patterRoutes = require("./routes/pattern");
const shapeRoutes = require("./routes/shape");
const bannerRoutes = require("./routes/banner");
const masterRoutes = require("./routes/master");
const filterRoutes = require("./routes/filter");
const featuredLogoRoutes = require("./routes/logo_featured");
const rugsInspirationRoutes = require("./routes/rugs_inspiration");
const menuRoutes = require("./routes/menu");
const contactUs = require("./routes/contactUs");
const productRoutesCsv = require("./routes/productRoutes");
const storeLocator = require("./routes/storeLocator");
const pincodeRoutes = require("./routes/pincode");



app.use("/api", homeRoutes);
app.use("/api", authRoutes);
app.use("/api", brandRoutes);
app.use("/api", categoryRoutes);
app.use("/api", collectionRoutes);
app.use("/api", subcategoryRoutes);
app.use("/api", newsletterRoutes);
app.use("/api", productRoutes);
app.use("/api", dashboardRoutes);
app.use("/api", searchRoutes);
app.use("/api", userRoutes);
app.use("/api", cartRoutes);
app.use("/api", couponCodeRoutes);
app.use("/api", productReviewRoutes);
app.use("/api", reviewRoutes);
app.use("/api", wishlistRoutes);
app.use("/api", OrderRoutes);
app.use("/api", paymentRoutes);
app.use("/api", delete_fileRoutes);
app.use("/api", shopRoutes);
app.use("/api", payment);
app.use("/api", currency);
app.use("/api", compaign);
app.use("/api", notification);
app.use("/api", fileRoutes);
app.use("/api/", sizeRoutes);
app.use("/api/", colorRoutes);
app.use("/api/", roomRoutes);
app.use("/api/", patterRoutes);
app.use("/api/", shapeRoutes);
app.use("/api/", bannerRoutes);
app.use("/api/", masterRoutes);
app.use("/api/", filterRoutes);
app.use("/api/", featuredLogoRoutes);
app.use("/api/", rugsInspirationRoutes);
app.use("/api/", menuRoutes);
app.use("/api/", contactUs);
app.use("/api", productRoutesCsv);
app.use("/api/", storeLocator);
app.use("/api/", pincodeRoutes);


// GET API
app.get("/", (req, res) => {
  res.send("This is a GET API");
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
