const User = require("../models/User");
const Sizes = require("../models/Sizes.js");

const createSize = async (req, res) => {
  try {
    const { ...others } = req.body;
    await Sizes.create({
      ...others,
    });

    res.status(201).json({ success: true, message: "Size Created" });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};
const getSizes = async (req, res) => {
  // console.log("Hello");
  try {
    const sizes = await Sizes.find().sort({
      createdAt: -1,
    });

    res.status(201).json({
      success: true,
      data: sizes,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const updateSizeById = async (req, res) => {
  try {
    const { id } = req.params;
    const { height, width, units,slug,name} = req.body;

    const newSize = await Sizes.findByIdAndUpdate(
      id,
      { height, width, units,slug,name },
      { new: true } // This option returns the updated document
    );

    if (!newSize) {
      return res
        .status(404)
        .json({ success: false, message: "Size not found" });
    }

    res
      .status(200)
      .json({ success: true, message: "Size Updated", data: newSize });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
};

const deleteSizeById = async (req, res) => {
  try {
    const { id } = req.params;

    const deletedSize = await Sizes.findByIdAndDelete(id);

    res.status(201).json({
      success: true,
      message: "Size Deleted Successfully",
      data: deletedSize,
    });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
};

// get singel sixe
const getSizeById = async (req, res) => {
  const { id } = req.params; // Extract the ID from the request parameters

  try {
    const size = await Sizes.findById(id); // Find the size by ID

    if (!size) {
      return res
        .status(404)
        .json({ success: false, message: "Size not found" });
    }

    res.status(200).json({ success: true, data: size }); // Return the found size
  } catch (error) {
    res.status(500).json({ success: false, message: error.message }); // Handle errors
  }
};


// get sizes Name
/*const getSizesName = async (req, res) => {
  try {
    const sizes = await Sizes.find()
      .sort({
        createdAt: -1,
      })
      .select(["height", "width", "units","slug"]);

    res.status(201).json({
      success: true,
      data: sizes,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};*/

// with custom limit
const getSizesName = async (req, res) => {
  try {
    // Get the limit from the query parameters, default to null (no limit)
    const limit = parseInt(req.query.limit) || null;

    const query = Sizes.find()
      .sort({ createdAt: -1 })
      .select(["height", "width", "units", "slug", "name"]);

    // If a limit is provided, apply it to the query
    if (limit) {
      query.limit(limit);
    }

    const sizes = await query;

    res.status(200).json({
      success: true,
      data: sizes,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};


module.exports = {
  createSize,
  getSizes,
  updateSizeById,
  deleteSizeById,
  getSizeById,
  getSizesName,
};
