const User = require("../models/User.js");
const Patterns = require("../models/Pattern");

const createPattern = async (req, res) => {
  try {
    const { ...others } = req.body;
    await Patterns.create({
      ...others,
    });

    res.status(201).json({ success: true, message: "Pattern Created" });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};
const getPatterns = async (req, res) => {
  // console.log("Hello");
  try {
    const patterns = await Patterns.find().sort({
      createdAt: -1,
    });

    res.status(201).json({
      success: true,
      data: patterns,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const updatePatternsById = async (req, res) => {
  try {
    const { id } = req.params;
    const { name,slug } = req.body;

    const newPattern = await Patterns.findByIdAndUpdate(
      id,
      { name, slug },
      { new: true } // This option returns the updated document
    );

    if (!newPattern) {
      return res
        .status(404)
        .json({ success: false, message: "Pattern not found" });
    }

    res
      .status(200)
      .json({ success: true, message: "Pattern Updated", data: newPattern });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
};

const deletePatternsById = async (req, res) => {
  try {
    const { id } = req.params;

    const deletedPattern = await Patterns.findByIdAndDelete(id);

    res.status(201).json({
      success: true,
      message: "Pattern Deleted Successfully",
      data: deletedPattern,
    });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
};

// get singel pattern
const getPatternById = async (req, res) => {
  const { id } = req.params; // Extract the ID from the request parameters

  try {
    const pattern = await Patterns.findById(id); // Find the room by ID

    if (!pattern) {
      return res
        .status(404)
        .json({ success: false, message: "Pattern not found" });
    }

    res.status(200).json({ success: true, data: pattern }); // Return the found pattern
  } catch (error) {
    res.status(500).json({ success: false, message: error.message }); // Handle errors
  }
};

/*const getPatternsName = async (req, res) => {
  try {
    const patterns = await Patterns.find()
      .sort({
        createdAt: -1,
      })
      .select(["patternType","slug"]);

    res.status(201).json({
      success: true,
      data: patterns,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};*/

// with custome limit
const getPatternsName = async (req, res) => {
  try {
    // Get the limit from the query parameters, default to null (no limit)
    const limit = parseInt(req.query.limit) || null;

    const query = Patterns.find().sort({ createdAt: -1 }).select(["name", "slug"]);

    // If a limit is provided, apply it to the query
    if (limit) {
      query.limit(limit);
    }

    const patterns = await query;

    res.status(200).json({
      success: true,
      data: patterns,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};




module.exports = {
  createPattern,
  getPatterns,
  updatePatternsById,
  deletePatternsById,
  getPatternById,
  getPatternsName,
};
