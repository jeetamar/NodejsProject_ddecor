const Inspiration = require("../models/Inspiration");
const { DeleteObjectCommand } = require("@aws-sdk/client-s3");
// Initialize S3 client

const s3 = require("../config/s3");

const createRugsInspiration = async (req, res) => {
  console.log(req.body);
  try {
    const { cover, ...others } = req.body;

    await Inspiration.create({
      ...others,
      cover: {
        ...cover,
      },
    });

    res.status(201).json({ success: true, message: "Inspiration Created" });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

const getRugsInspiration = async (req, res) => {
  try {
    const { limit = 10, page = 1, search = "" } = req.query;

    const skip = parseInt(limit) || 10;
    const totalInspiration = await Inspiration.find({
      name: { $regex: search, $options: "i" },
    });
    const inspirations = await Inspiration.find(
      {
        name: { $regex: search, $options: "i" },
      },
      null,
      {
        skip: skip * (parseInt(page) - 1 || 0),
        limit: skip,
      }
    ).sort({
      createdAt: -1,
    });

    res.status(201).json({
      success: true,
      data: inspirations,
      count: Math.ceil(totalInspiration.length / skip),
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// get rugs inspiration by slug

const getRugsInspirationBySlug = async (req, res) => {
  try {
    const { slug } = req.params;
    const inspiration = await Inspiration.findOne({ slug });

    if (!inspiration) {
      return res.status(400).json({
        success: false,
        message: "Inspiration Not Found",
      });
    }

    res.status(201).json({ success: true, data: inspiration });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message,
    });
  }
};

// update inspiration
const updateRugsInspirationBySlug = async (req, res) => {
  try {
    const { slug } = req.params;
    const { cover, ...others } = req.body;

    await Inspiration.findOneAndUpdate(
      { slug },
      {
        ...others,
        cover: {
          ...cover,
        },
      },
      { new: true, runValidators: true }
    );

    res.status(201).json({ success: true, message: "Inspiration Updated" });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// delete inspiration
const deleteRugsInspirationBySlug = async (req, res) => {
  try {
    const { slug } = req.params;

    // Find and delete logo by slug
    const inspiration = await Inspiration.findOneAndDelete({ slug });

    if (!inspiration) {
      return res.status(404).json({
        success: false,
        message: "Inspiration Not Found",
      });
    }

    // Check if the inspiration has a cover file
    if (inspiration.cover && inspiration.cover.key) {
      // Prepare AWS S3 delete parameters
      const deleteParams = {
        Bucket: process.env.AWS_BUCKET_NAME, // Ensure you have your bucket name in environment variables
        Key: inspiration.cover.key, // Correctly reference the S3 object key
      };

      // Attempt to delete the cover file from S3
      try {
        await s3.send(new DeleteObjectCommand(deleteParams));
      } catch (fileError) {
        console.error("Error deleting cover file from S3:", fileError);
        return res.status(500).json({
          success: false,
          message:
            "Inspiration deleted, but failed to delete cover file from S3.",
        });
      }
    }

    // Send success response
    res.status(200).json({
      success: true,
      message: "Inspiration Deleted Successfully",
    });
  } catch (error) {
    console.error("Error deleting logo:", error); // More detailed error logging
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};

const getRugsInspirationByAdmin = async (req, res) => {
  try {
    const inspirations = await Inspiration.find()
      .sort({
        createdAt: -1,
      })
      .select(["name", "slug"]);

    res.status(201).json({
      success: true,
      data: inspirations,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

module.exports = {
  createRugsInspiration,
  getRugsInspiration,
  getRugsInspirationBySlug,
  updateRugsInspirationBySlug,
  deleteRugsInspirationBySlug,
  getRugsInspirationByAdmin,
};
