const User = require("../models/User");
const Categories = require("../models/Category");
const SubCategories = require("../models/SubCategory");
// const { singleFileDelete } = require("../config/uploader");
const { DeleteObjectCommand } = require("@aws-sdk/client-s3");
const s3 = require("../config/s3");
// Initialize S3 client
// const s3 = new S3Client({ region: process.env.AWS_REGION });

const createCategory = async (req, res) => {
  try {
    const { cover, ...others } = req.body;
    // Validate if the 'blurDataURL' property exists in the logo object

    // If blurDataURL is not provided, generate it using the 'getBlurDataURL' function
    // const blurDataURL = await getBlurDataURL(cover.url);

    await Categories.create({
      ...others,
      cover: {
        ...cover,
      },
    });

    res.status(201).json({ success: true, message: "Category Created" });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

const getAllHeaderCategories = async (req, res) => {
  try {
    const userCount = await User.countDocuments();
    await SubCategories.findOne();
    const categories = await Categories.find()
      .sort({
        createdAt: -1,
      })
      .select(["name", "slug", "subCategories"])
      .populate({ path: "subCategories", select: ["name", "slug"] });

    res.status(201).json({
      success: true,
      data: categories,
      ...(!userCount && {
        adminPopup: true,
      }),
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

const getAllCategories = async (req, res) => {
  try {
    await SubCategories.findOne();
    const categories = await Categories.find()
      .sort({
        createdAt: -1,
      })
      .select(["name", "slug"])
      .populate({ path: "subCategories", select: ["name", "slug"] });

    res.status(201).json({
      success: true,
      data: categories,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

const getCategoriesByAdmin = async (req, res) => {
  try {
    const categories = await Categories.find()
      .sort({
        createdAt: -1,
      })
      .select(["name", "slug"]);

    res.status(201).json({
      success: true,
      data: categories,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};


const getCategoryByAdmin = async (req, res) => {
  try {
    const { slug } = req.params;
    const category = await Categories.findOne({ slug });

    if (!category) {
      return res.status(400).json({
        success: false,
        message: "Category Not Found",
      });
    }

    res.status(201).json({ success: true, data: category });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message,
    });
  }
};

const getCategoryBySlug = async (req, res) => {
  try {
    const { slug } = req.params;
    const category = await Categories.findOne({ slug });

    // const category = await Categories.findOne({ slug }).select([
    //   "name",
    //   "description",
    //   "metaTitle",
    //   "metaDescription",
    //   "cover",
    //   "slug",
    // ]);


    if (!category) {
      return res.status(400).json({
        success: false,
        message: "Category Not Found",
      });
    }

    res.status(201).json({ success: true, data: category });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message,
    });
  }
};

const updateCategoryBySlug = async (req, res) => {
  try {
    const { slug } = req.params;
    const { cover, ...others } = req.body;
    // Validate if the 'blurDataURL' property exists in the logo object
    // if (!cover.blurDataURL) {
    //   // If blurDataURL is not provided, generate it using the 'getBlurDataURL' function
    //   cover.blurDataURL = await getBlurDataURL(cover.url);
    // }
    await Categories.findOneAndUpdate(
      { slug },
      {
        ...others,
        cover: {
          ...cover,
        },
      },
      { new: true, runValidators: true }
    );

    res.status(201).json({ success: true, message: "Category Updated" });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

//old code
// const deleteCategoryBySlug = async (req, res) => {
//   try {
//     const { slug } = req.params;

//     const category = await Categories.findOneAndDelete({ slug });
//     const dataaa = await singleFileDelete(category.cover._id);
//     if (!category) {
//       return res.status(400).json({
//         success: false,
//         message: "Category Not Found",
//       });
//     }

//     res
//       .status(201)
//       .json({ success: true, message: "Category Deleted Successfully" });
//   } catch (error) {
//     res.status(400).json({ success: false, message: error.message });
//   }
// };

// some updated code
// const deleteCategoryBySlug = async (req, res) => {
//   try {
//     const { slug } = req.params;

//     const category = await Categories.findOneAndDelete({ slug });

//     if (!category) {
//       return res.status(404).json({
//         success: false,
//         message: "Category Not Found",
//       });
//     }

//     // Ensure singleFileDelete does not fail
//     await singleFileDelete(category.cover._id);

//     res.status(200).json({
//       success: true,
//       message: "Category Deleted Successfully",
//     });
//   } catch (error) {
//     console.error("Error deleting category:", error); // Log the error for debugging
//     res.status(500).json({
//       success: false,
//       message: "Internal Server Error",
//     });
//   }
// };

// const deleteCategoryBySlug = async (req, res) => {
//   try {
//     const { slug } = req.params;

//     const category = await Categories.findOneAndDelete({ slug });

//     if (!category) {
//       return res.status(404).json({
//         success: false,
//         message: "Category Not Found",
//       });
//     }

//     try {
//       await singleFileDelete(category.cover._id);
//     } catch (fileError) {
//       console.error("Error deleting cover file:", fileError);
//       return res.status(500).json({
//         success: false,
//         message: "Category deleted, but failed to delete cover file.",
//       });
//     }

//     res.status(200).json({
//       success: true,
//       message: "Category Deleted Successfully",
//     });
//   } catch (error) {
//     console.error("Error deleting category:", error); // More detailed error logging
//     res.status(500).json({
//       success: false,
//       message: "Internal Server Error",
//     });
//   }
// };

const deleteCategoryBySlug = async (req, res) => {
  try {
    const { slug } = req.params;

    // Find and delete category by slug
    const category = await Categories.findOneAndDelete({ slug });

    if (!category) {
      return res.status(404).json({
        success: false,
        message: "Category Not Found",
      });
    }

    // Prepare AWS S3 delete parameters
    const deleteParams = {
      Bucket: process.env.AWS_BUCKET_NAME, // Ensure you have your bucket name in environment variables
      Key: category.cover.key, // Assuming category.cover._id is the S3 object key
    };

    // Attempt to delete the cover file from S3
    try {
      await s3.send(new DeleteObjectCommand(deleteParams));
    } catch (fileError) {
      console.error("Error deleting cover file from S3:", fileError);
      return res.status(500).json({
        success: false,
        message: "Category deleted, but failed to delete cover file from S3.",
      });
    }

    // Send success response
    res.status(200).json({
      success: true,
      message: "Category Deleted Successfully",
    });
  } catch (error) {
    console.error("Error deleting category:", error); // More detailed error logging
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};

const getCategories = async (req, res) => {
  try {
    const { limit = 10, page = 1, search = "" } = req.query;

    const skip = parseInt(limit) || 10;
    const totalCategories = await Categories.find({
      name: { $regex: search, $options: "i" },
    });
    const categories = await Categories.find(
      {
        name: { $regex: search, $options: "i" },
      },
      null,
      {
        skip: skip * (parseInt(page) - 1 || 0),
        limit: skip,
      }
    ).sort({
      createdAt: -1,
    });

    res.status(201).json({
      success: true,
      data: categories,
      count: Math.ceil(totalCategories.length / skip),
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};
const getCategoriesSlugs = async (req, res) => {
  try {
    const categories = await Categories.find().select("slug");

    res.status(201).json({
      success: true,
      data: categories,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};
const getSubCategoriesSlugs = async (req, res) => {
  try {
    const categories = await SubCategories.find()
      .select("slug")
      .populate({ path: "parentCategory", select: ["slug"] });

    res.status(201).json({
      success: true,
      data: categories,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};
const getCategoryNameBySlug = async (req, res) => {
  try {
    const category = await Categories.findOne({
      slug: req.params.slug,
    }).select(["name", "slug"]);

    res.status(201).json({
      success: true,
      data: category,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// Get categories isHome

const getIsHomeCategories = async (req, res) => {
  try {
    const isHomeCategories = await Categories.find({ isHome: true });

    res.status(200).json({
      success: true,
      data: isHomeCategories,
      count: isHomeCategories.length,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};


module.exports = {
  createCategory,
  getCategories,
  getAllHeaderCategories,
  getCategoryBySlug,
  updateCategoryBySlug,
  deleteCategoryBySlug,
  getCategoriesSlugs,
  getSubCategoriesSlugs,
  getCategoryByAdmin,
  getCategoryNameBySlug,
  getAllCategories,
  getCategoriesByAdmin,
  getIsHomeCategories,
};
