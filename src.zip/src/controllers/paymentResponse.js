const bodyParser = require("body-parser");
const PaymentModel = require("../models/PaymentModel.js");
const OrderModel = require("../models/Order");
// Payment response handler

const payment_response = async (req, res) => {
  try {
    const payload = req.body; // Incoming payload

    // Log the payload for debugging
    console.log("Received Payload:", payload);

    // Check if payload contains the required fields
    if (!payload || !payload["Response Code"]) {
      return res.status(200).json({
        status: false,
        message: "Invalid payload, Response Code is missing.",
      });
    }

    // Process based on Response Code
    if (payload["Response Code"] === "E000") {
      // Success Response
      res.json({
        status: true,
        message: "Payment Successful",
        uniqueRefNumber: payload["Unique Ref Number"],
        referenceNumber: payload.ReferenceNo,
        transactionAmount: payload["Transaction Amount"],
        transactionDate: payload["Transaction Date"],
        paymentMode: payload["Payment Mode"],
        subMerchantId: payload.SubMerchantId,
      });
    } else {
      // Failure Response
      res.json({
        status: false,
        message: `Payment Failed: ${payload["Response Code"]}`,
        uniqueRefNumber: payload["Unique Ref Number"],
        referenceNumber: payload.ReferenceNo,
        transactionAmount: payload["Transaction Amount"],
        transactionDate: payload["Transaction Date"],
        paymentMode: payload["Payment Mode"],
        subMerchantId: payload.SubMerchantId,
      });
    }
  } catch (error) {
    return res.status(500).json({
      status: false,
      message: error.message,
    });
  }
};

//
// Create payment
const createPayment = async (req, res) => {
  try {
    const newPayment = await PaymentModel.create(req.body);
    res
      .status(201)
      .json({ success: true, message: "Payment created", data: newPayment });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};
// update payment
// const updatePayment = async (req, res) => {
//   try {
//     const { orderNo } = req.body; // The orderNo is provided in the body to identify the payment

//     // Find the payment by the orderNo (order number is unique per order)
//     const payment = await PaymentModel.findOne({ orderNo });

//     if (!payment) {
//       return res.status(200).json({
//         success: false,
//         message: "Payment not found for the given orderNo",
//       });
//     }

//     // Update payment status based on the request body
//     if (req.body.status) {
//       payment.status = req.body.status; // e.g., 'paid', 'failed', etc.
//     }

//     // If payment is successful, update the paidAt field
//     if (req.body.status === "paid") {
//       payment.paidAt = new Date(); // Set the paidAt timestamp
//     }

//     // Update the orderNo if needed (optional, assuming you allow this change)
//     if (req.body.orderNo) {
//       payment.orderNo = req.body.orderNo;
//     }

//     // You can also update other fields like `total`, `referenceNo`, etc., if needed
//     if (req.body.total) {
//       payment.total = req.body.total;
//     }

//     // Save the updated payment document
//     const updatedPayment = await payment.save();

//     res.status(200).json({
//       success: true,
//       message: "Payment updated successfully",
//       data: updatedPayment,
//     });
//   } catch (error) {
//     res.status(400).json({
//       success: false,
//       message: error.message,
//     });
//   }
// };

const updatePayment = async (req, res) => {
  try {
    const { orderNo } = req.body; // The orderNo is provided in the body to identify the payment

    // Find the payment by the orderNo (order number is unique per order)
    const payment = await PaymentModel.findOne({ orderNo });

    if (!payment) {
      return res.status(404).json({
        success: false,
        message: "Payment not found for the given orderNo",
      });
    }

    // Update payment status based on the request body
    if (req.body.status) {
      payment.status = req.body.status; // e.g., 'paid', 'failed', etc.
    }

    // If payment is successful (status = 'paid'), set the paidAt field
    if (req.body.status === "paid") {
      payment.paidAt = new Date(); // Set the paidAt timestamp

      // Now, update the corresponding Order status to 'processing'
      const order = await OrderModel.findOne({ orderNo });

      if (order) {
        order.status = "processing"; // Update the order status to 'processing' (or any other logic you need)
        await order.save(); // Save the updated order
      } else {
        return res.status(404).json({
          success: false,
          message: "Order not found for the given orderNo",
        });
      }
    }

    // Update the orderNo if needed (optional, assuming you allow this change)
    if (req.body.orderNo) {
      payment.orderNo = req.body.orderNo;
    }

    // You can also update other fields like `total`, `referenceNo`, etc., if needed
    if (req.body.total) {
      payment.total = req.body.total;
    }

    // Save the updated payment document
    const updatedPayment = await payment.save();

    res.status(200).json({
      success: true,
      message: "Payment and Order updated successfully",
      data: updatedPayment,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message,
    });
  }
};

module.exports = { payment_response, createPayment, updatePayment };
