const User = require("../models/User");
const Contact = require("../models/ContactUs.js");

const createContactUs = async (req, res) => {
  try {
    const { ...others } = req.body;
    await Contact.create({
      ...others,
    });

    res.status(201).json({ success: true, message: "Contact Us Created" });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};
const getContactUs = async (req, res) => {
  // console.log("Hello");
  try {
    const contacts = await Contact.find().sort({
      createdAt: -1,
    });

    res.status(201).json({
      success: true,
      data: contacts,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const updateContactUsById = async (req, res) => {
  try {
    const { id } = req.params;
    const { ...others } = req.body;

    const contact = await Contact.findByIdAndUpdate(
      id,
      { ...others },
      { new: true } // This option returns the updated document
    );

    if (!contact) {
      return res
        .status(404)
        .json({ success: false, message: "Contact not found" });
    }

    res
      .status(200)
      .json({ success: true, message: "Contact Updated", data: contact });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
};

const deleteContactUsById = async (req, res) => {
  try {
    const { id } = req.params;

    const deleteContact = await Contact.findByIdAndDelete(id);

    res.status(201).json({
      success: true,
      message: "Contact Deleted Successfully",
      data: deleteContact,
    });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
};

// get singel contact
const getContactUsById = async (req, res) => {
  const { id } = req.params; // Extract the ID from the request parameters

  try {
    const contact = await Contact.findById(id); // Find the contact by ID

    if (!contact) {
      return res
        .status(404)
        .json({ success: false, message: "Contact not found" });
    }

    res.status(200).json({ success: true, data: contact }); // Return the found contact
  } catch (error) {
    res.status(500).json({ success: false, message: error.message }); // Handle errors
  }
};

module.exports = {
  createContactUs,
  getContactUs,
  updateContactUsById,
  deleteContactUsById,
  getContactUsById,
};
