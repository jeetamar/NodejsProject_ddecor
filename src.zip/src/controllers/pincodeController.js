const Pincode = require("../models/Pincode");
const csv = require("csv-parser");
const fs = require("fs");
const path = require("path");
const axios = require("axios");

// Create a new Pincode
const createPincode = async (req, res) => {
  try {
    const { pincode, city } = req.body;

    // Use Pincode.create() for creating and saving in one step
    const newPincode = await Pincode.create({ pincode, city });

    res.status(201).json({
      status: true,
      message: "Pincode created successfully",
      data: newPincode,
    });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// Get all Pincodes
const getAllPincodes = async (req, res) => {
  try {
    // No need for new instance or creation, just find all
    const pincodes = await Pincode.find();
    res.status(200).json({
      status: true,
      message: "Pincodes retrieved successfully",
      data: pincodes,
      count: pincodes.length,
    });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// Get a single Pincode by its ID
const getPincodeById = async (req, res) => {
  try {
    const pincode = await Pincode.findById(req.params.id);

    if (!pincode) {
      return res.status(404).json({ message: "Pincode not found" });
    }

    res.status(200).json({
      status: true,
      message: "Pincode retrieved successfully",
      data: pincode,
    });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// Update a Pincode
const updatePincode = async (req, res) => {
  try {
    // Use findByIdAndUpdate to update directly
    const updatedPincode = await Pincode.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true } // Return the updated document
    );

    if (!updatedPincode) {
      return res.status(404).json({ message: "Pincode not found" });
    }

    res.status(200).json({
      status: true,
      message: "Pincode updated successfully",
      data: updatedPincode,
    });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// Delete a Pincode
const deletePincode = async (req, res) => {
  try {
    const deletedPincode = await Pincode.findByIdAndDelete(req.params.id);

    if (!deletedPincode) {
      return res.status(404).json({ message: "Pincode not found" });
    }

    res.status(200).json({
      status: true,
      message: "Pincode deleted successfully",
    });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

const checkPincodeAvailability = async (req, res) => {
  try {
    const { pincode } = req.body;

    if (!pincode) {
      return res.status(200).json({
        status: false,
        message: "Oops! Please provide a pincode to check availability.",
      });
    }

    
    //
    // Step 1: Check if pincode exists in India using the external API
    const response = await axios.get(
      `https://api.postalpincode.in/pincode/${pincode}`
    );

    // Step 2: Check the status from the API response
    if (response.data[0].Status !== "Success") {
      return res.status(200).json({
        status: false,
        message: "Invalid Pincode",
      });
    }


    const foundPincode = await Pincode.findOne({ pincode });

    if (foundPincode) {
      return res.status(200).json({
        status: true,
        message: `Great news! We deliver to pincode ${pincode}. Place your order now and we'll ensure a speedy delivery!`,
        data: foundPincode,
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "Currently out of stock in this area.",
      });
    }
  } catch (error) {
    console.error("Error checking pincode availability:", error);
    return res.status(500).json({
      status: false,
      message: "Something went wrong on our end. Please try again later.",
      error: error.message,
    });
  }
};


// upload csvfile pincode

const uploadCsvFile = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        status: false,
        message: "Please upload a CSV file.",
      });
    }

    const filePath = path.resolve(req.file.path); // Resolve the file path
    const pincodes = [];

    // Parse the CSV file
    fs.createReadStream(filePath)
      .pipe(csv())
      .on("data", (row) => {
        pincodes.push({ pincode: row.pincode, city: row.city });
      })
      .on("end", async () => {
        try {
          const uniquePincodes = pincodes.filter(
            (v, i, a) => a.findIndex((t) => t.pincode === v.pincode) === i
          );

          await Pincode.insertMany(uniquePincodes, { ordered: false }).catch(
            (err) => {
              if (err.code !== 11000) throw err; // Ignore duplicate key errors
            }
          );

          fs.unlinkSync(filePath); // Delete file after processing

          res.status(200).json({
            status: true,
            message: "CSV file uploaded and processed successfully.",
            totalRecords: uniquePincodes.length,
          });
        } catch (err) {
          res.status(500).json({
            status: false,
            message: "An error occurred while saving data.",
            error: err.message,
          });
        }
      });
  } catch (error) {
    console.error("Error uploading CSV:", error);
    res.status(500).json({
      status: false,
      message: "An error occurred while processing the CSV file.",
      error: error.message,
    });
  }
};

module.exports = {
  createPincode,
  getAllPincodes,
  getPincodeById,
  updatePincode,
  deletePincode,
  checkPincodeAvailability,
  uploadCsvFile,
};
