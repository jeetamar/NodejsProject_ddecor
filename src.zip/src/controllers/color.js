const User = require("../models/User");
const Colors = require("../models/Color.js");

const createColor = async (req, res) => {
  try {
    const { ...others } = req.body;
    await Colors.create({
      ...others,
    });

    res.status(201).json({ success: true, message: "Color Created" });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};
const getColors = async (req, res) => {
  // console.log("Hello");
  try {
    const sizes = await Colors.find().sort({
      createdAt: -1,
    });

    res.status(201).json({
      success: true,
      data: sizes,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const updateColorById = async (req, res) => {
  try {
    const { id } = req.params;
    const { colorHexCode, name , slug } = req.body;

    const newColor = await Colors.findByIdAndUpdate(
      id,
      { colorHexCode, name,slug },
      { new: true } // This option returns the updated document
    );

    if (!newColor) {
      return res
        .status(404)
        .json({ success: false, message: "Color not found" });
    }

    res
      .status(200)
      .json({ success: true, message: "Color Updated", data: newColor });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
};

const deleteColorById = async (req, res) => {
  try {
    const { id } = req.params;

    const deletedSize = await Colors.findByIdAndDelete(id);

    res.status(201).json({
      success: true,
      message: "Color Deleted Successfully",
      data: deletedSize,
    });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
};

// get singel color
const getColorById = async (req, res) => {
  const { id } = req.params; // Extract the ID from the request parameters

  try {
    const color = await Colors.findById(id); // Find the color by ID

    if (!color) {
      return res
        .status(404)
        .json({ success: false, message: "Color not found" });
    }

    res.status(200).json({ success: true, data: color }); // Return the found color
  } catch (error) {
    res.status(500).json({ success: false, message: error.message }); // Handle errors
  }
};


// get colors all name
/*const getColorsName = async (req, res) => {
  try {
    const colors = await Colors.find()
      .sort({
        createdAt: -1,
      })
      .select(["colorName","slug"]);

    res.status(201).json({
      success: true,
      data: colors,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};*/

// with custome limit
const getColorsName = async (req, res) => {
  try {
    // Get the limit from the query parameters, default to null (no limit)
    const limit = parseInt(req.query.limit) || null;

    const query = Colors.find().sort({ createdAt: -1 }).select(["name", "slug"]);

    // If a limit is provided, apply it to the query
    if (limit) {
      query.limit(limit);
    }

    const colors = await query;

    res.status(200).json({
      success: true,
      data: colors,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};



module.exports = {
  createColor,
  getColors,
  updateColorById,
  deleteColorById,
  getColorById,
  getColorsName,
};
