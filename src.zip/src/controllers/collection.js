const User = require("../models/User");
const Collections = require("../models/Collection");
const { DeleteObjectCommand } = require("@aws-sdk/client-s3");
// Initialize S3 client

const s3 = require("../config/s3");

/*const createCollections = async (req, res) => {
  console.log("Hello");
  try {
    const { cover, ...others } = req.body;

    await Collections.create({
      ...others,
      cover: {
        ...cover,
      },
    });

    res.status(201).json({ success: true, message: "Collection Created" });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};*/

/*const createCollections = async (req, res) => {
  console.log(req.body);
  try {
    const { cover, isFeatured, order, ...others } = req.body;

    // Check if isFeatured is true and order is set
    if (isFeatured && order) {
      // Check if a collection with the same order exists
      const existingCollection = await Collections.findOne({
        isFeatured: true,
        order,
      });

      if (existingCollection) {
        return res.status(400).json({
          success: false,
          message: `Order ${order} is already assigned to another featured collection.`,
        });
      }
    }

    await Collections.create({
      ...others,
      cover: {
        ...cover,
      },
      isFeatured: isFeatured, // Explicitly include
      order: order,
    });

    res.status(201).json({ success: true, message: "Collection Created" });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};*/

const createCollections = async (req, res) => {
  console.log(req.body);
  try {
    const { cover, isFeatured, order, ...others } = req.body;

    // Check if isFeatured is true and order is not provided
    if (isFeatured && (order === undefined || order === null || order === "")) {
      return res.status(400).json({
        success: false,
        message: "Order is required when Featured Collection is selected.",
      });
    }

    // Check if isFeatured is true and order is set
    if (isFeatured && order) {
      // Check if a collection with the same order exists
      const existingCollection = await Collections.findOne({
        isFeatured: true,
        order,
      });

      if (existingCollection) {
        return res.status(400).json({
          success: false,
          message: `Order ${order} is already assigned to another featured collection.`,
        });
      }
    }

    await Collections.create({
      ...others,
      cover: {
        ...cover,
      },
      isFeatured: isFeatured, // Explicitly include
      order: order,
    });

    res.status(201).json({ success: true, message: "Collection Created" });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};


/*const getCollections = async (req, res) => {
  try {
    const { limit = 10, page = 1, search = "" } = req.query;

    const skip = parseInt(limit) || 10;
    // Get total collections count
    const totalCollections = await Collections.countDocuments();
    const collections = await Collections.find(
      {
        name: { $regex: search, $options: "i" },
      },
      null,
      {
        skip: skip * (parseInt(page) - 1 || 0),
        limit: skip,
      }
    ).sort({
      createdAt: -1,
    });

    res.status(201).json({
      success: true,
      data: collections,
      count: totalCollections,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};*/



const getCollections = async (req, res) => {
  try {
    const { limit = 10, page = 1, search = "" } = req.query;

    const skip = parseInt(limit) || 10;
    // Get total collections count
    const totalCollections = await Collections.countDocuments();
    const collections = await Collections.find(
      {
        name: { $regex: search, $options: "i" },
        
      },
      null,
      {
        skip: skip * (parseInt(page) - 1 || 0),
        limit: skip,
      }
    ).sort({
    //   createdAt: -1,
      name:1,
    });

    res.status(201).json({
      success: true,
      data: collections,
      count: totalCollections,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};




// get collection by slug

const getCollectionsBySlug = async (req, res) => {
  try {
    const { slug } = req.params;
    const collection = await Collections.findOne({ slug });
    
    //  const collection = await Collections.findOne({ slug }).select([
    //   "name",
    //   "description",
    //   "metaTitle",
    //   "metaDescription",
    //   "cover",
    //   "slug",
    // ]);

    if (!collection) {
      return res.status(400).json({
        success: false,
        message: "Collection Not Found",
      });
    }

    res.status(201).json({ success: true, data: collection });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message,
    });
  }
};

// update collection
/*const updateCollectionBySlug = async (req, res) => {
  try {
    const { slug } = req.params;
    const { cover, ...others } = req.body;

    await Collections.findOneAndUpdate(
      { slug },
      {
        ...others,
        cover: {
          ...cover,
        },
      },
      { new: true, runValidators: true }
    );

    res.status(201).json({ success: true, message: "Collection Updated" });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};*/

const updateCollectionBySlug = async (req, res) => {
  try {
    const { slug } = req.params;
    const { cover, isFeatured, order, ...others } = req.body;

    // Check if isFeatured is true and order is not provided
    if (isFeatured && (order === undefined || order === null || order === "")) {
      return res.status(400).json({
        success: false,
        message: "Order is required when Featured Collection is selected.",
      });
    }

    // Check if isFeatured is true and order is set
    if (isFeatured && order) {
      // Check if a collection with the same order exists, excluding the current collection
      const existingCollection = await Collections.findOne({
        isFeatured: true,
        order,
        slug: { $ne: slug }, // Exclude current collection
      });

      if (existingCollection) {
        return res.status(400).json({
          success: false,
          message: `Order ${order} is already assigned to another featured collection.`,
        });
      }
    }

    const updatedCollection = await Collections.findOneAndUpdate(
      { slug },
      {
        ...others,
        cover: {
          ...cover,
        },
        isFeatured:isFeatured,
        order:order,
      },
      { new: true, runValidators: true }
    );

    if (!updatedCollection) {
      return res
        .status(404)
        .json({ success: false, message: "Collection not found" });
    }

    res.status(200).json({
      success: true,
      message: "Collection Updated",
      data: updatedCollection,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};



// delete collection
const deleteCollectionBySlug = async (req, res) => {
  try {
    const { slug } = req.params;

    // Find and delete collection by slug
    const collection = await Collections.findOneAndDelete({ slug });

    if (!collection) {
      return res.status(404).json({
        success: false,
        message: "Collection Not Found",
      });
    }

    // Check if the collection has a cover file
    if (collection.cover && collection.cover.key) {
      // Prepare AWS S3 delete parameters
      const deleteParams = {
        Bucket: process.env.AWS_BUCKET_NAME, // Ensure you have your bucket name in environment variables
        Key: collection.cover.key, // Correctly reference the S3 object key
      };

      // Attempt to delete the cover file from S3
      try {
        await s3.send(new DeleteObjectCommand(deleteParams));
      } catch (fileError) {
        console.error("Error deleting cover file from S3:", fileError);
        return res.status(500).json({
          success: false,
          message:
            "Collection deleted, but failed to delete cover file from S3.",
        });
      }
    }

    // Send success response
    res.status(200).json({
      success: true,
      message: "Collection Deleted Successfully",
    });
  } catch (error) {
    console.error("Error deleting collection:", error); // More detailed error logging
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};

const getCollectionByAdmin = async (req, res) => {
  try {
    const collection = await Collections.find()
      .sort({
        createdAt: -1,
      })
      .select(["name", "slug"]);

    res.status(201).json({
      success: true,
      data: collection,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};


// Get featured collections
const getFeaturedCollections = async (req, res) => {
  try {
    const featuredCollections = await Collections.find({
      isFeatured: true,
    }).sort({ order: 1 });

    res.status(200).json({
      success: true,
      data: featuredCollections,
      count: featuredCollections.length,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = {
  createCollections,
  getCollections,
  getCollectionsBySlug,
  updateCollectionBySlug,
  deleteCollectionBySlug,
  getCollectionByAdmin,
  getFeaturedCollections,
};
