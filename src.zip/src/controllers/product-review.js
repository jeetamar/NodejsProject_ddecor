const ProductReview = require("../models/ProductReview");
const Products = require("../models/Product");
const Users = require("../models/User");
const { getUser } = require("../config/getUser");
const Orders = require("../models/Order");
const blurDataUrl = require("../config/getBlurDataURL");


/*const getProductReviewsbyPid = async (req, res) => {
  try {
    // Populate the product
    const pid = req.params.pid;
    // Get reviews for the populated product
    const reviews = await ProductReview.find({
      product: pid,
    })
      .sort({
        createdAt: -1,
      })
      .populate({
        path: "user",
        select: ["firstName", "lastName", "cover", "orders"],
      });
    const product = await Products.findById(pid).select(["slug"]);

    const reviewsSummery = await Products.aggregate([
      {
        $match: { slug: product.slug },
      },

      {
        $lookup: {
          from: "productreviews",
          localField: "_id",
          foreignField: "product",
          as: "productreviews",
        },
      },
      {
        $unwind: "$productreviews",
      },

      {
        $group: {
          _id: "$productreviews.rating",
          count: { $sum: 1 },
        },
      },
    ]);

    return res.status(201).json({ success: true, reviewsSummery, reviews });
  } catch (error) {
    return res.status(400).json({ success: false, message: error.message });
  }
};*/

const getProductReviewsbyPid = async (req, res) => {
  try {
    const pid = req.params.pid;

    // Check if the product exists
    const product = await Products.findById(pid).select(["slug"]);
    if (!product) {
      return res
        .status(404)
        .json({ success: false, message: "Product not found." });
    }

    // Get reviews for the populated product
    const reviews = await ProductReview.find({ product: pid })
      .sort({ createdAt: -1 })
      .populate({
        path: "user",
        select: ["firstName", "lastName", "cover", "orders"],
      });

    // Check if there are no reviews
    if (!reviews.length) {
      return res.status(404).json({
        success: false,
        message: "No reviews found for this product.",
      });
    }

    // Aggregate reviews summary
    const reviewsSummary = await Products.aggregate([
      { $match: { slug: product.slug } },
      {
        $lookup: {
          from: "productreviews",
          localField: "_id",
          foreignField: "product",
          as: "productreviews",
        },
      },
      { $unwind: "$productreviews" },
      {
        $group: {
          _id: "$productreviews.rating",
          count: { $sum: 1 },
        },
      },
    ]);

    return res.status(200).json({ success: true, reviewsSummary, reviews });
  } catch (error) {
    return res.status(400).json({ success: false, message: error.message });
  }
};


// getProductReview
const getProductReview = async (req, res) => {
  try {
    // Get reviews 
    const reviews = await ProductReview.find().sort({ createdAt: -1 });

    // Check if there are no reviews
    if (!reviews.length) {
      return res.status(404).json({
        success: false,
        message: "No reviews found for this product.",
      });
    }

    return res.status(200).json({ success: true, reviews , count: reviews.length });
  } catch (error) {
    return res.status(400).json({ success: false, message: error.message });
  }
};

// getProductReview By Product Id
const getProductReviewByProductId = async (req, res) => {
  try {
    const pid = req.params.pid;

    // Check if the product exists
    const product = await Products.findById(pid).select(["slug"]);
    if (!product) {
      return res
        .status(404)
        .json({ success: false, message: "Product not found." });
    }

    // Get reviews for the specified product
    const reviews = await ProductReview.find({ product: pid }).sort({
      createdAt: -1,
    });

    // // Check if there are no reviews
    // if (reviews.length === 0) {
    //   return res.status(404).json({
    //     success: false,
    //     message: "No reviews found for this product.",
    //   });
    // }
    if (!reviews) {
      return res.status(200).json({ success: true, review: [] });
    }

    return res
      .status(200)
      .json({ success: true, reviews, count: reviews.length });
  } catch (error) {
    return res.status(400).json({ success: false, message: error.message });
  }
};

//User and product based reviews
const getUserReviewByProductId = async (req, res) => {
  try {
    const { pid, uid } = req.params;

    // Check if the product exists
    const product = await Products.findById(pid).select(["slug"]);
    if (!product) {
      return res
        .status(404)
        .json({ success: false, message: "Product not found." });
    }

    // Find the review by product ID and user ID
    const review = await ProductReview.findOne({ product: pid, user: uid });

    // // Check if the review exists
    // if (!review) {
    //   return res.status(404).json({
    //     success: false,
    //     message: "No review found for this product from the specified user.",
    //   });
    // }
    
    // If no review is found, return an empty array
    if (!review) {
      return res.status(200).json({ success: true, review: [] });
    }

    return res.status(200).json({ success: true, review });
  } catch (error) {
    console.error("Error fetching user review:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

/*const createProductReview = async (req, res) => {
  console.log("Product Review");
  try {
    const user = await getUser(req, res);
    const uid = user._id.toString();
    const { pid, rating, review: reviewText, images } = req.body;

    const orders = await Orders.find({
      "user.email": user.email,
      "items.pid": pid,
    });

    const updatedImages = await Promise.all(
      images.map(async (image) => {
        const blurDataURL = await blurDataUrl(image);
        return { url: image, blurDataURL };
      })
    );
    const review = await ProductReview.create({
      product: pid,
      review: reviewText,
      rating,
      images: updatedImages,
      user: uid,
      isPurchased: Boolean(orders.length),
    });

    await Products.findByIdAndUpdate(pid, {
      $addToSet: {
        reviews: review._id,
      },
    });

    return res.status(201).json({ success: true, data: review, user });
  } catch (error) {
    return res.status(400).json({ success: false, message: error.message });
  }
};*/

// added new code for create product reviews
/*const createProductReview = async (req, res) => {
  console.log("Product Review");
  try {
    console.log("Request Body:", req.body);

    const user = await getUser(req, res);
    const uid = user._id.toString();
    const { pid, rating, review: reviewText, images = [] } = req.body;

    // Check if images is an object and convert it to an array
    let imageArray = Array.isArray(images) ? images : [images];

    console.log("Processed Images Field:", imageArray);

    if (!Array.isArray(imageArray)) {
      return res.status(400).json({
        success: false,
        message: "Images field is not an array or object",
        receivedType: typeof images,
        receivedValue: images,
      });
    }

    const orders = await Orders.find({
      "user.email": user.email,
      "items.pid": pid,
    });

    const updatedImages = await Promise.all(
      imageArray.map(async (image) => {
        // Handle case where image is an object
        const imageUrl = image.url || image;
        const blurDataURL = await blurDataUrl(imageUrl);
        return { url: imageUrl, blurDataURL };
      })
    );

    const review = await ProductReview.create({
      product: pid,
      review: reviewText,
      rating,
      images: updatedImages,
      user: uid,
      isPurchased: Boolean(orders.length),
    });

    await Products.findByIdAndUpdate(pid, {
      $addToSet: {
        reviews: review._id,
      },
    });

    return res.status(201).json({ success: true, data: review, user });
  } catch (error) {
    return res.status(400).json({ success: false, message: error.message });
  }
};*/

// new 08/10/24
/*const createProductReview = async (req, res) => {
  // console.log("Product Review");
  try {
    console.log("Request Body:", req.body);

    const user = await getUser(req, res);
    console.log("User:", user);
    const uid = user._id.toString();

    const { pid, rating, review: reviewText } = req.body;

    // Check for required fields
    if (!pid || !rating || !reviewText) {
      return res.status(400).json({
        success: false,
        message: "Product ID, rating, and review text are required.",
      });
    }

    // Validate rating
    if (typeof rating !== "number" || rating < 1 || rating > 5) {
      return res.status(400).json({
        success: false,
        message: "Rating must be a number between 1 and 5.",
      });
    }

    // // Find orders to check if the user purchased the product
    // const orders = await Orders.find({
    //   "user.email": user.email,
    //   "items.pid": pid,
    // });

    // if (orders.length === 0) {
    //   return res.status(403).json({
    //     success: false,
    //     message: "You must purchase the product before reviewing.",
    //   });
    // }

    // Create the product review
    const review = await ProductReview.create({
      product: pid,
      user: uid,
      review: reviewText,
      rating,
      firstName: user.firstName || null,
      lastName: user.lastName || null,
      email: user.email || null,
    });

    // Update the product to add the new review
    await Products.findByIdAndUpdate(pid, {
      $addToSet: { reviews: review._id },
    });

    return res.status(201).json({ success: true, data: review, user });
  } catch (error) {
    console.error("Error creating product review:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};*/

const createProductReview = async (req, res) => {
  try {
    // console.log("Request Body:", req.body);

    const user = await getUser(req, res);
    // console.log("User:", user);
    const uid = user._id.toString();

    const { pid, rating, review: reviewText } = req.body;

    // Check for required fields
    if (!pid || !rating || !reviewText) {
      return res.status(400).json({
        success: false,
        message: "Product ID, rating, and review text are required.",
      });
    }

    // Validate rating
    if (typeof rating !== "number" || rating < 1 || rating > 5) {
      return res.status(400).json({
        success: false,
        message: "Rating must be a number between 1 and 5.",
      });
    }

    // Check if a review already exists from this user for this product
    let review = await ProductReview.findOne({ product: pid, user: uid });

    if (review) {
      // Update existing review
      review.review = reviewText;
      review.rating = rating;
      await review.save();
    } else {
      // Create new product review
      review = await ProductReview.create({
        product: pid,
        user: uid,
        review: reviewText,
        rating,
        firstName: user.firstName || null,
        lastName: user.lastName || null,
        email: user.email || null,
      });

      // Update the product to add the new review
      await Products.findByIdAndUpdate(pid, {
        $addToSet: { reviews: review._id },
      });
    }

    return res.status(200).json({ success: true, data: review, user });
  } catch (error) {
    console.error("Error creating/updating product review:", error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};




const getProductReviewsByAdmin = async (req, res) => {
  try {
    const reviews = await ProductReview.find(
      {}
    ); /* find all the data in our database */
    return res.status(200).json({ success: true, data: reviews });
  } catch (error) {
    return res.status(400).json({ success: false, message: error.message });
  }
};

const createProductReviewByAdmin = async (req, res) => {
  try {
    const { _id, review } = await req.body;
    const isProductReview = await ProductReview.findOne({ _id: _id });
    const product = await Products.findOne({ _id: _id });

    await Products.findByIdAndUpdate(
      _id,
      {
        totalProductReview: product.totalProductReview + 1,
        totalRating: product.totalRating + review.rating,
      },
      {
        new: true,
        runValidators: true,
      }
    );

    if (isProductReview) {
      const filtered = isProductReview.ratings.filter(
        (v) => v.name === `${review.rating} Star`
      )[0];
      const notFiltered = isProductReview.ratings.filter(
        (v) => v.name !== `${review.rating} Star`
      );

      const alreadyProductReview = await ProductReview.findByIdAndUpdate(
        _id,
        {
          ratings: [
            ...notFiltered,
            {
              name: `${review.rating} Star`,
              reviewCount: filtered.reviewCount + 1,
              starCount: filtered.starCount + 1,
            },
          ],
          reviews: [...isProductReview.reviews, { ...review }],
        },
        {
          new: true,
          runValidators: true,
        }
      );

      return res
        .status(400)
        .json({ success: true, data: alreadyProductReview });
    } else {
      const ratingData = [
        {
          name: "1 Star",
          starCount: 0,
          reviewCount: 0,
        },
        {
          name: "2 Star",
          starCount: 0,
          reviewCount: 0,
        },
        {
          name: "3 Star",
          starCount: 0,
          reviewCount: 0,
        },
        {
          name: "4 Star",
          starCount: 0,
          reviewCount: 0,
        },
        {
          name: "5 Star",
          starCount: 0,
          reviewCount: 0,
        },
      ];

      const filtered = ratingData.filter(
        (v) => v.name === `${review.rating} Star`
      )[0];
      const notFiltered = ratingData.filter(
        (v) => v.name !== `${review.rating} Star`
      );

      const newProductReview = await ProductReview.create([
        {
          _id: _id,
          ratings: [
            ...notFiltered,
            {
              name: `${review.rating} Star`,
              reviewCount: filtered.reviewCount + 1,
              starCount: filtered.starCount + 1,
            },
          ],
          reviews: [{ ...review }],
        },
      ]);

      return res.status(201).json({ success: true, data: newProductReview });
    }
  } catch (error) {
    return res.status(400).json({ success: false, error: message.error });
  }
};

module.exports = {
  getProductReviewsbyPid,
  getProductReview,
  getProductReviewByProductId,
  getUserReviewByProductId,
  createProductReview,
  getProductReviewsByAdmin,
  createProductReviewByAdmin,
};
