const Menu2 = require("../models/Menu.js");
const SizeCollection = require("../models/Sizes.js");
const ColorCollection = require("../models/Color.js");
const RoomCollection = require("../models/Room.js");
const ShapeCollection = require("../models/Shape.js");
const PatternCollection = require("../models/Pattern.js");
const Room = require("../models/Room.js");
const Pattern = require("../models/Pattern.js");
// Create a new menu
const createMenu = async (req, res) => {
//   console.log("ggggg");
  try {
    const {
      title,
      description,
      metaTitle,
      metaDescription,
      url,
      slug,
      submenus,
    } = req.body;

    const newMenu = await Menu2.create({
      title,
      description,
      metaTitle,
      metaDescription,
      url,
      slug,
      submenus,
    });

    res
      .status(201)
      .json({ success: true, message: "Menu Created", data: newMenu });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};



const getMenus = async (req, res) => {
  try {
    // Fetch all menus
    const menus = await Menu2.find();

    if (!menus || menus.length === 0) {
      return res
        .status(404)
        .json({ success: false, message: "No menus found" });
    }

    res.status(200).json({
      success: true,
      data: menus,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Update a menu by ID
const updateMenuById = async (req, res) => {
  try {
    const { id } = req.params;
    const updatedMenu = await Menu2.findByIdAndUpdate(id, req.body, {
      new: true,
    });

    if (!updatedMenu) {
      return res
        .status(404)
        .json({ success: false, message: "Menu not found" });
    }

    res
      .status(200)
      .json({ success: true, message: "Menu Updated", data: updatedMenu });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// Add a submenu to a menu
const addSubmenu = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      title,
      description,
      metaTitle,
      metaDescription,
      url,
      slug,
      dataCollection,
    } = req.body;

    const menu = await Menu2.findById(id);
    if (!menu) {
      return res
        .status(404)
        .json({ success: false, message: "Menu not found" });
    }

    // Ensure submenu is an array
    if (!Array.isArray(menu.submenus)) {
      menu.submenus = [];
    }

    const newSubmenu = {
      title,
      description,
      metaTitle,
      metaDescription,
      url,
      slug,
      dataCollection,
    };
    menu.submenus.push(newSubmenu); // Use submenu here
    const updatedMenu = await menu.save();

    res
      .status(201)
      .json({ success: true, message: "Submenu Added", data: updatedMenu });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// Delete a menu by ID
const deleteMenuById = async (req, res) => {
  try {
    const { id } = req.params;
    const deletedMenu = await Menu.findByIdAndDelete(id);

    if (!deletedMenu) {
      return res
        .status(404)
        .json({ success: false, message: "Menu not found" });
    }

    res.status(200).json({
      success: true,
      message: "Menu Deleted Successfully",
      data: deletedMenu,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// Delete a submenu by ID
const deleteSubmenuById = async (req, res) => {
  try {
    const { menuId, submenuId } = req.params;
    const menu = await Menu.findById(menuId);

    if (!menu) {
      return res
        .status(404)
        .json({ success: false, message: "Menu not found" });
    }

    // Filter out the submenu
    menu.submenus = menu.submenus.filter(
      (submenu) => submenu._id.toString() !== submenuId
    );
    await menu.save();

    res.status(200).json({
      success: true,
      message: "Submenu Deleted Successfully",
      data: menu,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

module.exports = {
  createMenu,
  getMenus,
  updateMenuById,
  deleteMenuById,
  addSubmenu,
  deleteSubmenuById, // Export the new delete submenu function
};
