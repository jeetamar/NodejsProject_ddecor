const User = require("../models/User");
const Shape = require("../models/Shape.js");

const createShape = async (req, res) => {
  try {
    const { ...others } = req.body;
    await Shape.create({
      ...others,
    });

    res.status(201).json({ success: true, message: "Shape Created" });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};
const getShapes = async (req, res) => {
  // console.log("Hello");
  try {
    const shapes = await Shape.find().sort({
      createdAt: -1,
    });

    res.status(201).json({
      success: true,
      data: shapes,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const updateShapesById = async (req, res) => {
  try {
    const { id } = req.params;
    const { name,slug} = req.body;

    const newShape = await Shape.findByIdAndUpdate(
      id,
      { name,slug},
      { new: true } // This option returns the updated document
    );

    if (!newShape) {
      return res
        .status(404)
        .json({ success: false, message: "Shape not found" });
    }

    res
      .status(200)
      .json({ success: true, message: "Shape Updated", data: newShape });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
};

const deleteShapesById = async (req, res) => {
  try {
    const { id } = req.params;

    const deletedShape = await Shape.findByIdAndDelete(id);

    res.status(201).json({
      success: true,
      message: "Shape Deleted Successfully",
      data: deletedShape,
    });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
};


// get singel shape
const getShapeById = async (req, res) => {
  const { id } = req.params; // Extract the ID from the request parameters

  try {
    const shape = await Shape.findById(id); // Find the shape by ID

    if (!shape) {
      return res
        .status(404)
        .json({ success: false, message: "Shape not found" });
    }

    res.status(200).json({ success: true, data: shape }); // Return the found shape
  } catch (error) {
    res.status(500).json({ success: false, message: error.message }); // Handle errors
  }
};

/*const getShapesName = async (req, res) => {
  try {
    const shapes = await Shape.find()
      .sort({
        createdAt: -1,
      })
      .select(["shapeName","slug"]);

    res.status(201).json({
      success: true,
      data: shapes,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};*/

// with custome limit
const getShapesName = async (req, res) => {
  try {
    // Get the limit from the query parameters, default to null (no limit)
    const limit = parseInt(req.query.limit) || null;

    const query = Shape.find()
      .sort({ createdAt: -1 })
      .select(["name", "slug"]);

    // If a limit is provided, apply it to the query
    if (limit) {
      query.limit(limit);
    }

    const shapes = await query;

    res.status(200).json({
      success: true,
      data: shapes,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};



module.exports = {
  createShape,
  getShapes,
  updateShapesById,
  deleteShapesById,
   getShapeById,
  getShapesName,
};
