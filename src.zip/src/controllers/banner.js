const Banners = require("../models/Banner");

const { DeleteObjectCommand } = require("@aws-sdk/client-s3");
const s3 = require("../config/s3");
// Initialize S3 client
// const s3 = new S3Client({ region: process.env.AWS_REGION });

const createBanner = async (req, res) => {
  try {
    const { cover, ...others } = req.body;

    await Banners.create({
      ...others,
      cover: {
        ...cover,
      },
    });

    res.status(201).json({ success: true, message: "Banner Created" });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

const updateBannerBySlug = async (req, res) => {
  try {
    const { slug } = req.params;
    const { cover, ...others } = req.body;

    await Banners.findOneAndUpdate(
      { slug },
      {
        ...others,
        cover: {
          ...cover,
        },
      },
      { new: true, runValidators: true }
    );

    res.status(201).json({ success: true, message: "Banner Updated" });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

const deleteBannersBySlug = async (req, res) => {
  try {
    const { slug } = req.params;

    // Find and delete banner by slug
    const banner = await Banners.findOneAndDelete({ slug });

    if (!banner) {
      return res.status(404).json({
        success: false,
        message: "Banner Not Found",
      });
    }

    // Prepare AWS S3 delete parameters
    const deleteParams = {
      Bucket: process.env.AWS_BUCKET_NAME, // Ensure you have your bucket name in environment variables
      Key: banner.cover.key, // Assuming banner.cover._id is the S3 object key
    };

    // Attempt to delete the cover file from S3
    try {
      await s3.send(new DeleteObjectCommand(deleteParams));
    } catch (fileError) {
      console.error("Error deleting cover file from S3:", fileError);
      return res.status(500).json({
        success: false,
        message: "Banner deleted, but failed to delete cover file from S3.",
      });
    }

    // Send success response
    res.status(200).json({
      success: true,
      message: "Banner Deleted Successfully",
    });
  } catch (error) {
    console.error("Error deleting banner:", error); // More detailed error logging
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};

const getBanners = async (req, res) => {
  // console.log("Hello");
  try {
    // const banners = await Banners.find().sort({
    //   createdAt: -1,
    // });
    const banners = await Banners.find();

    res.status(201).json({
      success: true,
      data: banners,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};



const getBannerBySlug = async (req, res) => {
  const { slug } = req.params;
  try {
    const banners = await Banners.findOne({ slug });

    res.status(201).json({
      success: true,
      data: banners,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = {
  createBanner,
  updateBannerBySlug,
  deleteBannersBySlug,
  getBanners,
  getBannerBySlug,
};
