const Products = require("../models/Product");
const Shop = require("../models/Shop");
const Category = require("../models/Category");
const Brand = require("../models/Brand");
const SubCategory = require("../models/SubCategory");



const Collection = require("../models/Collection");
const Size = require("../models/Sizes");
const Color = require("../models/Color");
const Shape = require("../models/Shape");
const Pattern = require("../models/Pattern");
const Room = require("../models/Room");




const Search = async (req, res) => {
  try {
    const { query, shop, subCategory, category } = req.body;
    const currenctShop = shop ? await Shop.findById(shop).select(["_id"]) : "";
    const catId = category
      ? await Category.findById(category).select(["_id"])
      : "";
    const subCatId = subCategory
      ? await SubCategory.findById(subCategory).select(["_id"])
      : "";
    console.log(subCatId);
    const products = await Products.aggregate([
      {
        $match: {
          name: { $regex: query || "", $options: "i" },
          ...(currenctShop && {
            shop: currenctShop._id,
          }),
          ...(catId && {
            category: catId._id,
          }),
          ...(catId &&
            subCatId && {
              subCategory: subCatId._id,
            }),

          status: { $ne: "disabled" },
        },
      },
      {
        $lookup: {
          from: "categories", // Assuming 'categories' is the name of your Category model collection
          localField: "category", // Field in the Products model
          foreignField: "_id", // Field in the Category model
          as: "categoryData",
        },
      },
      {
        $addFields: {
          category: { $arrayElemAt: ["$categoryData.name", 0] }, // Extracting the title from the categoryData array

          image: { $arrayElemAt: ["$images", 0] },
        },
      },

      {
        $project: {
          image: { url: "$image.url", blurDataURL: "$image.blurDataURL" },
          name: 1,
          priceSale: 1,
          slug: 1,
          _id: 1,
          category: 1, // Including the category field with only the title
        },
      },

      {
        $limit: 10,
      },
    ]);

    return res.status(200).json({
      success: true,
      products,
    });
  } catch (error) {
    return res.status(400).json({ success: false, message: error.message });
  }
};

const getFilters = async (req, res) => {
  try {
    await SubCategory.findOne();
    const categories = await Category.find()
      .select(["_id", "name", "slug", "subCategories"])
      .populate({
        path: "subCategories",
        select: ["_id", "name", "slug"],
      });

    const shops = await Shop.find().select(["_id", "title", "slug"]);

    return res.status(200).json({
      success: true,
      categories,
      shops,
    });
  } catch (error) {
    return res.status(400).json({ success: false, message: error.message });
  }
};

// search products - for user side
const searchProducts = async (req, res) => {
  try {
    // Check if query is provided and convert it to lowercase
    const query = req.query.q && req.query.q.toLowerCase();

    // Check if query is provided
    if (!query || query.trim() === "") {
      return res.status(200).json({
        success: false,
        message: "You did not search for any product.",
        data: [],
      });
    }

    // Fetch collections and categories based on the query
    const collections = await Collection.find({
      name: { $regex: query, $options: "i" },
    });
    const categories = await Category.find({
      name: { $regex: query, $options: "i" },
    });

    // Convert ObjectId to string
    const collectionIds = collections.map((collection) =>
      collection._id.toString()
    );
    const categoryIds = categories.map((category) => category._id.toString());

    // Fetch products from the database
    const products = await Products.find();

    const filteredProducts = products.filter((product) => {
      return (
        (product.name && product.name.toLowerCase().includes(query)) ||
        (product.colors && product.colors.toLowerCase().includes(query)) ||
        (product.size && product.size.toLowerCase().includes(query)) ||
        (product.collection &&
          collectionIds.includes(product.collection.toString())) ||
        (product.category &&
          categoryIds.includes(product.category.toString())) ||
        (product.price && product.price.toString().includes(query))
      );
    });

    // Make sure filteredProducts is not empty
    if (filteredProducts.length === 0) {
      return res.status(200).json({
        success: true,
        data: [],
        count: 0,
      });
    }

    // Set up the structures for fetching additional data
    const colorsPromises = filteredProducts.map((product) =>
      Color.find({ slug: { $in: product.colors } })
    );
    const sizesPromises = filteredProducts.map((product) =>
      Size.find({ slug: { $in: product.sizes.map((size) => size.size) } })
    );
    const roomsPromises = filteredProducts.map((product) =>
      Room.find({ slug: { $in: product.rooms } })
    );
    const patternsPromises = filteredProducts.map((product) =>
      Pattern.find({ slug: { $in: product.patterns } })
    );
    const shapesPromises = filteredProducts.map((product) =>
      Shape.find({ slug: { $in: product.shapes } })
    );

    // Await all promises
    const colors = await Promise.all(colorsPromises);
    const sizesData = await Promise.all(sizesPromises);
    const rooms = await Promise.all(roomsPromises);
    const patterns = await Promise.all(patternsPromises);
    const shapes = await Promise.all(shapesPromises);

    // Construct the response
    const response = filteredProducts.map((product, index) => {
      const sizeMap = sizesData[index].reduce((acc, size) => {
        acc[size.slug] = size;
        return acc;
      }, {});

      const sizes = product.sizes
        .map((item) => {
          const sizeInfo = sizeMap[item.size];
          return sizeInfo
            ? {
                _id: sizeInfo._id,
                name: sizeInfo.name,
                slug: item.size,
                price: item.price,
              }
            : null;
        })
        .filter(Boolean);
        
        
        // Calculate the lowest and highest price from sizePrices
      const prices = sizes
        .map((sizes) => sizes.price)
        .filter((price) => price !== null);

      let priceRange;

      if (prices.length === 0) {
        priceRange = { lowest: null, highest: null };
      } else if (prices.length === 1) {
        priceRange = { price: prices[0] }; // Show only one price
      } else {
        priceRange = {
          lowest: Math.min(...prices),
          highest: Math.max(...prices),
        };
      }
    //   console.log(priceRange);
        

      return {
        ...product.toObject(),
        priceRange,
        colors: colors[index],
        sizes,
        shapes: shapes[index],
        patterns: patterns[index],
        rooms: rooms[index],
      };
    });

    return res.status(200).json({
      success: true,
      data: response,
      count: response.length,
    });
  } catch (error) {
    console.error("Error searching products:", error);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
};




// Suggestion API
const getSuggestions = async (req, res) => {
  try {
    const query = req.query.q;

    // Check if query is provided
    if (!query || query.trim() === "") {
      return res.status(200).json({
        success: false,
        message: "You did not search for any product.",
        data: [],
      });
    }

    const lowerCaseQuery = query.toLowerCase();

    // Fetch collections and categories based on the query
    const collections = await Collection.find({
      name: { $regex: lowerCaseQuery, $options: "i" },
    }).limit(5);

    const categories = await Category.find({
      name: { $regex: lowerCaseQuery, $options: "i" },
    }).limit(5);

    // Fetch products based on the query
    const products = await Products.find({
      name: { $regex: lowerCaseQuery, $options: "i" },
    }).limit(5);

    // Fetch sizes, colors, shapes, patterns, and rooms based on the query
    const sizes = await Size.find({
      name: { $regex: lowerCaseQuery, $options: "i" },
    }).limit(5);

    const colors = await Color.find({
      name: { $regex: lowerCaseQuery, $options: "i" },
    }).limit(5);

    const shapes = await Shape.find({
      name: { $regex: lowerCaseQuery, $options: "i" },
    }).limit(5);

    const patterns = await Pattern.find({
      name: { $regex: lowerCaseQuery, $options: "i" },
    }).limit(5);

    const rooms = await Room.find({
      name: { $regex: lowerCaseQuery, $options: "i" },
    }).limit(5);

    // Combine all suggestions into a single array
    const suggestions = [
      ...collections.map((collection) => ({
        type: "collection",
        name: collection.name,
        slug: collection.slug,
      })),
      ...categories.map((category) => ({
        type: "category",
        name: category.name,
        slug: category.slug,
      })),
      ...products.map((product) => ({
        type: "product",
        name: product.name,
        slug: product.slug,
      })),
      ...sizes.map((size) => ({
        type: "size",
        name: size.name,
        slug: size.slug,
      })),
      ...colors.map((color) => ({
        type: "color",
        name: color.name,
        slug: color.slug,
      })),
      ...shapes.map((shape) => ({
        type: "shape",
        name: shape.name,
        slug: shape.slug,
      })),
      ...patterns.map((pattern) => ({
        type: "pattern",
        name: pattern.name,
        slug: pattern.slug,
      })),
      ...rooms.map((room) => ({
        type: "room",
        name: room.name,
        slug: room.slug,
      })),
    ];

    // Remove duplicates from suggestions
    const uniqueSuggestions = Array.from(
      new Set(suggestions.map((s) => JSON.stringify(s)))
    ).map((s) => JSON.parse(s));

    res.status(200).json({
      success: true,
      data: uniqueSuggestions,
    });
  } catch (error) {
    console.error("Error fetching suggestions:", error);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
};


module.exports = { Search, getFilters,searchProducts, getSuggestions,  };
