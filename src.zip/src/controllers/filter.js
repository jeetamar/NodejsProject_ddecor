const Size = require("../models/Sizes");
const Color = require("../models/Color");
const Shape = require("../models/Shape");
const Pattern = require("../models/Pattern");
const Collection = require("../models/Collection");
const Room = require("../models/Room");
const Product = require("../models/Product");
const Category = require("../models/Category");

/*const getFilteredProducts = async (req, res) => {
  console.log("Fetching filtered products");
  try {
    const query = req.query;

    // Prepare the filter object
    const filter = {
      status: { $ne: "disabled" }, // Only include products that are not disabled
    };

    // Add filters based on query params if they exist
    if (query.size) {
      filter.sizes = { $in: query.size.split("_") };
    }

    if (query.color) {
      filter.colors = { $in: query.color.split("_") };
    }

    if (query.shape) {
      filter.shapes = { $in: query.shape.split("_") };
    }

    if (query.pattern) {
      filter.patterns = { $in: query.pattern.split("_") };
    }

    // if (query.collection) {
    //   const collection = await Collection.findOne({ slug: query.collection });
    //   if (!collection) {
    //     return res.status(404).json({
    //       success: false,
    //       message: "Collection not found",
    //     });
    //   }
    //   filter.collection = collection._id;
    // }

    // if (query.category) {
    //   const category = await Category.findOne({ slug: query.category });
    //   if (!category) {
    //     return res.status(404).json({
    //       success: false,
    //       message: "Category not found",
    //     });
    //   }
    //   filter.category = category._id; // Only add if the category is found
    // }
    
    
    // new logic
    if (query.collection) {
      const collections = query.collection.split("_");
      const foundCollections = await Collection.find({
        slug: { $in: collections },
      });

      if (foundCollections.length === 0) {
        return res.status(404).json({
          success: false,
          message: "Collections not found",
        });
      }

      filter.collection = { $in: foundCollections.map((c) => c._id) }; // Use _id of found collections
    }

    if (query.category) {
      const categories = query.category.split("_");
      const foundCategories = await Category.find({
        slug: { $in: categories },
      });

      if (foundCategories.length === 0) {
        return res.status(404).json({
          success: false,
          message: "Categories not found",
        });
      }

      filter.category = { $in: foundCategories.map((c) => c._id) }; // Use _id of found categories
    }

    

    // Log the filter object
    console.log("Filter Object:", filter);

    // Pagination parameters
    const page = Number(query.page) || 1;
    const limit = Number(query.limit) || 12;
    const skip = (page - 1) * limit;

    // Count total products matching the filter
    const totalProducts = await Product.countDocuments(filter);

    // Fetch the filtered products
    const products = await Product.find(filter)
      .skip(skip)
      .limit(limit);
    //   .select("name priceSale colors images sizes shapes patterns");

    res.status(200).json({
      success: true,
      data: products,
      total: totalProducts,
      count: Math.ceil(totalProducts / limit),
    });
  } catch (error) {
    console.error("Error occurred:", error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
      error: error.message,
    });
  }
};*/


/*const getFilteredProducts = async (req, res) => {
  // console.log("Fetching filtered products");
  try {
    const query = req.query;
    const slug = req.params.slug;

    // Prepare the filter object
    // const filter = {
    //   status: { $ne: "disabled" }, // Only include products that are not disabled
    // };
    let filter = {
      status: { $ne: "disabled" }, // Only include products that are not disabled
    };

    if (slug === "rugs") {
      filter = {};
    }
    
    if (slug === "collection") {
      filter = {};
    }
    if (slug === "colors") {
      filter = {};
    }
    if (slug === "new-arrival") {
      filter.isArrival = true;
    }
    if (slug === "best-seller") {
      filter.isBestSeller = true;
    }
    if (slug === "all-rugs") {
      filter = {};
    }
    
    
    
    
    // Initialize arrays to hold matched IDs
    const matchedSizes = [];
    const matchedColors = [];
    const matchedShapes = [];
    const matchedPatterns = [];
    const matchedRooms = [];
    const matchCollection = [];
    const matchCategory = [];

    // Check slug in Size
    const sizeMatch = await Size.findOne({ slug });
    // console.log(sizeMatch);
    if (sizeMatch) {
      matchedSizes.push(sizeMatch.slug); // Store slug for sizes
    }

    // Check slug in Color
    const colorMatch = await Color.findOne({ slug });
    if (colorMatch) {
      matchedColors.push(colorMatch.slug); // Store slug for colors
    }

    // Check slug in Shape
    const shapeMatch = await Shape.findOne({ slug });
    if (shapeMatch) {
      matchedShapes.push(shapeMatch.slug); // Store slug for shapes
    }

    // Check slug in Pattern
    const patternMatch = await Pattern.findOne({ slug });
    if (patternMatch) {
      matchedPatterns.push(patternMatch.slug); // Store slug for patterns
    }

    // Check slug in Room
    const roomMatch = await Room.findOne({ slug });
    if (roomMatch) {
      matchedRooms.push(roomMatch.slug); // Store slug for rooms
    }

    //check slug in collection
    const collectionMatch = await Collection.findOne({ slug });
    if (collectionMatch) {
      matchCollection.push(collectionMatch._id); // Store id for collections
    }

    //check if slug in category
    const categoryMatch = await Category.findOne({ slug });
    if (categoryMatch) {
      matchCategory.push(categoryMatch._id); // Store id for categories
    }

    // Build filter based on matched IDs
    if (matchedSizes.length > 0) {
      filter.sizes = { $in: matchedSizes };
    }
    if (matchedColors.length > 0) {
      filter.colors = { $in: matchedColors };
    }
    if (matchedShapes.length > 0) {
      filter.shapes = { $in: matchedShapes };
    }
    if (matchedPatterns.length > 0) {
      filter.patterns = { $in: matchedPatterns };
    }
    if (matchedRooms.length > 0) {
      filter.rooms = { $in: matchedRooms };
    }
    if (matchCollection.length > 0) {
      filter.collection = { $in: matchCollection };
    }
    if (matchCategory.length > 0) {
      filter.category = { $in: matchCategory };
    }


    






    // Add filters based on query params if they exist
    if (query.size) {
      filter.sizes = { $in: query.size.split("_") };
    }

    if (query.color) {
      filter.colors = { $in: query.color.split("_") };
    }

    if (query.shape) {
      filter.shapes = { $in: query.shape.split("_") };
    }

    if (query.pattern) {
      filter.patterns = { $in: query.pattern.split("_") };
    }
    
    
    // rugs filter 
    if (query.rugs) {
      if (query.rugs === "collection") {
        // Fetch all collections
        const collections = await Collection.find();

        if (collections.length > 0) {
          // If collections exist, filter products based on their IDs
          filter.collection = { $in: collections.map((c) => c._id) }; // Assuming products have a 'collectionId' field
        } else {
          // If no collections found, you might want to handle it
          return res.status(404).json({
            success: false,
            message: "No collections found",
          });
        }
      } else if (query.rugs === "new-arrival") {
        filter.isArrival = true;
      } else if (query.rugs === "best-seller") {
        filter.isBestSeller = true;
      } else if (query.rugs === "colors") {
        // Fetch all colors
        const colors = await Color.find();

        if (colors.length > 0) {
          // If colors exist, filter products based on their slugs
          filter.colors = { $in: colors.map((c) => c.slug) }; // Assuming products have a 'colors' field storing slugs
        } else {
          return res.status(404).json({
            success: false,
            message: "No colors found",
          });
        }
      } else if (query.rugs === "all-rugs") {
        filter = {};
      }
    }
    
    
    // Log the filter object

    if (query.collection) {
      const collections = query.collection.split("_");
      const foundCollections = await Collection.find({
        slug: { $in: collections },
      });

      if (foundCollections.length === 0) {
        return res.status(404).json({
          success: false,
          message: "Collections not found",
        });
      }

      filter.collection = { $in: foundCollections.map((c) => c._id) }; // Use _id of found collections
    }

    if (query.category) {
      const categories = query.category.split("_");
      const foundCategories = await Category.find({
        slug: { $in: categories },
      });

      if (foundCategories.length === 0) {
        return res.status(404).json({
          success: false,
          message: "Categories not found",
        });
      }

      filter.category = { $in: foundCategories.map((c) => c._id) }; // Use _id of found categories
    }

    // console.log("Filter Object:", filter);

    // Pagination parameters
    const page = Number(query.page) || 1;
    const limit = Number(query.limit) || 12;
    const skip = (page - 1) * limit;

    // Count total products matching the filter
    const totalProducts = await Product.countDocuments(filter);

    // Fetch the filtered products
    const products = await Product.find(filter)
      .skip(skip)
      .limit(limit);
    // .select("name priceSale colors images sizes shapes patterns");

    // Initialize an array to hold detailed products
    const detailedProducts = await Promise.all(
      products.map(async (product) => {
        // Fetch associated colors, sizes, shapes, rooms, and patterns
        const colors =
          (await Color.find({ slug: { $in: product.colors } })) || [];
        const sizes = (await Size.find({ slug: { $in: product.sizes } })) || [];
        const rooms = (await Room.find({ slug: { $in: product.rooms } })) || [];
        const patterns =
          (await Pattern.find({ slug: { $in: product.patterns } })) || [];
        const shapes =
          (await Shape.find({ slug: { $in: product.shapes } })) || [];

        // Return product with details and associated attributes
        return {
          ...product.toObject(), // Convert to plain object
          colors: colors.length ? colors : [],
          sizes: sizes.length ? sizes : [],
          rooms: rooms.length ? rooms : [],
          patterns: patterns.length ? patterns : [],
          shapes: shapes.length ? shapes : [],
        };
      })
    );

    res.status(200).json({
      success: true,
      data: detailedProducts,
      total: totalProducts,
      count: Math.ceil(totalProducts / limit),
    });
  } catch (error) {
    console.error("Error occurred:", error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
      error: error.message,
    });
  }
};*/




const getFilteredProducts = async (req, res) => {
  // console.log("Fetching filtered products");
  try {
    const query = req.query;
    const slug = req.params.slug;

    // Prepare the filter object
    let filter = {
      status: { $ne: "disabled" }, // Only include products that are not disabled
    };
    
    
    
    if (slug) {
      // Try to find the product by slug if it's a specific product slug
      const productMatch = await Product.findOne({ slug });

      if (productMatch) {
        // If a product with that slug is found, filter by this product only
        filter = { _id: productMatch._id }; // Use the product's ID to match it exclusively
      }
    }
    
    

    if (slug === "rugs") {
      filter = {};
    }
    if (slug === "collection") {
      filter = {};
    }
    if (slug === "colors") {
      filter = {};
    }
    if (slug === "new-arrival") {
      filter.isArrival = true;
    }
    if (slug === "best-seller") {
      filter.isBestSeller = true;
    }
    if (slug === "all-rugs") {
      filter = {};
    }

    // Initialize arrays to hold matched IDs
    const matchedSizes = [];
    const matchedColors = [];
    const matchedShapes = [];
    const matchedPatterns = [];
    const matchedRooms = [];
    const matchCollection = [];
    const matchCategory = [];
    // const matchNewArrival = [];
    // const matchBestSeller = [];
    // const matchAllCollection = [];
    // const matchAllcolors = [];
    // const constAllrugs = [];

    // Check slug in Size
    const sizeMatch = await Size.findOne({ slug });
    // console.log(sizeMatch);
    if (sizeMatch) {
      matchedSizes.push(sizeMatch.slug); // Store slug for sizes
    }

    // Check slug in Color
    const colorMatch = await Color.findOne({ slug });
    if (colorMatch) {
      matchedColors.push(colorMatch.slug); // Store slug for colors
    }

    // Check slug in Shape
    const shapeMatch = await Shape.findOne({ slug });
    if (shapeMatch) {
      matchedShapes.push(shapeMatch.slug); // Store slug for shapes
    }

    // Check slug in Pattern
    const patternMatch = await Pattern.findOne({ slug });
    if (patternMatch) {
      matchedPatterns.push(patternMatch.slug); // Store slug for patterns
    }

    // Check slug in Room
    const roomMatch = await Room.findOne({ slug });
    if (roomMatch) {
      matchedRooms.push(roomMatch.slug); // Store slug for rooms
    }

    //check slug in collection
    const collectionMatch = await Collection.findOne({ slug });
    if (collectionMatch) {
      matchCollection.push(collectionMatch._id); // Store id for collections
    }

    //check if slug in category
    const categoryMatch = await Category.findOne({ slug });
    if (categoryMatch) {
      matchCategory.push(categoryMatch._id); // Store id for categories
    }

    // Build filter based on matched IDs
    // if (matchedSizes.length > 0) {
    //   filter.sizes = { $in: matchedSizes };
    // }
    // Build filter based on matched IDs
    if (matchedSizes.length > 0) {
      filter.sizes = { $elemMatch: { size: { $in: matchedSizes } } };
    }
    if (matchedColors.length > 0) {
      filter.colors = { $in: matchedColors };
    }
    if (matchedShapes.length > 0) {
      filter.shapes = { $in: matchedShapes };
    }
    if (matchedPatterns.length > 0) {
      filter.patterns = { $in: matchedPatterns };
    }
    if (matchedRooms.length > 0) {
      filter.rooms = { $in: matchedRooms };
    }
    if (matchCollection.length > 0) {
      filter.collection = { $in: matchCollection };
    }
    if (matchCategory.length > 0) {
      filter.category = { $in: matchCategory };
    }

    // Add filters based on query params if they exist
    // if (query.size) {
    //   filter.sizes = { $in: query.size.split("_") };
    // }

    // Handle query size if provided
    if (query.size) {
      filter.sizes = {
        $elemMatch: {
          size: { $in: query.size.split("_") },
        },
      };
    }

    if (query.color) {
      filter.colors = { $in: query.color.split("_") };
    }

    if (query.shape) {
      filter.shapes = { $in: query.shape.split("_") };
    }

    if (query.pattern) {
      filter.patterns = { $in: query.pattern.split("_") };
    }
    
    // price Range Filter
    
     if (query.priceRange) {
      const priceRanges = query.priceRange.split("_"); // Split by underscore for multiple ranges
      const priceConditions = []; // Initialize an array to hold the conditions

      priceRanges.forEach((range) => {
        if (range.startsWith("under-")) {
          const maxPrice = Number(range.split("-")[1]);
          priceConditions.push({ price: { $lt: maxPrice } }); // Condition for prices less than maxPrice
        } else if (range.startsWith("above-")) {
          const minPrice = Number(range.split("-")[1]);
          priceConditions.push({ price: { $gt: minPrice } }); // Condition for prices greater than minPrice
        } else {
          // Handle the case for ranges like 2000-5000
          const [minPrice, maxPrice] = range.split("-").map(Number);
          priceConditions.push({ price: { $gte: minPrice, $lte: maxPrice } }); // Condition for prices within the specified range
        }
      });

      // Combine the conditions using $or
      if (priceConditions.length > 0) {
        filter.$or = priceConditions; // Use $or directly on the filter object
      }
    }
    
    
    
    

    // rugs filter
    // if (query.rugs) {
    //   if (query.rugs === "isArrival") {
    //     filter.isArrival = true;
    //   } else if (query.rugs === "isBestSeller") {
    //     filter.isBestSeller = true;
    //   }
    // }

    if (query.rugs) {
      if (query.rugs === "collection") {
        // Fetch all collections
        const collections = await Collection.find();

        if (collections.length > 0) {
          // If collections exist, filter products based on their IDs
          filter.collection = { $in: collections.map((c) => c._id) }; //  products have a 'collectionId' field
        } else {
          // If no collections found, you might want to handle it
          return res.status(404).json({
            success: false,
            message: "No collections found",
          });
        }
      } else if (query.rugs === "new-arrival") {
        filter.isArrival = true;
      } else if (query.rugs === "best-seller") {
        filter.isBestSeller = true;
      } else if (query.rugs === "colors") {
        // Fetch all colors
        const colors = await Color.find();

        if (colors.length > 0) {
          // If colors exist, filter products based on their slugs
          filter.colors = { $in: colors.map((c) => c.slug) }; //  products have a 'colors' field storing slugs
        } else {
          return res.status(404).json({
            success: false,
            message: "No colors found",
          });
        }
      } else if (query.rugs === "all-rugs") {
        filter = {};
      }
    }

    // Log the filter object

    if (query.collection) {
      const collections = query.collection.split("_");
      const foundCollections = await Collection.find({
        slug: { $in: collections },
      });

      if (foundCollections.length === 0) {
        return res.status(404).json({
          success: false,
          message: "Collections not found",
        });
      }

      filter.collection = { $in: foundCollections.map((c) => c._id) }; // Use _id of found collections
    }

    if (query.category) {
      const categories = query.category.split("_");
      const foundCategories = await Category.find({
        slug: { $in: categories },
      });

      if (foundCategories.length === 0) {
        return res.status(404).json({
          success: false,
          message: "Categories not found",
        });
      }

      filter.category = { $in: foundCategories.map((c) => c._id) }; // Use _id of found categories
    }

    // console.log("Filter Object:", filter);

    // Pagination parameters
    const page = Number(query.page) || 1;
    const limit = Number(query.limit) || 12;
    const skip = (page - 1) * limit;

    // Count total products matching the filter
    const totalProducts = await Product.countDocuments(filter);

    // Fetch the filtered products
    const products = await Product.find(filter)
      .skip(skip)
      .limit(limit);
    // .select("name priceSale colors images sizes shapes patterns");

    // Initialize an array to hold detailed products
    const detailedProducts = await Promise.all(
      products.map(async (product) => {
        // Fetch associated colors, sizes, shapes, rooms, and patterns
        const colors =
          (await Color.find({ slug: { $in: product.colors } })) || [];
        const sizes =
          (await Size.find({
            slug: { $in: product.sizes.map((size) => size.size) },
          })) || [];
        const rooms = (await Room.find({ slug: { $in: product.rooms } })) || [];
        const patterns =
          (await Pattern.find({ slug: { $in: product.patterns } })) || [];
        const shapes =
          (await Shape.find({ slug: { $in: product.shapes } })) || [];
          
          
          // Create an array of sizes with their corresponding prices
        const sizePrices = sizes.map((size) => {
          const productSize = product.sizes.find((s) => s.size === size.slug);
          return {
            size: size.slug,
            price: productSize ? productSize.price : null, // Assume price is stored in product.sizes
          };
        });
          
          // Calculate the lowest and highest price from sizePrices
        const prices = sizePrices
          .map((sizePrice) => sizePrice.price)
          .filter((price) => price !== null);

        let priceRange;

        if (prices.length === 0) {
          priceRange = { lowest: null, highest: null };
        } else if (prices.length === 1) {
          priceRange = { price: prices[0] }; // Show only one price
        } else {
          priceRange = {
            lowest: Math.min(...prices),
            highest: Math.max(...prices),
          };
        }

        // Return product with details and associated attributes
        return {
          ...product.toObject(), // Convert to plain object
          priceRange,
          colors: colors.length ? colors : [],
          sizes: sizes.length ? sizes : [],
          rooms: rooms.length ? rooms : [],
          patterns: patterns.length ? patterns : [],
          shapes: shapes.length ? shapes : [],
        };
      })
    );
    
    //   let lowestPrice = Infinity;
    // let highestPrice = -Infinity;

    // // Loop through detailedProducts and determine the global lowest and highest price
    // detailedProducts.forEach((product) => {
    //   if (product.priceRange) {
    //     if (product.priceRange.lowest < lowestPrice) {
    //       lowestPrice = product.priceRange.lowest;
    //     }
    //     if (product.priceRange.highest > highestPrice) {
    //       highestPrice = product.priceRange.highest;
    //     }
    //   }
    // });
    
    
    let lowestPrice = Infinity;
    let highestPrice = -Infinity;
    
    // Loop through detailedProducts and determine the global lowest and highest price
    detailedProducts.forEach(product => {
      if (product.priceRange) {
        // If priceRange has lowest and highest values (range)
        if (product.priceRange.lowest !== undefined && product.priceRange.highest !== undefined) {
          if (product.priceRange.lowest < lowestPrice) {
            lowestPrice = product.priceRange.lowest;
          }
          if (product.priceRange.highest > highestPrice) {
            highestPrice = product.priceRange.highest;
          }
        }
        // If priceRange has only a single price (no range)
        else if (product.priceRange.price !== undefined) {
          if (product.priceRange.price < lowestPrice) {
            lowestPrice = product.priceRange.price;
          }
          if (product.priceRange.price > highestPrice) {
            highestPrice = product.priceRange.price;
          }
        }
      }
    });
    
    // Ensure that the lowest and highest price are set to valid numbers (in case there are no valid products)
    if (lowestPrice === Infinity) lowestPrice = 0;
    if (highestPrice === -Infinity) highestPrice = 0;

    res.status(200).json({
      success: true,
      data: detailedProducts,
      total: totalProducts,
      count: Math.ceil(totalProducts / limit),
       Range: {
        lowest: lowestPrice,
        highest: highestPrice,
      },
    });
  } catch (error) {
    console.error("Error occurred:", error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
      error: error.message,
    });
  }
};



// Export the function
module.exports = {
  getFilteredProducts,
};
