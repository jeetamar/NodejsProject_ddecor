const Colors = require("../models/Color");
const Size = require("../models/Sizes");
const Shape = require("../models/Shape");
const Pattern = require("../models/Pattern");
const Room = require("../models/Room");

const getMasterData = async (req, res) => {
  try {
    const sizes = await Size.find()
      .sort({ createdAt: -1 })
      .limit(10);
    const colors = await Colors.find()
      .sort({ createdAt: -1 })
      .limit(10);
    const shapes = await Shape.find()
      .sort({ createdAt: -1 })
      .limit(10);
    const patterns = await Pattern.find()
      .sort({ createdAt: -1 })
      .limit(10);
    const rooms = await Room.find()
      .sort({ createdAt: -1 })
      .limit(10);

    res.status(200).json({
      success: true,
      data: {
        sizes,
        colors,
        shapes,
        patterns,
        rooms,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = {
  getMasterData,
};
