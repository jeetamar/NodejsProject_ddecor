
//

const Stores = require("../models/StoreLocator"); // Assuming the model file is named StoreLocator.js
const csv = require("csv-parser");
const fs = require("fs");
const path = require("path");


// Create a new store
const CreateStores = async (req, res) => {
  try {
    const {
      code,
      name,
      addressLine1,
      addressLine2,
      addressLine3,
      addressLine4,
      city,
      state,
      postalCode,
      latitude,
      longitude,
      googleMapLink,
    } = req.body;

    // Check if a store already exists with the same name, address, and postalCode
    const existingStore = await Stores.findOne({
      $or: [
        {
          code,
          name,
          addressLine1,
          addressLine2,
          addressLine3,
          addressLine4,
          city,
          state,
          postalCode,
        },
      ],
    });

    if (existingStore) {
      return res.status(400).json({
        success: false,
        message: "Store already exists with the same details",
      });
    }

    // Create a new store if no store exists with the same details
    const newStore = await Stores.create({
      code,
      name,
      addressLine1,
      addressLine2,
      addressLine3,
      addressLine4,
      city,
      state,
      postalCode,
      latitude,
      longitude,
      googleMapLink,
      location: { type: "Point", coordinates: [longitude, latitude] }, // GeoJSON format
    });

    // Send success response
    res.status(201).json({
      success: true,
      message: "Store Created",
      data: newStore,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message,
    });
  }
};

// Get all stores
const getStores = async (req, res) => {
  try {
    const stores = await Stores.find().sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      data: stores,
      count:stores.length,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Search stores by dynamic criteria
/*const getStorebySeach = async (req, res) => {
  try {
    // Get all search parameters from the query
    const {
      code,
      name,
      addressLine1,
      addressLine2,
      city,
      state,
      postalCode,
    } = req.query;

    // Build the search query object dynamically
    let searchQuery = {};

    // Only add the field to the query if it's provided
    if (code) searchQuery.code = { $regex: code, $options: "i" }; // case-insensitive search
    if (name) searchQuery.name = { $regex: name, $options: "i" };
    if (addressLine1)
      searchQuery.addressLine1 = { $regex: addressLine1, $options: "i" };
    if (addressLine2)
      searchQuery.addressLine2 = { $regex: addressLine2, $options: "i" };
    if (city) searchQuery.city = { $regex: city, $options: "i" };
    if (state) searchQuery.state = { $regex: state, $options: "i" };
    if (postalCode)
      searchQuery.postalCode = { $regex: postalCode, $options: "i" };

    // Find stores based on the constructed search query
    const stores = await Stores.find(searchQuery).sort({ createdAt: -1 });

    // If no stores are found, return a 404 message
    if (stores.length === 0) {
      return res.status(404).json({
        success: false,
        message: "No stores found matching the search criteria",
      });
    }

    // Return the matching stores
    return res.status(200).json({
      success: true,
      data: stores,
      count: stores.length,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};*/


const getStorebySeach = async (req, res) => {
  try {
    // Get all search parameters from the query
    const {
        slug,
    //   code,
    //   name,
    //   addressLine1,
    //   addressLine2,
    //   city,
    //   state,
    //   postalCode,
      latitude,
      longitude,
    } = req.query;

    // // Build the search query object dynamically
    // let searchQuery = {};

    // // Add filters for non-geospatial fields if provided
    // if (code) searchQuery.code = { $regex: code, $options: "i" }; // case-insensitive search
    // if (name) searchQuery.name = { $regex: name, $options: "i" };
    // if (addressLine1)
    //   searchQuery.addressLine1 = { $regex: addressLine1, $options: "i" };
    // if (addressLine2)
    //   searchQuery.addressLine2 = { $regex: addressLine2, $options: "i" };
    // if (city) searchQuery.city = { $regex: city, $options: "i" };
    // if (state) searchQuery.state = { $regex: state, $options: "i" };
    // if (postalCode)
    //   searchQuery.postalCode = { $regex: postalCode, $options: "i" };


    
    // Build the search query object dynamically
    let searchQuery = {};

    // If a slug is provided, apply it to multiple fields
    if (slug) {
      // We are matching the slug across multiple fields using regex (case insensitive)
      searchQuery = {
        $or: [
          { name: { $regex: slug, $options: "i" } }, // Search in name
          { addressLine1: { $regex: slug, $options: "i" } }, // Search in addressLine1
          { addressLine2: { $regex: slug, $options: "i" } }, // Search in addressLine2
          { addressLine3: { $regex: slug, $options: "i" } }, // Search in addressLine3
          { city: { $regex: slug, $options: "i" } }, // Search in city
          { state: { $regex: slug, $options: "i" } }, // Search in state
          { postalCode: { $regex: slug, $options: "i" } }, // Search in postalCode
        ],
      };
    }



    // If latitude and longitude are provided, we perform a geospatial search
    if (latitude && longitude) {
      const lat = parseFloat(latitude);
      const lon = parseFloat(longitude);

      // First, try to find an exact match using latitude and longitude (within 1 meter)
      const exactMatchStore = await Stores.findOne({
        location: {
          $near: {
            $geometry: {
              type: "Point",
              coordinates: [lon, lat], // longitude, latitude
            },
            $maxDistance: 3000000, // Very small maxDistance for exact match (in meters)
          },
        },
      });

      // If an exact match is found, return it
      if (exactMatchStore) {
        return res.status(200).json({
          success: true,
          data: [exactMatchStore], // Return an array with the exact match
        });
      }

      // If no exact match is found, return the nearest stores (within 20 km radius)
      searchQuery.location = {
        $near: {
          $geometry: {
            type: "Point",
            coordinates: [lon, lat], // longitude, latitude
          },
          $maxDistance: 3000000, // 20 kilometers max distance
        },
      };
    }

    // Find stores based on the constructed search query, either geospatial or by other fields
    const stores = await Stores.find(searchQuery).sort({ createdAt: -1 });

    // If no stores are found, return a 404 message
    if (stores.length === 0) {
      return res.status(200).json({
        success: false,
        message: "No stores found matching the search criteria",
      });
    }

    // Return the matching stores
    return res.status(200).json({
      success: true,
      data: stores,
      count: stores.length,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};



// Update store by ID
const updateStoresById = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      code,
      name,
      addressLine1,
      addressLine2,
      addressLine3,
      addressLine4,
      city,
      state,
      postalCode,
      latitude,
      longitude,
      googleMapLink,
    } = req.body;

    // Ensure that at least one field is provided
    if (
      !code &&
      !name &&
      !addressLine1 &&
      !addressLine2 &&
      !addressLine3 &&
      !addressLine4 &&
      !city &&
      !state &&
      !postalCode &&
      !latitude &&
      !longitude &&
      !googleMapLink
    ) {
      return res.status(400).json({
        success: false,
        message: "At least one field must be provided for update",
      });
    }

    const updateFields = {};

    if (code) updateFields.code = code;
    if (name) updateFields.name = name;
    if (addressLine1) updateFields.addressLine1 = addressLine1;
    if (addressLine2) updateFields.addressLine2 = addressLine2;
    if (addressLine3) updateFields.addressLine3 = addressLine3;
    if (addressLine4) updateFields.addressLine4 = addressLine4;
    if (city) updateFields.city = city;
    if (state) updateFields.state = state;
    if (postalCode) updateFields.postalCode = postalCode;

    if (latitude && longitude) {
      if (isNaN(latitude) || isNaN(longitude)) {
        return res.status(400).json({
          success: false,
          message: "Latitude and Longitude must be valid numbers",
        });
      }

      if (
        latitude < -90 ||
        latitude > 90 ||
        longitude < -180 ||
        longitude > 180
      ) {
        return res.status(400).json({
          success: false,
          message:
            "Latitude must be between -90 and 90, and longitude must be between -180 and 180",
        });
      }

      updateFields.latitude = latitude;
      updateFields.longitude = longitude;
      updateFields.location = {
        type: "Point",
        coordinates: [longitude, latitude],
      };
    }
    if (googleMapLink) updateFields.googleMapLink = googleMapLink;

    const updatedStore = await Stores.findByIdAndUpdate(id, updateFields, {
      new: true,
    });

    if (!updatedStore) {
      return res.status(404).json({
        success: false,
        message: "Store not found",
      });
    }

    res.status(200).json({
      success: true,
      message: "Store updated successfully",
      data: updatedStore,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message,
    });
  }
};

// Delete store by ID
const deleteStoresById = async (req, res) => {
  try {
    const { id } = req.params;

    const deletedStore = await Stores.findByIdAndDelete(id);

    if (!deletedStore) {
      return res.status(404).json({
        success: false,
        message: "Store not found",
      });
    }

    res.status(200).json({
      success: true,
      message: "Store deleted successfully",
      data: deletedStore,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message,
    });
  }
};

// Get stores with a custom limit
const getStoresName = async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || null;

    const query = Stores.find()
      .sort({ createdAt: -1 })
      .select([
        "name",
        "addressLine1",
        "addressLine2",
        "addressLine3",
        "addressLine4",
        "city",
        "state",
        "postalCode",
      ]);

    if (limit) {
      query.limit(limit);
    }

    const stores = await query;

    res.status(200).json({
      success: true,
      data: stores,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message,
    });
  }
};

// Get a single store by ID
const getStoresById = async (req, res) => {
  const { id } = req.params;

  try {
    const store = await Stores.findById(id);

    if (!store) {
      return res.status(404).json({
        success: false,
        message: "Store not found",
      });
    }

    res.status(200).json({
      success: true,
      data: store,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};


// upload csv - Stores
const uploadCsvFile = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        status: false,
        message: "Please upload a CSV file.",
      });
    }

    const filePath = path.resolve(req.file.path); // Resolve the file path
    const stores = [];

    // Parse the CSV file
    fs.createReadStream(filePath)
      .pipe(csv())
      .on("data", (row) => {
        const latitude = parseFloat(row.latitude);
        const longitude = parseFloat(row.longitude);

        // Validate essential fields
        if (
          row.code &&
          row.postalCode &&
          !isNaN(latitude) &&
          !isNaN(longitude)
        ) {
          stores.push({
            code: row.code,
            name: row.name || "Unknown", // Provide default value if missing
            addressLine1: row.addressLine1 || "",
            addressLine2: row.addressLine2 || "",
            addressLine3: row.addressLine3 || "",
            addressLine4: row.addressLine4 || "",
            city: row.city || "",
            state: row.state || "",
            postalCode: row.postalCode,
            latitude,
            longitude,
            googleMapLink: row.googleMapLink || "",
            location: {
              type: "Point",
              coordinates: [longitude, latitude],
            },
          });
        }
      })
      .on("end", async () => {
        try {
          // Remove duplicates within the CSV
          const uniqueStores = stores.filter(
            (v, i, a) => a.findIndex((t) => t.code === v.code) === i
          );

          let addedRecords = 0;

          for (const store of uniqueStores) {
            // Check if store with the same code exists
            const existingStore = await Stores.findOne({ code: store.code });

            if (!existingStore) {
              // Insert only if the store does not already exist
              await Stores.create(store);
              addedRecords++;
            }
          }

          // Delete the file after processing
          fs.unlinkSync(filePath);

          res.status(200).json({
            status: true,
            message: "CSV file uploaded and processed successfully.",
            totalRecords: addedRecords,
          });
        } catch (err) {
          console.error("Error saving data:", err);
          res.status(500).json({
            status: false,
            message: "An error occurred while saving data.",
            error: err.message,
          });
        }
      })
      .on("error", (error) => {
        console.error("Error reading CSV file:", error);
        res.status(500).json({
          status: false,
          message: "An error occurred while reading the CSV file.",
          error: error.message,
        });
      });
  } catch (error) {
    console.error("Error processing request:", error);
    res.status(500).json({
      status: false,
      message: "An error occurred while processing the CSV file.",
      error: error.message,
    });
  }
};


module.exports = {
  CreateStores,
  getStores,
  getStorebySeach,
  updateStoresById,
  deleteStoresById,
  getStoresName,
  getStoresById,
  uploadCsvFile,
};
