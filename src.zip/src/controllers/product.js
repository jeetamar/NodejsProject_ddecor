const Brand = require("../models/Brand");
const Product = require("../models/Product");
const Shop = require("../models/Shop");
const Collection = require("../models/Collection");
const Category = require("../models/Category");
const SubCategory = require("../models/SubCategory");
const Compaign = require("../models/Compaign");
const _ = require("lodash");
const { multiFilesDelete } = require("../config/uploader");
const blurDataUrl = require("../config/getBlurDataURL");
const { getAdmin, getVendor } = require("../config/getUser");
const { S3Client, DeleteObjectsCommand } = require("@aws-sdk/client-s3");
const s3 = new S3Client({ region: process.env.AWS_REGION });
const mongoose = require('mongoose');

//masters
const Size = require("../models/Sizes");
const Color = require("../models/Color");
const Shape = require("../models/Shape");
const Pattern = require("../models/Pattern");
const Room = require("../models/Room");


const getProducts = async (req, res) => {
  try {
    const query = req.query; // Extract query params from request

    var newQuery = { ...query };
    delete newQuery.page;
    delete newQuery.limit;
    delete newQuery.prices;
    delete newQuery.sizes;
    delete newQuery.colors;
    delete newQuery.name;
    delete newQuery.date;
    delete newQuery.price;
    delete newQuery.top;
    delete newQuery.brand;
    delete newQuery.rate;
    delete newQuery.gender;
    for (const [key, value] of Object.entries(newQuery)) {
      newQuery = { ...newQuery, [key]: value.split("_") };
    }
    const brand = await Brand.findOne({
      slug: query.brand,
    }).select("slug");
    const skip = Number(query.limit) || 12;
    const totalProducts = await Product.countDocuments({
      ...newQuery,
      ...(Boolean(query.brand) && { brand: brand._id }),
      ...(query.sizes && { sizes: { $in: query.sizes.split("_") } }),
      ...(query.colors && { colors: { $in: query.colors.split("_") } }),
      priceSale: {
        $gt: query.prices
          ? Number(query.prices.split("_")[0]) / Number(query.rate || 1)
          : 1,
        $lt: query.prices
          ? Number(query.prices.split("_")[1]) / Number(query.rate || 1)
          : 1000000,
      },
      status: { $ne: "disabled" },
    }).select([""]);

    const minPrice = query.prices
      ? Number(query.prices.split("_")[0]) / Number(query.rate || 1)
      : 1;
    const maxPrice = query.prices
      ? Number(query.prices.split("_")[1]) / Number(query.rate || 1)
      : 10000000;

    const products = await Product.aggregate([
      {
        $lookup: {
          from: "productreviews",
          localField: "reviews",
          foreignField: "_id",
          as: "reviews",
        },
      },
      {
        $addFields: {
          averageRating: { $avg: "$reviews.rating" },
          image: { $arrayElemAt: ["$images", 0] },
        },
      },

      {
        $match: {
          ...(Boolean(query.brand) && {
            brand: brand._id,
          }),

          ...(query.isFeatured && {
            isFeatured: Boolean(query.isFeatured),
          }),

          ...(query.gender && {
            gender: { $in: query.gender.split("_") },
          }),
          ...(query.sizes && {
            sizes: { $in: query.sizes.split("_") },
          }),

          ...(query.colors && {
            colors: { $in: query.colors.split("_") },
          }),
          ...(query.prices && {
            priceSale: {
              $gt: minPrice,
              $lt: maxPrice,
            },
          }),
          status: { $ne: "disabled" },
        },
      },
      {
        $project: {
          image: { url: "$image.url", blurDataURL: "$image.blurDataURL" },
          name: 1,
          available: 1,
          slug: 1,
          colors: 1,
          discount: 1,
          likes: 1,
          priceSale: 1,
          price: 1,
          averageRating: 1,
          vendor: 1,
          shop: 1,
          createdAt: 1,
        },
      },
      {
        $sort: {
          ...((query.date && { createdAt: Number(query.date) }) ||
            (query.price && {
              priceSale: Number(query.price),
            }) ||
            (query.name && { name: Number(query.name) }) ||
            (query.top && { averageRating: Number(query.top) }) || {
              averageRating: -1,
            }),
        },
      },
      {
        $skip: Number(skip * parseInt(query.page ? query.page[0] - 1 : 0)),
      },
      {
        $limit: Number(skip),
      },
    ]);

    res.status(200).json({
      success: true,
      data: products,
      total: totalProducts,
      count: Math.ceil(totalProducts / skip),
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
      error: error.message,
    });
  }
};

const getProductsByCategory = async (req, res) => {
  try {
    const query = req.query; // Extract query params from request

    var newQuery = { ...query };
    delete newQuery.page;
    delete newQuery.limit;
    delete newQuery.prices;
    delete newQuery.sizes;
    delete newQuery.colors;
    delete newQuery.name;
    delete newQuery.date;
    delete newQuery.price;
    delete newQuery.top;
    delete newQuery.brand;
    delete newQuery.gender;
    delete newQuery.rate;
    for (const [key, value] of Object.entries(newQuery)) {
      newQuery = { ...newQuery, [key]: value.split("_") };
    }
    const brand = await Brand.findOne({
      slug: query.brand,
    }).select("slug");
    const category = await Category.findOne({
      slug: req.params.category,
    }).select("slug");

    const skip = Number(query.limit) || 12;
    const totalProducts = await Product.countDocuments({
      ...newQuery,
      ...(Boolean(query.brand) && { brand: brand._id }),
      category: category._id,
      // ...(Boolean(req.params.category) && { category: category._id }),
      ...(query.sizes && { sizes: { $in: query.sizes.split("_") } }),
      ...(query.colors && { colors: { $in: query.colors.split("_") } }),

      priceSale: {
        $gt: query.prices
          ? Number(query.prices.split("_")[0]) / Number(query.rate)
          : 1,
        $lt: query.prices
          ? Number(query.prices.split("_")[1]) / Number(query.rate)
          : 1000000,
      },
      status: { $ne: "disabled" },
    }).select([""]);

    const minPrice = query.prices
      ? Number(query.prices.split("_")[0]) / Number(query.rate)
      : 1;
    const maxPrice = query.prices
      ? Number(query.prices.split("_")[1]) / Number(query.rate)
      : 10000000;

    const products = await Product.aggregate([
      {
        $lookup: {
          from: "productreviews",
          localField: "reviews",
          foreignField: "_id",
          as: "reviews",
        },
      },
      {
        $addFields: {
          averageRating: { $avg: "$reviews.rating" },
          image: { $arrayElemAt: ["$images", 0] },
        },
      },

      {
        $match: {
          category: category._id,
          // ...(Boolean(req.params.category) && {
          //   category: category._id,
          // }),
          ...(Boolean(query.brand) && {
            brand: brand._id,
          }),
          ...(query.isFeatured && {
            isFeatured: Boolean(query.isFeatured),
          }),

          ...(query.gender && {
            gender: { $in: query.gender.split("_") },
          }),
          ...(query.sizes && {
            sizes: { $in: query.sizes.split("_") },
          }),

          ...(query.colors && {
            colors: { $in: query.colors.split("_") },
          }),
          ...(query.prices && {
            priceSale: {
              $gt: minPrice,
              $lt: maxPrice,
            },
          }),
          status: { $ne: "disabled" },
        },
      },
      {
        $project: {
          image: { url: "$image.url", blurDataURL: "$image.blurDataURL" },
          name: 1,
          available: 1,
          slug: 1,
          colors: 1,
          discount: 1,
          likes: 1,
          priceSale: 1,
          available: 1,
          price: 1,
          averageRating: 1,
          vendor: 1,
          shop: 1,
          createdAt: 1,
        },
      },
      {
        $sort: {
          ...((query.date && { createdAt: Number(query.date) }) ||
            (query.price && {
              priceSale: Number(query.price),
            }) ||
            (query.name && { name: Number(query.name) }) ||
            (query.top && { averageRating: Number(query.top) }) || {
              averageRating: -1,
            }),
        },
      },
      {
        $skip: Number(skip * parseInt(query.page ? query.page[0] - 1 : 0)),
      },
      {
        $limit: Number(skip),
      },
    ]);

    res.status(200).json({
      success: true,
      data: products,
      total: totalProducts,
      count: Math.ceil(totalProducts / skip),
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
      error: error.message,
    });
  }
};

const getProductsByCompaign = async (req, res) => {
  try {
    const query = req.query; // Extract query params from request

    var newQuery = { ...query };
    delete newQuery.page;
    delete newQuery.limit;
    delete newQuery.name;
    delete newQuery.date;
    delete newQuery.price;
    delete newQuery.top;
    delete newQuery.rate;
    for (const [key, value] of Object.entries(newQuery)) {
      newQuery = { ...newQuery, [key]: value.split("_") };
    }
    const compaign = await Compaign.findOne({
      slug: req.params.slug,
    });
    const skip = Number(query.limit) || 12;
    const totalProducts = await Product.countDocuments({
      _id: { $in: compaign.products },

      status: { $ne: "disabled" },
    }).select([""]);

    const products = await Product.aggregate([
      {
        $lookup: {
          from: "productreviews",
          localField: "reviews",
          foreignField: "_id",
          as: "reviews",
        },
      },
      {
        $addFields: {
          averageRating: { $avg: "$reviews.rating" },
          image: { $arrayElemAt: ["$images", 0] },
        },
      },

      {
        $match: {
          _id: { $in: compaign.products },
          status: { $ne: "disabled" },
        },
      },
      {
        $project: {
          image: { url: "$image.url", blurDataURL: "$image.blurDataURL" },
          name: 1,
          available: 1,
          slug: 1,
          colors: 1,
          discount: 1,
          likes: 1,
          priceSale: 1,
          available: 1,
          price: 1,
          averageRating: 1,
          vendor: 1,
          shop: 1,
          createdAt: 1,
        },
      },
      {
        $sort: {
          ...((query.date && { createdAt: Number(query.date) }) ||
            (query.price && {
              priceSale: Number(query.price),
            }) ||
            (query.name && { name: Number(query.name) }) ||
            (query.top && { averageRating: Number(query.top) }) || {
              averageRating: -1,
            }),
        },
      },
      {
        $skip: Number(skip * parseInt(query.page ? query.page[0] - 1 : 0)),
      },
      {
        $limit: Number(skip),
      },
    ]);

    res.status(200).json({
      success: true,
      data: products,
      total: totalProducts,
      count: Math.ceil(totalProducts / skip),
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
      error: error.message,
    });
  }
};

const getProductsBySubCategory = async (req, res) => {
  try {
    const query = req.query; // Extract query params from request

    var newQuery = { ...query };
    delete newQuery.page;
    delete newQuery.limit;
    delete newQuery.prices;
    delete newQuery.sizes;
    delete newQuery.colors;
    delete newQuery.name;
    delete newQuery.date;
    delete newQuery.price;
    delete newQuery.top;
    delete newQuery.brand;
    delete newQuery.rate;
    delete newQuery.gender;
    for (const [key, value] of Object.entries(newQuery)) {
      newQuery = { ...newQuery, [key]: value.split("_") };
    }
    const brand = await Brand.findOne({
      slug: query.brand,
    }).select("slug");
    const subCategory = await SubCategory.findOne({
      slug: req.params.subcategory,
    }).select("slug");

    const skip = Number(query.limit) || 12;
    const totalProducts = await Product.countDocuments({
      ...newQuery,
      ...(Boolean(query.brand) && { brand: brand._id }),
      subCategory: subCategory._id,
      // ...(Boolean(req.params.subcategory) && { subCategory: subCategory._id }),
      ...(query.sizes && { sizes: { $in: query.sizes.split("_") } }),
      ...(query.colors && { colors: { $in: query.colors.split("_") } }),

      priceSale: {
        $gt: query.prices
          ? Number(query.prices.split("_")[0]) / Number(query.rate)
          : 1,
        $lt: query.prices
          ? Number(query.prices.split("_")[1]) / Number(query.rate)
          : 1000000,
      },
      status: { $ne: "disabled" },
    }).select([""]);
    const minPrice = query.prices
      ? Number(query.prices.split("_")[0]) / Number(query.rate)
      : 1;
    const maxPrice = query.prices
      ? Number(query.prices.split("_")[1]) / Number(query.rate)
      : 10000000;

    const products = await Product.aggregate([
      {
        $lookup: {
          from: "productreviews",
          localField: "reviews",
          foreignField: "_id",
          as: "reviews",
        },
      },
      {
        $addFields: {
          averageRating: { $avg: "$reviews.rating" },
          image: { $arrayElemAt: ["$images", 0] },
        },
      },

      {
        $match: {
          subCategory: subCategory._id,
          // ...(Boolean(req.params.subcategory) && {
          //   subCategory: subCategory._id,
          // }),
          ...(Boolean(query.brand) && {
            brand: brand._id,
          }),
          ...(query.isFeatured && {
            isFeatured: Boolean(query.isFeatured),
          }),

          ...(query.gender && {
            gender: { $in: query.gender.split("_") },
          }),
          ...(query.sizes && {
            sizes: { $in: query.sizes.split("_") },
          }),

          ...(query.colors && {
            colors: { $in: query.colors.split("_") },
          }),
          ...(query.prices && {
            priceSale: {
              $gt: minPrice,
              $lt: maxPrice,
            },
          }),
          status: { $ne: "disabled" },
        },
      },
      {
        $project: {
          image: { url: "$image.url", blurDataURL: "$image.blurDataURL" },
          name: 1,
          slug: 1,
          colors: 1,
          discount: 1,
          likes: 1,
          priceSale: 1,
          price: 1,
          available: 1,
          averageRating: 1,
          vendor: 1,
          shop: 1,
          createdAt: 1,
        },
      },
      {
        $sort: {
          ...((query.date && { createdAt: Number(query.date) }) ||
            (query.price && {
              priceSale: Number(query.price),
            }) ||
            (query.name && { name: Number(query.name) }) ||
            (query.top && { averageRating: Number(query.top) }) || {
              averageRating: -1,
            }),
        },
      },
      {
        $skip: Number(skip * parseInt(query.page ? query.page[0] - 1 : 0)),
      },
      {
        $limit: Number(skip),
      },
    ]);

    res.status(200).json({
      success: true,
      data: products,
      total: totalProducts,
      count: Math.ceil(totalProducts / skip),
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
      error: error.message,
    });
  }
};

const getProductsByShop = async (req, res) => {
  try {
    const query = req.query; // Extract query params from request

    var newQuery = { ...query };
    delete newQuery.page;
    delete newQuery.limit;
    delete newQuery.prices;
    delete newQuery.sizes;
    delete newQuery.colors;
    delete newQuery.name;
    delete newQuery.date;
    delete newQuery.price;
    delete newQuery.top;
    delete newQuery.brand;
    delete newQuery.rate;
    delete newQuery.gender;

    for (const [key, value] of Object.entries(newQuery)) {
      newQuery = { ...newQuery, [key]: value.split("_") };
    }
    const brand = await Brand.findOne({
      slug: query.brand,
    }).select("slug");
    const shop = await Shop.findOne({
      slug: req.params.shop,
    }).select("slug");

    const skip = Number(query.limit) || 12;
    const totalProducts = await Product.countDocuments({
      ...newQuery,
      shop: shop._id,
      ...(Boolean(query.brand) && { brand: brand._id }),
      ...(query.sizes && { sizes: { $in: query.sizes.split("_") } }),
      ...(query.colors && { colors: { $in: query.colors.split("_") } }),

      priceSale: {
        $gt: query.prices
          ? Number(query.prices.split("_")[0]) / Number(query.rate)
          : 1,
        $lt: query.prices
          ? Number(query.prices.split("_")[1]) / Number(query.rate)
          : 1000000,
      },
      status: { $ne: "disabled" },
    }).select([""]);

    const minPrice = query.prices
      ? Number(query.prices.split("_")[0]) / Number(query.rate)
      : 1;
    const maxPrice = query.prices
      ? Number(query.prices.split("_")[1]) / Number(query.rate)
      : 10000000;

    const products = await Product.aggregate([
      {
        $lookup: {
          from: "productreviews",
          localField: "reviews",
          foreignField: "_id",
          as: "reviews",
        },
      },
      {
        $addFields: {
          averageRating: { $avg: "$reviews.rating" },
          image: { $arrayElemAt: ["$images", 0] },
        },
      },

      {
        $match: {
          shop: shop._id,
          ...(Boolean(query.brand) && {
            brand: brand._id,
          }),

          ...(query.isFeatured && {
            isFeatured: Boolean(query.isFeatured),
          }),

          ...(query.gender && {
            gender: { $in: query.gender.split("_") },
          }),
          ...(query.sizes && {
            sizes: { $in: query.sizes.split("_") },
          }),

          ...(query.colors && {
            colors: { $in: query.colors.split("_") },
          }),
          ...(query.prices && {
            priceSale: {
              $gt: minPrice,
              $lt: maxPrice,
            },
          }),
          status: { $ne: "disabled" },
        },
      },
      {
        $project: {
          image: { url: "$image.url", blurDataURL: "$image.blurDataURL" },
          name: 1,
          slug: 1,
          colors: 1,
          discount: 1,
          likes: 1,
          priceSale: 1,
          price: 1,
          averageRating: 1,
          vendor: 1,
          available: 1,
          shop: 1,
          createdAt: 1,
        },
      },
      {
        $sort: {
          ...((query.date && { createdAt: Number(query.date) }) ||
            (query.price && {
              priceSale: Number(query.price),
            }) ||
            (query.name && { name: Number(query.name) }) ||
            (query.top && { averageRating: Number(query.top) }) || {
              averageRating: -1,
            }),
        },
      },
      {
        $skip: Number(skip * parseInt(query.page ? query.page[0] - 1 : 0)),
      },
      {
        $limit: Number(skip),
      },
    ]);

    res.status(200).json({
      success: true,
      data: products,
      total: totalProducts,
      count: Math.ceil(totalProducts / skip),
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
      error: error.message,
    });
  }
};

const getFilters = async (req, res) => {
  try {
    const totalProducts = await Product.find({
      status: { $ne: "disabled" },
    }).select(["colors", "sizes", "gender", "price"]);
    const Shops = await Shop.find({
      status: { $ne: "disabled" },
    }).select(["title"]);
    const brands = await Brand.find({
      status: { $ne: "disabled" },
    }).select(["name", "slug"]);
    const total = totalProducts.map((item) => item.gender);
    const totalGender = total.filter((item) => item !== "");
    function onlyUnique(value, index, array) {
      return array.indexOf(value) === index;
    }
    const mappedColors = totalProducts?.map((v) => v.colors);
    const mappedSizes = totalProducts?.map((v) => v.sizes);
    const mappedPrices = totalProducts?.map((v) => v.price);
    const min = mappedPrices[0] ? Math.min(...mappedPrices) : 0;
    const max = mappedPrices[0] ? Math.max(...mappedPrices) : 100000;
    const response = {
      colors: _.union(...mappedColors),
      sizes: _.union(...mappedSizes),
      prices: [min, max],
      genders: totalGender.filter(onlyUnique),
      brands: brands,
      Shops: Shops,
    };
    res.status(200).json({ success: true, data: response });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
      error: error.message,
    });
  }
};

const getProductsByAdmin = async (request, response) => {
  try {
    const {
      page: pageQuery,
      limit: limitQuery,
      search: searchQuery,
      shop,
      category,
      brand,
    } = request.query;

    const limit = parseInt(limitQuery) || 10;
    const page = parseInt(pageQuery) || 1;

    // Calculate skip correctly
    const skip = limit * (page - 1);

    let matchQuery = {};

    if (shop) {
      const currentShop = await Shop.findOne({
        slug: shop,
      }).select(["slug", "_id"]);

      matchQuery.shop = currentShop._id;
    }
    if (category) {
      const currentCategory = await Category.findOne({
        slug: category,
      }).select(["slug", "_id"]);

      matchQuery.category = currentCategory._id;
    }
    if (brand) {
      const currentBrand = await Brand.findOne({
        slug: brand,
      }).select(["slug", "_id"]);

      matchQuery.brand = currentBrand._id;
    }

    const totalProducts = await Product.countDocuments({
      name: { $regex: searchQuery || "", $options: "i" },
      ...matchQuery,
    });

    const products = await Product.aggregate([
      {
        $match: {
          ...matchQuery,
        },
      },
      {
        $sort: {
          createdAt: -1,
        },
      },
      {
        $skip: skip,
      },
      {
        $limit: limit,
      },
      {
        $lookup: {
          from: "productreviews",
          localField: "reviews",
          foreignField: "_id",
          as: "reviews",
        },
      },
      {
        $addFields: {
          averageRating: { $avg: "$reviews.rating" },
          image: { $arrayElemAt: ["$images", 0] },
        },
      },

      {
        $project: {
          image: { url: "$image.url", blurDataURL: "$image.blurDataURL" },
          name: 1,
          slug: 1,
          colors: 1,
          discount: 1,
          likes: 1,
          priceSale: 1,
          price: 1,
          averageRating: 1,
          vendor: 1,
          shop: 1,
          available: 1,
          createdAt: 1,
        },
      },
    ]);

    response.status(200).json({
      success: true,
      data: products,
      total: totalProducts,
      count: Math.ceil(totalProducts / limit),
      currentPage: page,
    });
  } catch (error) {
    response.status(400).json({ success: false, message: error.message });
  }
};

// Get Featured Products
const getFeaturedProductByAdmin = async (request, response) => {
  try {
    const {
      page: pageQuery,
      limit: limitQuery,
      search: searchQuery,
    } = request.query;

    const limit = parseInt(limitQuery) || 10;
    const page = parseInt(pageQuery) || 1;

    // Calculate skip correctly
    const skip = limit * (page - 1);

    // Match query to find featured products
    const matchQuery = { isFeatured: true };

    if (searchQuery) {
      matchQuery.name = { $regex: searchQuery, $options: "i" };
    }

    const totalProducts = await Product.countDocuments(matchQuery);

    const products = await Product.aggregate([
      {
        $match: matchQuery,
      },
      {
        $sort: {
          createdAt: -1,
        },
      },
      {
        $skip: skip,
      },
      {
        $limit: limit,
      },
      {
        $lookup: {
          from: "productreviews",
          localField: "reviews",
          foreignField: "_id",
          as: "reviews",
        },
      },
      {
        $addFields: {
          averageRating: { $avg: "$reviews.rating" },
          image: { $arrayElemAt: ["$images", 0] },
        },
      },
      {
        $project: {
          image: { url: "$image.url", blurDataURL: "$image.blurDataURL" },
          name: 1,
          slug: 1,
          colors: 1,
          discount: 1,
          likes: 1,
          priceSale: 1,
          price: 1,
          averageRating: 1,
          vendor: 1,
          shop: 1,
          available: 1,
          createdAt: 1,
        },
      },
    ]);

    response.status(200).json({
      success: true,
      data: products,
      total: totalProducts,
      count: Math.ceil(totalProducts / limit),
      currentPage: page,
    });
  } catch (error) {
    response.status(400).json({ success: false, message: error.message });
  }
};

/*const createProductByAdmin = async (req, res) => {
  try {
    const admin = await getAdmin(req, res);

    const { images, ...body } = req.body;

    // const updatedImages = await Promise.all(
    //   images.map(async (image) => {
    //     const blurDataURL = await blurDataUrl(image.url);
    //     return { ...image, blurDataURL };
    //   })
    // );
    const data = await Product.create({
      vendor: admin._id,
      ...body,
      images: images,
      likes: 0,
    });
    await Shop.findByIdAndUpdate(req.body.shop, {
      $addToSet: {
        products: data._id,
      },
    });
    res.status(201).json({
      success: true,
      message: "Product Created",
      data: data,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};*/

/*const createProductByAdmin = async (req, res) => {
  try {
    const admin = await getAdmin(req, res);

    const { images, ...body } = req.body;

    // const updatedImages = await Promise.all(
    //   images.map(async (image) => {
    //     const blurDataURL = await blurDataUrl(image.url);
    //     return { ...image, blurDataURL };
    //   })
    // );
    const data = await Product.create({
      vendor: admin._id,
      ...body,
      images: images,
      likes: 0,
    });
    await Collection.findByIdAndUpdate(req.body.collection, {
      $addToSet: {
        products: data._id,
      },
    });
    res.status(201).json({
      success: true,
      message: "Product Created",
      data: data,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};*/


// new code - 8_11_24
const createProductByAdmin = async (req, res) => {
  try {
    const admin = await getAdmin(req, res);

    const { images, similarProductIds,
      similarColorProductIds, ...body } = req.body;

    
    const data = await Product.create({
    //   vendor: admin._id,
      ...body,
      images: images,
      similarProductIds,
      similarColorProductIds,
      likes: 0,
    });
    await Collection.findByIdAndUpdate(req.body.collection, {
      $addToSet: {
        products: data._id,
      },
    });
    
    
     // Handle similarProductIds if provided
    if (similarProductIds && similarProductIds.length > 0) {
      await Promise.all(
        similarProductIds.map(async (productId) => {
          const similarProduct = await Product.findById(productId);
          if (
            similarProduct &&
            !similarProduct.similarProductIds.includes(data._id)
          ) {
            // Add the new product ID to the similarProductIds of the similar product
            similarProduct.similarProductIds.push(data._id);
            await similarProduct.save();
            // console.log(
            //   `Added new product ID to similarProductIds of product ${productId}`
            // );
          }
        })
      );
    } else {
      // If similarProductIds is not provided or is empty, simply proceed without adding to other products
    //   console.log(
    //     "No similarProductIds provided. No updates to other products."
    //   );
    }

    // Handle similarColorProductIds if provided
    if (similarColorProductIds && similarColorProductIds.length > 0) {
      await Promise.all(
        similarColorProductIds.map(async (productId) => {
          const similarColorProduct = await Product.findById(productId);
          if (
            similarColorProduct &&
            !similarColorProduct.similarColorProductIds.includes(data._id)
          ) {
            // Add the new product ID to the similarColorProductIds of the similar color product
            similarColorProduct.similarColorProductIds.push(data._id);
            await similarColorProduct.save();
            // console.log(
            //   `Added new product ID to similarColorProductIds of product ${productId}`
            // );
          }
        })
      );
    } else {
      // If similarColorProductIds is not provided or is empty, simply proceed without adding to other products
    //   console.log(
    //     "No similarColorProductIds provided. No updates to other products."
    //   );
    }
    
    
    
    res.status(201).json({
      success: true,
      message: "Product Created",
      data: data,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// 18-11-24
// const createProductByAdmin = async (req, res) => {
//   try {
//     const admin = await getAdmin(req, res); // Fetch the admin user (if needed)

//     // Destructure the request body and extract the images, similar product ids, etc.
//     const { images, similarProductIds = [], similarColorProductIds = [], category, collection, ...body } = req.body;

//     // Convert category, collection, similarProductIds, similarColorProductIds to ObjectId if needed
//     const categoryId = mongoose.Types.ObjectId(category); // Convert to ObjectId
//     const collectionId = mongoose.Types.ObjectId(collection); // Convert to ObjectId

//     // Convert similar product and color product IDs to ObjectId array
//     const similarProductObjectIds = similarProductIds.map(id => mongoose.Types.ObjectId(id));
//     const similarColorProductObjectIds = similarColorProductIds.map(id => mongoose.Types.ObjectId(id));

//     // Create the new product (MongoDB will auto-generate _id)
//     const data = await Product.create({
//       // vendor: admin._id, // Uncomment if vendor association is required
//       ...body, // Rest of the fields from request body
//       images: images || [], // Ensure images are an empty array if not provided
//       similarProductIds: similarProductObjectIds, // Use the ObjectId array
//       similarColorProductIds: similarColorProductObjectIds, // Use the ObjectId array
//       category: categoryId, // Store the category ObjectId
//       collection: collectionId, // Store the collection ObjectId
//       likes: 0, // Initialize likes to 0
//     });

//     // Add the newly created product to the collection (ensure no duplicates)
//     await Collection.findByIdAndUpdate(collectionId, {
//       $addToSet: {
//         products: data._id, // Add the new product _id to the collection's product list
//       },
//     });

//     // Update similarProductIds in existing products if provided
//     if (similarProductObjectIds.length > 0) {
//       await Promise.all(
//         similarProductObjectIds.map(async (productId) => {
//           const similarProduct = await Product.findById(productId);
//           if (similarProduct && !similarProduct.similarProductIds.includes(data._id)) {
//             // Add the new product to the similarProductIds of existing similar product
//             similarProduct.similarProductIds.push(data._id);
//             await similarProduct.save();
//           }
//         })
//       );
//     }

//     // Update similarColorProductIds in existing products if provided
//     if (similarColorProductObjectIds.length > 0) {
//       await Promise.all(
//         similarColorProductObjectIds.map(async (productId) => {
//           const similarColorProduct = await Product.findById(productId);
//           if (similarColorProduct && !similarColorProduct.similarColorProductIds.includes(data._id)) {
//             // Add the new product to the similarColorProductIds of existing similar color product
//             similarColorProduct.similarColorProductIds.push(data._id);
//             await similarColorProduct.save();
//           }
//         })
//       );
//     }

//     // Respond with the created product
//     res.status(201).json({
//       success: true,
//       message: "Product Created Successfully",
//       data, // Return the created product data
//     });
//   } catch (error) {
//     console.error("Error creating product:", error); // Log error for debugging
//     res.status(400).json({ success: false, message: error.message });
//   }
// };

/*const getOneProductByAdmin = async (req, res) => {
  try {
    const product = await Product.findOne({ slug: req.params.slug });
    const category = await Category.findById(product.category).select([
      "name",
      "slug",
    ]);
    const brand = await Brand.findById(product.brand).select("name");

    const getProductRatingAndProductReviews = () => {
      return Product.aggregate([
        {
          $match: { slug: req.params.slug },
        },
        {
          $lookup: {
            from: "productreviews",
            localField: "_id",
            foreignField: "reviews",
            as: "reviews",
          },
        },
        {
          $project: {
            _id: 1,
            name: 1,
            rating: { $avg: "$reviews.rating" },
            totalProductReviews: { $size: "$reviews" },
          },
        },
      ]);
    };

    const reviewReport = await getProductRatingAndProductReviews();
    return res.status(201).json({
      success: true,
      data: product,
      totalRating: reviewReport[0]?.rating,
      totalProductReviews: reviewReport[0]?.totalProductReviews,
      brand: brand,
      category: category,
    });
  } catch (error) {
    return res.status(400).json({ success: false, error: error.message });
  }
};*/


const getOneProductByAdmin = async (req, res) => {
  try {
    const product = await Product.findOne({ slug: req.params.slug });
    if (!product) {
      return res
        .status(404)
        .json({ success: false, message: "Product not found" });
    }

    const category = await Category.findById(product.category);
    

    const colors = await Color.find({ slug: { $in: product.colors } });
    const sizesToFetch = product.sizes.map((item) => item.size);
    const sizesdata = await Size.find({ slug: { $in: sizesToFetch } });

    const sizeMap = sizesdata.reduce((acc, size) => {
      acc[size.slug] = size;
      return acc;
    }, {});


    const sizes = product.sizes
      .map((item) => {
        const sizeInfo = sizeMap[item.size];
        return sizeInfo
          ? {
              _id: sizeInfo._id,
              name: sizeInfo.name,
              slug: item.size,
              price: item.price,
            }
          : null; // Return null if sizeInfo doesn't exist
      })
      .filter(Boolean);

    const rooms = await Room.find({ slug: { $in: product.rooms } });
    const patterns = await Pattern.find({ slug: { $in: product.patterns } });
    const shapes = await Shape.find({ slug: { $in: product.shapes } });

    const getProductRatingAndReviews = async () => {
      const productReviewData = await Product.aggregate([
        {
          $match: { slug: req.params.slug },
        },
        {
          $lookup: {
            from: "productreviews",
            localField: "reviews",
            foreignField: "_id",
            as: "reviews",
          },
        },
        {
          $project: {
            totalReviews: { $size: "$reviews" },
            averageRating: { $avg: "$reviews.rating" },
          },
        },
      ]);
      return productReviewData[0];
    };

    const reviewReport = await getProductRatingAndReviews();
    const { similarProductIds, similarColorProductIds } = product;

    // const similarProducts = await Product.find({
    //   _id: { $in: similarProductIds },
    // }).select("id name ");
    // const similarColorProducts = await Product.find({
    //   _id: { $in: similarColorProductIds },
    // }).select("id name ");
    
    const similarProducts = await Product.find({
      code: { $in: similarProductIds },
    }).select("id name ");
    const similarColorProducts = await Product.find({
      code: { $in: similarColorProductIds },
    }).select("id name ");

    return res.status(200).json({
      success: true,
      data: {
        ...product.toObject(),
        
        colors,
        sizes,
        shapes,
        patterns,
        rooms,
        totalReviews: reviewReport.totalReviews,
        totalRating: reviewReport.averageRating || 0,
        category,
        similarProducts,
        similarColorProducts,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};




/*const updateProductByAdmin = async (req, res) => {
  console.log("update");
  try {
    const admin = await getAdmin(req, res);
    const { slug } = req.params;
    const { images, ...body } = req.body;

    const updatedImages = await Promise.all(
      images.map(async (image) => {
        const blurDataURL = await blurDataUrl(image.url);
        return { ...image, blurDataURL };
      })
    );

    const updated = await Product.findOneAndUpdate(
      { slug: slug, vendor: admin._id },
      {
        ...body,
        images: updatedImages,
      },
      { new: true, runValidators: true }
    );

    return res.status(201).json({
      success: true,
      data: updated,
      message: "Product Updated",
    });
  } catch (error) {
    return res.status(400).json({ success: false, error: error.message });
  }
};*/

//added new code 5 sep 24
/*const updateProductByAdmin = async (req, res) => {
  console.log("update");
  try {
    const admin = await getAdmin(req, res);
    const { slug } = req.params;
    const { images, ...body } = req.body;

    if (!slug || !admin._id) {
      return res
        .status(400)
        .json({ success: false, error: "Missing parameters" });
    }

    // const updatedImages = await Promise.all(
    //   images.map(async (image) => {
    //     const blurDataURL = await blurDataUrl(image.url);
    //     return { ...image, blurDataURL };
    //   })
    // );

    // console.log("Admin ID:", admin._id);
    // console.log("Slug:", slug);
    // console.log("Body:", body);

    const updated = await Product.findOneAndUpdate(
      { slug: slug },
      {
        ...body,
        images: images,
      },
      { new: true, runValidators: true }
    );

    if (!updated) {
      console.log("No product found with the given slug and vendor ID.");
      return res
        .status(404)
        .json({ success: false, message: "Product not found" });
    }

    return res.status(200).json({
      success: true,
      data: updated,
      message: "Product Updated",
    });
  } catch (error) {
    console.error("Error updating product:", error);
    return res.status(400).json({ success: false, error: error.message });
  }
};*/


const updateProductByAdmin = async (req, res) => {
//   console.log("update");
  try {
    const admin = await getAdmin(req, res);
    const { slug } = req.params;
    const { images,similarProductIds,
      similarColorProductIds, ...body } = req.body;

    if (!slug || !admin._id) {
      return res
        .status(200)
        .json({ success: false, error: "Missing parameters" });
    }

   

    const updated = await Product.findOneAndUpdate(
      { slug: slug },
      {
        ...body,
        images: images,
         similarProductIds,
        similarColorProductIds,
      },
      { new: true, runValidators: true }
    );

    if (!updated) {
      console.log("No product found with the given slug and vendor ID.");
      return res
        .status(200)
        .json({ success: false, message: "Product not found" });
    }

    
    
    // If similarProductIds is provided, update the corresponding products
    if (similarProductIds && similarProductIds.length > 0) {
      await Promise.all(
        similarProductIds.map(async (productId) => {
          const similarProduct = await Product.findById(productId);
          if (
            similarProduct &&
            !similarProduct.similarProductIds.includes(updated._id)
          ) {
            // Add the updated product's ID to the similarProductIds array of the other products
            similarProduct.similarProductIds.push(updated._id);
            await similarProduct.save();
            console.log(
              `Added updated product ID to similarProductIds of product ${productId}`
            );
          }
        })
      );
    } else {
      // If similarProductIds is not provided or is empty, add the updated product ID to existing products that already have similar products
      const productsWithSimilarIds = await Product.find({
        similarProductIds: { $exists: true, $ne: [] },
      });
      for (const product of productsWithSimilarIds) {
        if (!product.similarProductIds.includes(updated._id)) {
          product.similarProductIds.push(updated._id);
          await product.save();
          console.log(
            `Added updated product ID to similarProductIds of product ${product._id}`
          );
        }
      }
    }

    // If similarColorProductIds is provided, update the corresponding products
    if (similarColorProductIds && similarColorProductIds.length > 0) {
      await Promise.all(
        similarColorProductIds.map(async (productId) => {
          const similarColorProduct = await Product.findById(productId);
          if (
            similarColorProduct &&
            !similarColorProduct.similarColorProductIds.includes(updated._id)
          ) {
            // Add the updated product's ID to the similarColorProductIds array of the other products
            similarColorProduct.similarColorProductIds.push(updated._id);
            await similarColorProduct.save();
            console.log(
              `Added updated product ID to similarColorProductIds of product ${productId}`
            );
          }
        })
      );
    } else {
      // If similarColorProductIds is not provided or is empty, add the updated product ID to existing products with similar color products
      const productsWithColorSimilarIds = await Product.find({
        similarColorProductIds: { $exists: true, $ne: [] },
      });
      for (const product of productsWithColorSimilarIds) {
        if (!product.similarColorProductIds.includes(updated._id)) {
          product.similarColorProductIds.push(updated._id);
          await product.save();
          console.log(
            `Added updated product ID to similarColorProductIds of product ${product._id}`
          );
        }
      }
    }
    


    return res.status(200).json({
      success: true,
      data: updated,
      message: "Product Updated",
    });
  } catch (error) {
    console.error("Error updating product:", error);
    return res.status(400).json({ success: false, error: error.message });
  }
};








/*async function deletedProductByAdmin(req, res) {
  console.log("deleted");
  try {
    const slug = req.params.slug;
    const product = await Product.findOne({ slug: slug });
    if (!product) {
      return res.status(404).json({
        success: false,
        message: "Product Not Found",
      });
    }
    // const length = product?.images?.length || 0;
    // for (let i = 0; i < length; i++) {
    //   await multiFilesDelete(product?.images[i]);
    // }
    if (product && product.images && product.images.length > 0) {
      await multiFilesDelete(product.images);
    }
    const deleteProduct = await Product.deleteOne({ slug: slug });
    if (!deleteProduct) {
      return res.status(400).json({
        success: false,
        message: "Product Deletion Failed",
      });
    }
    await Shop.findByIdAndUpdate(req.body.shop, {
      $pull: {
        products: product._id,
      },
    });
    return res.status(200).json({
      success: true,
      message: "Product Deleted ",
    });
  } catch (error) {
    return res.status(400).json({ success: false, message: error.message });
  }
}*/




// Update Similar Products or Similar Products By Color
/*const updateSimilarProducts = async (req, res) => {
  try {
    // Admin verify
    const admin = await getAdmin(req, res);
    const slug = req.params.slug; // Slug from URL
    const { similarProductIds, similarColorProductIds, type } = req.body; // IDs and type from request body

    // Parameter validation
    if (!slug || !admin?._id || !type) {
      return res
        .status(400)
        .json({ success: false, error: "Missing parameters" });
    }

    // Product find by slug
    const product = await Product.findOne({ slug });

    // if product not found
    if (!product) {
      console.log("No product found with the given slug.");
      return res
        .status(404)
        .json({ success: false, message: "Product not found" });
    }

    // Prepare update data based on type
    const updateData = {};
    if (type === "color" && similarColorProductIds) {
      updateData.similarColorProductIds = similarColorProductIds;
      console.log("Updating similarColorProductIds:", similarColorProductIds);
    } else if (similarProductIds) {
      updateData.similarProductIds = similarProductIds;
      console.log("Updating similarProductIds:", similarProductIds);
    }

    // Update the product
    const updatedProduct = await Product.findByIdAndUpdate(
      product._id,
      updateData,
      { new: true, runValidators: true }
    );

    // Success response
    return res.status(200).json({
      success: true,
      data: updatedProduct,
      message: "Product Updated",
    });
  } catch (error) {
    console.error("Error updating product:", error);
    return res.status(400).json({ success: false, error: error.message });
  }
};*/



// new code- 7-11-24
const updateSimilarProducts = async (req, res) => {
  try {
    // Admin verify
    const admin = await getAdmin(req, res);
    const slug = req.params.slug; // Slug from URL
    const { similarProductIds, similarColorProductIds, type } = req.body; // IDs and type from request body

    // Parameter validation
    if (!slug || !admin?._id || !type) {
      return res
        .status(400)
        .json({ success: false, error: "Missing parameters" });
    }

    // Find the product by slug (Product A)
    const product = await Product.findOne({ slug });

    // If product not found
    if (!product) {
      console.log("No product found with the given slug.");
      return res
        .status(404)
        .json({ success: false, message: "Product not found" });
    }

    // Prepare update data based on type
    const updateData = {};

    if (type === "color" && similarColorProductIds) {
      updateData.similarColorProductIds = similarColorProductIds;
      // console.log("Updating similarColorProductIds:", similarColorProductIds);
    } else if (similarProductIds) {
      updateData.similarProductIds = similarProductIds;
      // console.log("Updating similarProductIds:", similarProductIds);
    }

    // Update the product (Product A)
    const updatedProduct = await Product.findByIdAndUpdate(
      product._id,
      updateData,
      { new: true, runValidators: true }
    );

    // Function to update similar product fields in other products
    const updateSimilarProductsList = async (productIds, key) => {
      for (let similarProductId of productIds) {
        const similarProduct = await Product.findById(similarProductId);

        // If the product exists and it's not the same as Product A
        if (similarProduct && !similarProduct[key].includes(product._id)) {
          // Add Product A's ID to this product's similarProductIds or similarColorProductIds
          similarProduct[key].push(product._id);
          await similarProduct.save();
          // console.log(
          //   `Added Product A's ID to ${key} of product ${similarProductId}`
          // );
        }
      }
    };

    // If we are updating similarProductIds, propagate the update to all products in that list
    if (similarProductIds) {
      await updateSimilarProductsList(similarProductIds, "similarProductIds");
    }

    // If we are updating similarColorProductIds, propagate the update to all products in that list
    if (similarColorProductIds) {
      await updateSimilarProductsList(
        similarColorProductIds,
        "similarColorProductIds"
      );
    }

    // Success response
    return res.status(200).json({
      success: true,
      data: updatedProduct,
      message: "Product and its similar products updated successfully",
    });
  } catch (error) {
    console.error("Error updating product:", error);
    return res.status(400).json({ success: false, error: error.message });
  }
};



// serarch product by admin in admin side
const searchProductsByNameByAdmin = async (req, res) => {
  console.log("Search");
  try {
    const admin = await getAdmin(req, res);
    const { name } = req.query; // Get the search term from query parameters

    // Validate the name parameter
    if (!name || !admin?._id) {
      return res
        .status(400)
        .json({ success: false, error: "Missing search parameter" });
    }

    // Search for products by name (case-insensitive)
    const products = await Product.find({
      name: { $regex: name, $options: "i" },
    });

    // If no products found
    if (products.length === 0) {
      return res
        .status(404)
        .json({ success: false, message: "No products found" });
    }

    // Fetch categories for the found products
    const categoryIds = products.flatMap((product) => product.category); // Get all category IDs
    let categories = [];

    if (categoryIds.length > 0) {
      categories = await Category.find({ _id: { $in: categoryIds } }).select([
        "name",
        "slug",
      ]);
    }

    // Success response
    return res.status(200).json({
      success: true,
      data: products,
      categories: categories,
      message: "Products found",
    });
  } catch (error) {
    console.error("Error searching products:", error);
    return res.status(500).json({ success: false, error: error.message });
  }
};









const deletedProductByAdmin = async (req, res) => {
  try {
    const slug = req.params.slug;

    // Find and delete the product by slug
    const product = await Product.findOneAndDelete({ slug });
    if (!product) {
      return res.status(404).json({
        success: false,
        message: "Product Not Found",
      });
    }

    // Prepare AWS S3 delete parameters
    const deleteParams = {
      Bucket: process.env.AWS_BUCKET_NAME,
      Delete: {
        Objects: product.images.map((image) => ({ Key: image.key })), // Assuming product.images contains S3 keys
      },
    };

    // Attempt to delete images from S3
    try {
      await s3.send(new DeleteObjectsCommand(deleteParams));
    } catch (fileError) {
      console.error("Error deleting files from S3:", fileError);
      // Even if there's an error deleting files from S3, you still want to return success for the product deletion
      return res.status(500).json({
        success: true, // Product was deleted, but some files might have failed to delete
        message: "Product deleted, but failed to delete some images from S3.",
      });
    }

    // Update the shop
    await Shop.findByIdAndUpdate(req.body.shop, {
      $pull: {
        products: product._id,
      },
    });

    // Send success response
    res.status(200).json({
      success: true,
      message: "Product Deleted Successfully",
    });
  } catch (error) {
    console.error("Error deleting product:", error); // More detailed error logging
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};

const getFiltersByCategory = async (req, res) => {
  console.log("filter");
  try {
    const { shop, category } = req.params;
    // Fetch shop data
    const shopData = await Shop.findOne({ slug: shop }).select(["_id"]);
    console.log("Shop Data:", shopData); // Log shop data
    if (!shopData) {
      return res
        .status(404)
        .json({ success: false, message: "Shop Not Found" });
    }

    // Fetch category data
    const categoryData = await Category.findOne({ slug: category }).select([
      "_id",
      "name",
    ]);
    console.log("CategoryData :", categoryData);
    if (!categoryData) {
      return res
        .status(404)
        .json({ success: false, message: "Category Not Found" });
    }
    // Fetch products for the category under the specified shop
    const products = await Product.find({
      status: { $ne: "disabled" },
      category: categoryData._id,
      shop: shopData._id,
    }).select(["colors", "sizes", "gender", "price", "brand"]);

    // Extract unique values for colors, sizes, gender, and prices
    const colors = [
      ...new Set(products.flatMap((product) => product.colors || [])),
    ];
    const sizes = [
      ...new Set(products.flatMap((product) => product.sizes || [])),
    ];
    const genders = [
      ...new Set(products.flatMap((product) => product.gender || [])),
    ];
    const prices = products.flatMap((product) => product.price || []);
    const minPrice = Math.min(...prices, 0); // Calculate min price
    const maxPrice = Math.max(...prices, 100000); // Calculate max price

    // Extract unique brands
    const brands = [...new Set(products.map((product) => product.brand))];

    // Remove any undefined or null values from brands array
    const cleanBrands = brands.filter(Boolean);

    // Query the Brand collection to get additional information for brands
    const brandData = await Brand.find({ _id: { $in: cleanBrands } }).select([
      "_id",
      "slug",
      "name",
    ]);

    // Construct the response object
    const response = {
      colors,
      sizes,
      prices: [minPrice, maxPrice],
      genders,
      brands: brandData,
    };

    res.status(200).json({ success: true, data: response });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};


const getFiltersBySubCategory = async (req, res) => {
  try {
    const { shop, category, subcategory } = req.params;

    // Fetch shop data
    const shopData = await Shop.findOne({ slug: shop }).select(["_id"]);
    if (!shopData) {
      return res
        .status(404)
        .json({ success: false, message: "Shop Not Found" });
    }
    const categoryData = await Category.findOne({ slug: category }).select([
      "_id",
      "name",
    ]);
    if (!categoryData) {
      return res
        .status(404)
        .json({ success: false, message: "Category Not Found" });
    }
    // Fetch subcategory data
    const subcategoryData = await SubCategory.findOne({
      slug: subcategory,
      parentCategory: categoryData._id,
    }).select(["_id"]);
    if (!subcategoryData) {
      return res
        .status(404)
        .json({ success: false, message: "Subcategory Not Found" });
    }

    // Fetch products for the subcategory under the specified shop
    const products = await Product.find({
      status: { $ne: "disabled" },
      subCategory: subcategoryData._id,
      shop: shopData._id,
    }).select(["colors", "sizes", "gender", "price", "brand"]);

    // Extract unique values for colors, sizes, gender, and prices
    const colors = [
      ...new Set(products.flatMap((product) => product.colors || [])),
    ];
    const sizes = [
      ...new Set(products.flatMap((product) => product.sizes || [])),
    ];
    const genders = [
      ...new Set(products.flatMap((product) => product.gender || [])),
    ];
    const prices = products.flatMap((product) => product.price || []);
    const minPrice = Math.min(...prices, 0); // Calculate min price
    const maxPrice = Math.max(...prices, 100000); // Calculate max price

    // Extract unique brands
    const brands = [...new Set(products.map((product) => product.brand))];

    // Query the Brand collection to get additional information for brands
    const brandData = await Brand.find({ _id: { $in: brands } }).select([
      "_id",
      "slug",
      "name",
    ]);

    // Construct the response object
    const response = {
      colors,
      sizes,
      prices: [minPrice, maxPrice],
      genders,
      brands: brandData,
    };

    res.status(200).json({ success: true, data: response });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getFiltersByShop = async (req, res) => {
  try {
    const { shop } = req.params;

    // Query the Shop collection to find the shop data
    const shopData = await Shop.findOne({ slug: shop }).select([
      "title",
      "slug",
    ]);
    if (!shopData) {
      return res
        .status(404)
        .json({ success: false, message: "Shop Not Found" });
    }

    // Query the Product collection to find products related to the shop
    const products = await Product.find({
      status: { $ne: "disabled" },
      shop: shopData._id,
    }).select(["colors", "sizes", "gender", "price", "brand"]);

    // Extract unique values for colors, sizes, gender, and prices
    const colors = [
      ...new Set(products.flatMap((product) => product.colors || [])),
    ];
    const sizes = [
      ...new Set(products.flatMap((product) => product.sizes || [])),
    ];
    const genders = [
      ...new Set(products.flatMap((product) => product.gender || [])),
    ];
    const prices = products.flatMap((product) => product.price || []);
    const minPrice = Math.min(...prices, 0); // Calculate min price
    const maxPrice = Math.max(...prices, 100000); // Calculate max price

    // Extract unique brands
    const brands = [...new Set(products.map((product) => product.brand))];

    // Remove any undefined or null values from brands array
    const cleanBrands = brands.filter(Boolean);

    // Query the Brand collection to get additional information for brands
    const brandData = await Brand.find({ _id: { $in: cleanBrands } }).select([
      "_id",
      "slug",
      "name",
    ]);

    // Construct the response object
    const response = {
      colors,
      sizes,
      prices: [minPrice, maxPrice],
      genders,
      brands: brandData,
    };

    res.status(200).json({ success: true, data: response });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getAllProductSlug = async (req, res) => {
  try {
    const products = await Product.find().select("slug");

    return res.status(200).json({
      success: true,
      data: products,
    });
  } catch (error) {
    return res.status(400).json({ success: false, message: error.message });
  }
};

const relatedProducts = async (req, res) => {
  try {
    const pid = req.params.pid;
    const product = await Product.findById(pid).select("_id category");

    const related = await Product.aggregate([
      {
        $lookup: {
          from: "reviews",
          localField: "reviews",
          foreignField: "_id",
          as: "reviews",
        },
      },
      {
        $addFields: {
          averageRating: { $avg: "$reviews.rating" },
          image: { $arrayElemAt: ["$images", 0] },
        },
      },
      {
        $match: {
          category: product.category,
          _id: { $ne: product._id },
        },
      },
      {
        $limit: 8,
      },
      {
        $project: {
          image: { url: "$image.url", blurDataURL: "$image.blurDataURL" },
          name: 1,
          slug: 1,
          colors: 1,
          discount: 1,
          likes: 1,
          available: 1,
          priceSale: 1,
          price: 1,
          averageRating: 1,
          vendor: 1,
          shop: 1,
          createdAt: 1,
        },
      },
    ]);

    res.status(200).json({ success: true, data: related });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};


// get product details by slug user side -
/*const getOneProductBySlug = async (req, res) => {
  try {
    const product = await Product.findOne({ slug: req.params.slug });
    const category = await Category.findById(product.category);
    // const category = await Category.findById(product.category).select([
    //   "name",
    //   "slug",
    // ]);
    // const brand = await Brand.findById(product.brand).select("name");

    const colors = await Color.find({ slug: { $in: product.colors } });
    const sizes = await Size.find({ slug: { $in: product.sizes } });
    const rooms = await Room.find({ slug: { $in: product.rooms } });
    const patterns = await Pattern.find({ slug: { $in: product.patterns } });
    const shapes = await Shape.find({ slug: { $in: product.shapes } });


    const getProductRatingAndReviews = async () => {
      const product = await Product.aggregate([
        {
          $match: { slug: req.params.slug },
        },
        {
          $lookup: {
            from: "productreviews", // Replace with your actual review model name
            localField: "reviews", // Replace with the field referencing product in reviews
            foreignField: "_id", // Replace with the field referencing product in reviews
            as: "reviews",
          },
        },
        {
          $project: {
            _id: 0, // Exclude unnecessary fields if needed
            totalReviews: { $size: "$reviews" }, // Count total reviews
            averageRating: {
              $avg: "$reviews.rating", // Calculate average rating (optional)
            },
          },
        },
      ]);

      return product[0];
    };

    const reviewReport = await getProductRatingAndReviews();
    return res.status(201).json({
      success: true,
      data: product,
      colors,
      sizes,
      shapes,
      patterns,
      rooms,
      totalReviews: reviewReport.totalReviews,
      totalRating: reviewReport.averageRating || 0,
    //   brand: brand,
      category: category,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};*/

/*const getOneProductBySlug = async (req, res) => {
  try {
    const product = await Product.findOne({ slug: req.params.slug });
    const category = await Category.findById(product.category);

    const colors = await Color.find({ slug: { $in: product.colors } });
    const sizes = await Size.find({ slug: { $in: product.sizes } });
    const rooms = await Room.find({ slug: { $in: product.rooms } });
    const patterns = await Pattern.find({ slug: { $in: product.patterns } });
    const shapes = await Shape.find({ slug: { $in: product.shapes } });

    const getProductRatingAndReviews = async () => {
      const productReviewData = await Product.aggregate([
        {
          $match: { slug: req.params.slug },
        },
        {
          $lookup: {
            from: "productreviews",
            localField: "reviews",
            foreignField: "_id",
            as: "reviews",
          },
        },
        {
          $project: {
            totalReviews: { $size: "$reviews" },
            averageRating: { $avg: "$reviews.rating" },
          },
        },
      ]);
      return productReviewData[0];
    };

    const reviewReport = await getProductRatingAndReviews();


    // Extracting similar product IDs and similar color product IDs
    const { similarProductIds, similarColorProductIds } = product;

    // Fetching details of similar products
    const similarProducts = await Product.find({
      _id: { $in: similarProductIds },
    });

    // Fetching details of similar color products
    const similarColorProducts = await Product.find({
      _id: { $in: similarColorProductIds },
    }).select("name id slug colors images"); // Only select the fields you want


    
    return res.status(200).json({
      success: true,
      data: {
        ...product.toObject(), // Convert product to plain object and spread its properties
        colors, // Nest colors here
        sizes, // Nest sizes here
        shapes, // Nest shapes here
        patterns, // Nest patterns here
        rooms, // Nest rooms here
        totalReviews: reviewReport.totalReviews,
        totalRating: reviewReport.averageRating || 0,
        category,
        similarProducts,
        similarColorProducts,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};*/


const getOneProductBySlug = async (req, res) => {
  try {
    const product = await Product.findOne({ slug: req.params.slug });
    if (!product) {
      return res
        .status(404)
        .json({ success: false, message: "Product not found" });
    }

    const category = await Category.findById(product.category);
    const { size } = req.query;

    // Initialize price with the default price
    let updatedPrice = product.price;

    if (size) {
      const sizes = product.sizes.find((s) => s.size === size);
      // console.log(sizes);
      if (sizes) {
        updatedPrice = sizes.price; // Update price to the size-specific price
      } else {
        return res.status(200).json({
          message: "Size not found, displaying default product info",
          product,
        });
      }
    }

    const colors = await Color.find({ slug: { $in: product.colors } });
    const sizesToFetch = product.sizes.map((item) => item.size);
    const sizesdata = await Size.find({ slug: { $in: sizesToFetch } });

    const sizeMap = sizesdata.reduce((acc, size) => {
      acc[size.slug] = size;
      return acc;
    }, {});

    // const sizes = product.sizes.map((item) => ({
    //   _id: sizeMap[item.size]?._id || null,
    //   name: sizeMap[item.size]?.name || item.size,
    //   slug: item.size,
    //   price: item.price,
    // }));
    const sizes = product.sizes
  .map((item) => {
    const sizeInfo = sizeMap[item.size];
    return sizeInfo ? {
      _id: sizeInfo._id,
      name: sizeInfo.name,
      slug: item.size,
      price: item.price,
    } : null; // Return null if sizeInfo doesn't exist
  })
  .filter(Boolean); 

    const rooms = await Room.find({ slug: { $in: product.rooms } });
    const patterns = await Pattern.find({ slug: { $in: product.patterns } });
    const shapes = await Shape.find({ slug: { $in: product.shapes } });

    const getProductRatingAndReviews = async () => {
      const productReviewData = await Product.aggregate([
        {
          $match: { slug: req.params.slug },
        },
        {
          $lookup: {
            from: "productreviews",
            localField: "reviews",
            foreignField: "_id",
            as: "reviews",
          },
        },
        {
          $project: {
            totalReviews: { $size: "$reviews" },
            averageRating: { $avg: "$reviews.rating" },
          },
        },
      ]);
      return productReviewData[0];
    };

    const reviewReport = await getProductRatingAndReviews();
    const { similarProductIds, similarColorProductIds } = product;

    // const similarProducts = await Product.find({
    //   _id: { $in: similarProductIds },
    // });
    // const similarColorProducts = await Product.find({
    //   _id: { $in: similarColorProductIds },
    // }).select("id name sizes slug colors images");
    
    const similarColorProducts = await Product.find({
      code: { $in: similarColorProductIds },
    }).select("id name sizes slug colors images");






    const sortSizes = (sizes) => {
      return sizes.sort((a, b) => {
        // Normalize the size strings
        const aSize = a.name
          .replace(" ft", "")
          .toLowerCase()
          .replace(/\s+/g, " ")
          .trim();
        const bSize = b.name
          .replace(" ft", "")
          .toLowerCase()
          .replace(/\s+/g, " ")
          .trim();

        const [aWidth, aHeight] = aSize.split(" x ").map(Number);
        const [bWidth, bHeight] = bSize.split(" x ").map(Number);

        // Compare width first, then height
        return aWidth === bWidth ? aHeight - bHeight : aWidth - bWidth;
      });
    };

    const sortedSizes = sortSizes(sizes);
    // const sortedSizes = sizes.length > 0 ? sortSizes(sizes) : [];

    
    


    return res.status(200).json({
      success: true,
      data: {
        ...product.toObject(),
        price: updatedPrice, // Update the price to reflect the size-specific price
        colors,
        sizes:sortedSizes,
        shapes,
        patterns,
        rooms,
        totalReviews: reviewReport.totalReviews,
        totalRating: reviewReport.averageRating || 0,
        category,
        // similarProducts,
        similarColorProducts,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};


const getCompareProducts = async (req, res) => {
  try {
    const fetchedProducts = await Product.find({
      _id: { $in: req.body.products },
    }).select(["_id"]);
    const products = await Product.aggregate([
      {
        $match: {
          _id: { $in: fetchedProducts.map((v) => v._id) },
        },
      },
      {
        $lookup: {
          from: "productreviews", // Replace with your actual review model name
          localField: "reviews", // Replace with the field referencing product in reviews
          foreignField: "_id", // Replace with the field referencing product in reviews
          as: "reviews",
        },
      },
      {
        $lookup: {
          from: "brands", // Replace with your actual review model name
          localField: "brand", // Replace with the field referencing product in reviews
          foreignField: "_id", // Replace with the field referencing product in reviews
          as: "brand",
        },
      },
      {
        $lookup: {
          from: "shops", // Replace with your actual review model name
          localField: "shop", // Replace with the field referencing product in reviews
          foreignField: "_id", // Replace with the field referencing product in reviews
          as: "shop",
        },
      },
      {
        $addFields: {
          averageRating: { $avg: "$reviews.rating" },
          image: { $arrayElemAt: ["$images", 0] },
          brandName: { $arrayElemAt: ["$brand.name", 0] },
          shopName: { $arrayElemAt: ["$shop.title", 0] },
        },
      },
      {
        $project: {
          _id: 1, // Exclude unnecessary fields if needed
          brandName: 1,
          shopName: 1,
          slug: 1,
          available: 1,
          name: 1,
          sizes: 1,
          colors: 1,
          priceSale: 1,
          price: 1,
          image: { url: "$image.url", blurDataURL: "$image.blurDataURL" },
          totalReviews: { $size: "$reviews" }, // Count total reviews
          averageRating: 1,
        },
      },
    ]);
    return res.status(201).json({
      success: true,
      data: products,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Get featured products
/*const getFeaturedProduct = async (req, res) => {
  try {
    const featuredProducts = await Product.find({ isFeatured: true }).sort({
      createdAt: -1,
    });

    res.status(200).json({
      success: true,
      data: featuredProducts,
      count: featuredProducts.length,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};*/

const getFeaturedProduct = async (req, res) => {
  try {
    // Fetch featured products
    const featuredProducts = await Product.find({ isFeatured: true }).sort({
      createdAt: -1,
    });

    // Initialize an array to hold detailed products
    const detailedProducts = await Promise.all(
      featuredProducts.map(async (product) => {
        // Fetch associated colors, sizes, shapes, rooms, and patterns
        const colors =
          (await Color.find({ slug: { $in: product.colors } })) || [];
        // const sizes = (await Size.find({ slug: { $in: product.sizes } })) || [];
        const sizes =
          (await Size.find({
            slug: { $in: product.sizes.map((size) => size.size) },
          })) || [];
        const rooms = (await Room.find({ slug: { $in: product.rooms } })) || [];
        const patterns =
          (await Pattern.find({ slug: { $in: product.patterns } })) || [];
        const shapes =
          (await Shape.find({ slug: { $in: product.shapes } })) || [];

        // Return product with details and associated attributes
        return {
          ...product.toObject(), // Convert to plain object
          colorDetails: colors.length ? colors : [],
          sizeDetails: sizes.length ? sizes : [],
          roomDetails: rooms.length ? rooms : [],
          patternDetails: patterns.length ? patterns : [],
          shapeDetails: shapes.length ? shapes : [],
        };
      })
    );

    res.status(200).json({
      success: true,
      data: detailedProducts,
      count: detailedProducts.length,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};


// Get is Arrival products
/*const getIsArrivalProduct = async (req, res) => {
  try {
    const arrivalProducts = await Product.find({
      isArrival: true,
    }).sort({
      createdAt: -1,
    });

    res.status(200).json({
      success: true,
      data: arrivalProducts,
      count: arrivalProducts.length,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};*/

const getIsArrivalProduct = async (req, res) => {
  try {
    const arrivalProducts = await Product.find({
      isArrival: true,
    }).sort({
      createdAt: -1,
    });

    // Initialize an array to hold detailed products
    const detailedProducts = await Promise.all(
      arrivalProducts.map(async (product) => {
        // Fetch associated colors, sizes, shapes, rooms, and patterns
        const colors =
          (await Color.find({ slug: { $in: product.colors } })) || [];
        // const sizes = (await Size.find({ slug: { $in: product.sizes } })) || [];
        const sizes =
          (await Size.find({
            slug: { $in: product.sizes.map((size) => size.size) },
          })) || [];
        const rooms = (await Room.find({ slug: { $in: product.rooms } })) || [];
        const patterns =
          (await Pattern.find({ slug: { $in: product.patterns } })) || [];
        const shapes =
          (await Shape.find({ slug: { $in: product.shapes } })) || [];

        // Return product with details and associated attributes
        return {
          ...product.toObject(), // Convert to plain object
          colors: colors.length ? colors : [],
          sizes: sizes.length ? sizes : [],
          rooms: rooms.length ? rooms : [],
          patterns: patterns.length ? patterns : [],
          shapes: shapes.length ? shapes : [],
        };
      })
    );

    res.status(200).json({
      success: true,
      data: detailedProducts,
      count: detailedProducts.length,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};


// Get is Best Seller products
/*const getIsBestSellerProduct = async (req, res) => {
  try {
    const bestSellerProducts = await Product.find({
      isBestSeller: true,
    }).sort({
      createdAt: -1,
    });

    res.status(200).json({
      success: true,
      data: bestSellerProducts,
      count: bestSellerProducts.length,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};*/

const getIsBestSellerProduct = async (req, res) => {
  try {
    const bestSellerProducts = await Product.find({
      isBestSeller: true,
    }).sort({
      createdAt: -1,
    });

    // Initialize an array to hold detailed products
    const detailedProducts = await Promise.all(
      bestSellerProducts.map(async (product) => {
        // Fetch associated colors, sizes, shapes, rooms, and patterns
        const colors =
          (await Color.find({ slug: { $in: product.colors } })) || [];
        // const sizes = (await Size.find({ slug: { $in: product.sizes } })) || [];
        const sizes =
          (await Size.find({
            slug: { $in: product.sizes.map((size) => size.size) },
          })) || [];
        const rooms = (await Room.find({ slug: { $in: product.rooms } })) || [];
        const patterns =
          (await Pattern.find({ slug: { $in: product.patterns } })) || [];
        const shapes =
          (await Shape.find({ slug: { $in: product.shapes } })) || [];

        // Return product with details and associated attributes
        return {
          ...product.toObject(), // Convert to plain object
          colors: colors.length ? colors : [],
          sizes: sizes.length ? sizes : [],
          shapes: rooms.length ? rooms : [],
          patterns: patterns.length ? patterns : [],
          rooms: shapes.length ? shapes : [],
        };
      })
    );

    res.status(200).json({
      success: true,
      data: detailedProducts,
      count: detailedProducts.length,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};


const getSimilarProducts = async (req, res) => {
  try {
    const pid = req.params.pid;

    // Find the product by ID and select necessary fields
    const product = await Product.findById(pid).select("_id similarProductIds");

    // If the product is not found, return an empty array
    if (!product) {
      return res.status(200).json({ success: true, data: [] });
    }

    // Get similar product IDs
    const similarProductIds = product.similarProductIds;

    // Find products with the similar product IDs
    // const related = await Product.find({
    //   _id: { $in: similarProductIds },
    // });
    
    const related = await Product.find({
      code: { $in: similarProductIds },
    });
    

    res
      .status(200)
      .json({ success: true, data: related, count: related.length });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};


module.exports = {
  getProducts,
  getProductsByCategory,
  getProductsBySubCategory,
  getProductsByShop,
  getFilters,
  getProductsByAdmin,
  getFeaturedProductByAdmin,
  createProductByAdmin,
  getOneProductByAdmin,
  updateProductByAdmin,
  deletedProductByAdmin,
  getFiltersByCategory,
  getFiltersByShop,
  getAllProductSlug,
  getFiltersBySubCategory,
  relatedProducts,
  getOneProductBySlug,
  getProductsByCompaign,
  getCompareProducts,
  getFeaturedProduct,
  getIsArrivalProduct,
  getIsBestSellerProduct,
  getSimilarProducts,
  updateSimilarProducts,
  searchProductsByNameByAdmin,
};
