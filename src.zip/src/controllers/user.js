const User = require("../models/User");
const Orders = require("../models/Order");
const Size = require("../models/Sizes");

const bcrypt = require("bcrypt");
const { getUser } = require("../config/getUser");

const getOneUser = async (req, res) => {
  try {
    const user = await getUser(req, res);

    return res.status(201).json({
      success: true,
      data: user,
    });
  } catch (error) {
    return res.status(400).json({ success: false, message: error.message });
  }
};

const getUserByAdmin = async (req, res) => {
  try {
    const id = req.params.uid;

    const pageQuery = req.params.page;
    const limitQuery = req.params.limit;

    const limit = parseInt(limitQuery) || 10;
    const page = parseInt(pageQuery) || 1;

    // Calculate skip correctly
    const skip = limit * (page - 1);

    const currentUser = await User.findOne({ _id: id });

    const totalOrders = await Orders.countDocuments({ "user._id": id });

    const orders = await Orders.find({ "user._id": id }, null, {
      skip: skip * (page - 1),
      limit: skip,
    }).sort({ createdAt: -1 });

    if (!currentUser) {
      return res.status(404).json({
        success: false,
        message: "User Not Found",
      });
    }

    return res.status(201).json({
      success: true,
      data: {
        user: currentUser,
        orders,
        count: Math.ceil(totalOrders / limit),
      },
    });
  } catch (error) {
    return res.status(400).json({ success: false, message: error.message });
  }
};


/*const updateUser = async (req, res) => {
  const user = await getUser(req, res);

  const uid = user._id.toString();

  try {
    const data = await req.body;
    const profile = await User.findByIdAndUpdate(
      uid,
      { ...data },
      {
        new: true,
        runValidators: true,
      }
    ).select("-password");

    if (!profile) {
      return res.status(404).json({
        success: false,
        message: "User Not Found",
      });
    }

    return res.status(200).json({
      success: true,
      data: profile,
    });
  } catch (error) {
    return res.status(400).json({ success: false, message: error.message });
  }
};*/


/*const updateUser = async (req, res) => {
  const user = await getUser(req, res);
  const uid = user._id.toString();

  try {
    const data = { ...req.body };

    // Check if the password is present in the update
    if (data.password) {
      // Hash the new password before saving
      const hashedPassword = await bcrypt.hash(data.password, 10);
      data.password = hashedPassword; // Replace plain password with hashed password
    }

    const profile = await User.findByIdAndUpdate(
      uid,
      data,
      {
        new: true,
        runValidators: true,
      }
    ).select("-password");

    if (!profile) {
      return res.status(404).json({
        success: false,
        message: "User Not Found",
      });
    }

    return res.status(200).json({
      success: true,
      data: profile,
    });
  } catch (error) {
    return res.status(400).json({ success: false, message: error.message });
  }
};*/




const updateUser = async (req, res) => {
  const user = await getUser(req, res);

  // Ensure user is retrieved and includes password
  if (!user) {
    return res.status(200).json({
      success: false,
      message: "User not found.",
    });
  }

  const uid = user._id.toString();
  const user_password = await User.findOne({ _id: uid }).select("+password");
//   console.log(user_password);
  try {
    const { old_password, new_password, ...data } = req.body;

    // Check if both old_password and new_password are provided
    if (old_password && new_password) {
      // Verify old password
      const isMatch = await bcrypt.compare(
        old_password,
        user_password.password
      ); // Ensure user.password is defined
      if (!isMatch) {
        return res.status(200).json({
          success: false,
          message: "Old password is incorrect.",
        });
      }

      // Hash new password
      const hashedPassword = await bcrypt.hash(new_password, 10);
      data.password = hashedPassword; // Update with the new hashed password
    } else if (old_password || new_password) {
      return res.status(200).json({
        success: false,
        message: "Both old_password and new_password must be provided.",
      });
    }

    const profile = await User.findByIdAndUpdate(uid, data, {
      new: true,
      runValidators: true,
    }).select("-password");

    if (!profile) {
      return res.status(200).json({
        success: false,
        message: "User Not Found",
      });
    }

    return res.status(200).json({
      success: true,
      data: profile,
    });
  } catch (error) {
    return res.status(400).json({ success: false, message: error.message });
  }
};





const getInvoice = async (req, res) => {
  try {
    const user = await getUser(req, res);
    const { limit = 10, page = 1 } = req.query;

    const skip = parseInt(limit) * (parseInt(page) - 1) || 0;
    const totalOrderCount = await Orders.countDocuments();

    const orders = await Orders.find({ "user.email": user.email }, null, {
      skip: skip,
      limit: parseInt(limit),
    }).sort({
      createdAt: -1,
    });

    return res.status(200).json({
      success: true,
      data: orders,
      count: Math.ceil(totalOrderCount / parseInt(limit)),
    });
  } catch (error) {
    return res.status(400).json({ success: false, message: error.message });
  }
};


// user side invoice 
const getInvoiceByUser = async (req, res) => {
  try {
    const user = await getUser(req, res);
    const { limit = 10, page = 1 } = req.query;

    const skip = parseInt(limit) * (parseInt(page) - 1) || 0;
    const totalOrderCount = await Orders.countDocuments();

    const orders = await Orders.find({ "user.email": user.email }, null, {
      skip: skip,
      limit: parseInt(limit),
    }).sort({
      createdAt: -1,
    });

    // Step 2: Collect all size slugs from the orders
    const sizeSlugs = orders.flatMap((order) =>
      order.items.map((item) => item.size)
    );

    // Step 3: Fetch sizes from the Size model based on collected slugs
    const sizes = (await Size.find({ slug: { $in: sizeSlugs } }).lean()) || [];

    // Create a mapping of size slugs to size names
    const sizeMap = sizes.reduce((acc, size) => {
      acc[size.slug] = size.name; // Assuming `slug` and `name` are the fields in your sizes
      return acc;
    }, {});

    // Update orders to replace size slugs with size names
    const updatedOrders = orders.map((order) => {
      return {
        ...order._doc, // Use _doc to access the plain object
        items: order.items.map((item) => {
          return {
            ...item,
            size: sizeMap[item.size] || item.size, // Replace size slug with name
          };
        }),
      };
    });

    console.log(updatedOrders);
    return res.status(200).json({
      success: true,
      data: updatedOrders,
      count: Math.ceil(totalOrderCount / parseInt(limit)),
    });
  } catch (error) {
    return res.status(400).json({ success: false, message: error.message });
  }
};




const changePassword = async (req, res) => {
  try {
    const user = await getUser(req, res);
    const uid = user._id.toString();
    const { password, newPassword, confirmPassword } = await req.body;

    // Find the user by ID
    const userWithPassword = await User.findById(uid).select("password");

    if (!userWithPassword) {
      return res
        .status(404)
        .json({ success: false, message: "User Not Found" });
    }

    // Check if the old password matches the stored hashed password
    const passwordMatch = await bcrypt.compare(
      password,
      userWithPassword.password
    );

    if (passwordMatch) {
      // Check if the new password and confirm password match
      if (newPassword !== confirmPassword) {
        return res
          .status(400)
          .json({ success: false, message: "New Password Mismatch" });
      }
      if (password === newPassword) {
        return NextResponse.json(
          {
            success: false,
            message: "Please Enter A New Password ",
          },
          { status: 400 }
        );
      }
      // Hash the new password before updating
      const hashedNewPassword = await bcrypt.hash(newPassword, 10);

      // Update the password with the hashed version
      const updatedUser = await User.findByIdAndUpdate(
        uid,
        { password: hashedNewPassword },
        {
          new: true,
          runValidators: true,
        }
      );

      if (!updatedUser) {
        return res
          .status(404)
          .json({ success: false, message: "User Not Found" });
      }

      return res
        .status(201)
        .json({ success: true, message: "Password Changed" });
    } else {
      return res
        .status(400)
        .json({ success: false, message: "Old Password Incorrect" });
    }
  } catch (error) {
    return res.status(400).json({ success: false, message: error.message });
  }
};

module.exports = {
  getOneUser,
  updateUser,
  getInvoice,
  changePassword,
  getUserByAdmin,
  getInvoiceByUser,
};
