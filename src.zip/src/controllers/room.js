const User = require("../models/User");
const Rooms = require("../models/Room.js");

const createRoom = async (req, res) => {
  try {
    const { ...others } = req.body;
    await Rooms.create({
      ...others,
    });

    res.status(201).json({ success: true, message: "Room Created" });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};
const getRooms = async (req, res) => {
  // console.log("Hello");
  try {
    const rooms = await Rooms.find().sort({
      createdAt: -1,
    });

    res.status(201).json({
      success: true,
      data: rooms,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const updateRoomsById = async (req, res) => {
  try {
    const { id } = req.params;
    const { name , slug} = req.body;

    const newRoom = await Rooms.findByIdAndUpdate(
      id,
      { name ,slug},
      { new: true } // This option returns the updated document
    );

    if (!newRoom) {
      return res
        .status(404)
        .json({ success: false, message: "Room not found" });
    }

    res
      .status(200)
      .json({ success: true, message: "Room Updated", data: newRoom });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
};

const deleteRoomsById = async (req, res) => {
  try {
    const { id } = req.params;

    const deletedRoom = await Rooms.findByIdAndDelete(id);

    res.status(201).json({
      success: true,
      message: "Room Deleted Successfully",
      data: deletedRoom,
    });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
};


// get singel room
const getRoomById = async (req, res) => {
  const { id } = req.params; // Extract the ID from the request parameters

  try {
    const room = await Rooms.findById(id); // Find the room by ID

    if (!room) {
      return res
        .status(404)
        .json({ success: false, message: "Room not found" });
    }

    res.status(200).json({ success: true, data: room }); // Return the found room
  } catch (error) {
    res.status(500).json({ success: false, message: error.message }); // Handle errors
  }
};

/*const getRoomsName = async (req, res) => {
  try {
    const rooms = await Rooms.find()
      .sort({
        createdAt: -1,
      })
      .select(["roomName","slug"]);

    res.status(201).json({
      success: true,
      data: rooms,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};*/

const getRoomsName = async (req, res) => {
  try {
    // Get the limit from the query parameters, default to null (no limit)
    const limit = parseInt(req.query.limit) || null;

    const query = Rooms.find().sort({ createdAt: -1 }).select(["name", "slug"]);

    // If a limit is provided, apply it to the query
    if (limit) {
      query.limit(limit);
    }

    const rooms = await query;

    res.status(200).json({
      success: true,
      data: rooms,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};



module.exports = {
  createRoom,
  getRooms,
  updateRoomsById,
  deleteRoomsById,
   getRoomById,
  getRoomsName,
};
