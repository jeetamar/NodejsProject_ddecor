const Logo = require("../models/Logo");
const { DeleteObjectCommand } = require("@aws-sdk/client-s3");
// Initialize S3 client

const s3 = require("../config/s3");

const createLogo = async (req, res) => {
  console.log(req.body);
  try {
    const { cover, ...others } = req.body;

    await Logo.create({
      ...others,
      cover: {
        ...cover,
      },
    });

    res.status(201).json({ success: true, message: "logo Created" });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

const getLogo = async (req, res) => {
  try {
    const { limit = 10, page = 1, search = "" } = req.query;

    const skip = parseInt(limit) || 10;
    const totalLogos = await Logo.find({
      name: { $regex: search, $options: "i" },
    });
    const logos = await Logo.find(
      {
        name: { $regex: search, $options: "i" },
      },
      null,
      {
        skip: skip * (parseInt(page) - 1 || 0),
        limit: skip,
      }
    ).sort({
      createdAt: -1,
    });

    res.status(201).json({
      success: true,
      data: logos,
      count: Math.ceil(totalLogos.length / skip),
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// get logo by slug

const getLogoBySlug = async (req, res) => {
  try {
    const { slug } = req.params;
    const logo = await Logo.findOne({ slug });

    if (!logo) {
      return res.status(400).json({
        success: false,
        message: "Logo Not Found",
      });
    }

    res.status(201).json({ success: true, data: logo });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message,
    });
  }
};

// update logo
const updateLogoBySlug = async (req, res) => {
  try {
    const { slug } = req.params;
    const { cover, ...others } = req.body;

    await Logo.findOneAndUpdate(
      { slug },
      {
        ...others,
        cover: {
          ...cover,
        },
      },
      { new: true, runValidators: true }
    );

    res.status(201).json({ success: true, message: "Logo Updated" });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// delete logo
const deleteLogoBySlug = async (req, res) => {
  try {
    const { slug } = req.params;

    // Find and delete logo by slug
    const logo = await Logo.findOneAndDelete({ slug });

    if (!logo) {
      return res.status(404).json({
        success: false,
        message: "Logo Not Found",
      });
    }

    // Check if the logo has a cover file
    if (logo.cover && logo.cover.key) {
      // Prepare AWS S3 delete parameters
      const deleteParams = {
        Bucket: process.env.AWS_BUCKET_NAME, // Ensure you have your bucket name in environment variables
        Key: logo.cover.key, // Correctly reference the S3 object key
      };

      // Attempt to delete the cover file from S3
      try {
        await s3.send(new DeleteObjectCommand(deleteParams));
      } catch (fileError) {
        console.error("Error deleting cover file from S3:", fileError);
        return res.status(500).json({
          success: false,
          message: "logo deleted, but failed to delete cover file from S3.",
        });
      }
    }

    // Send success response
    res.status(200).json({
      success: true,
      message: "Logo Deleted Successfully",
    });
  } catch (error) {
    console.error("Error deleting logo:", error); // More detailed error logging
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};

const getLogoByAdmin = async (req, res) => {
  try {
    const logos = await logo
      .find()
      .sort({
        createdAt: -1,
      })
      .select(["name", "slug"]);

    res.status(201).json({
      success: true,
      data: logos,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

module.exports = {
  createLogo,
  getLogo,
  getLogoBySlug,
  updateLogoBySlug,
  deleteLogoBySlug,
  getLogoByAdmin,
};
