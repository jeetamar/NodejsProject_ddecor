const express = require("express");
const router = express.Router();
const collection = require("../controllers/collection");

// Import verifyToken function
const verifyToken = require("../config/jwt");

// admin
router.post("/admin/collection", verifyToken, collection.createCollections);
router.get("/admin/collection", verifyToken, collection.getCollections);
router.get(
  "/admin/collection/:slug",
  verifyToken,
  collection.getCollectionsBySlug
);
router.get("/admin/collection-all", verifyToken, collection.getCollections);

router.put(
  "/admin/collection/:slug",
  verifyToken,
  collection.updateCollectionBySlug
);
router.delete(
  "/admin/collection/:slug",
  verifyToken,
  collection.deleteCollectionBySlug
);
router.get("/admin/all-collection", collection.getCollectionByAdmin); // get id name and slug


//user side
router.get("/collections", collection.getCollections);

// get single collection
router.get("/collections/:slug", collection.getCollectionsBySlug);

// get featured collection
router.get("/featured-collection", collection.getFeaturedCollections);



module.exports = router;
