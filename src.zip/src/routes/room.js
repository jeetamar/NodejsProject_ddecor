const express = require("express");
const router = express.Router();
const rooms = require("../controllers/room");

// Import verifyToken function
const verifyToken = require("../config/jwt");

router.post("/admin/rooms", verifyToken, rooms.createRoom);

router.get("/admin/rooms",verifyToken, rooms.getRooms);

router.get("/admin/single-room/:id", verifyToken, rooms.getRoomById);


router.put("/admin/rooms/:id", verifyToken, rooms.updateRoomsById);
router.delete("/admin/rooms/:id", verifyToken, rooms.deleteRoomsById);

//without token  get all room - name
router.get("/admin/all-room", rooms.getRoomsName);

module.exports = router;
