const express = require("express");
const router = express.Router();
const inspiration = require("../controllers/rugs_inspiration");

// Import verifyToken function
const verifyToken = require("../config/jwt");

// admin

router.post(
  "/admin/inspiration",
  verifyToken,
  inspiration.createRugsInspiration
);
router.get("/admin/inspiration", verifyToken, inspiration.getRugsInspiration);
router.get(
  "/admin/inspiration/:slug",
  verifyToken,
  inspiration.getRugsInspirationBySlug
);
router.get(
  "/admin/inspiration-all",
  verifyToken,
  inspiration.getRugsInspiration
);

router.put(
  "/admin/inspiration/:slug",
  verifyToken,
  inspiration.updateRugsInspirationBySlug
);
router.delete(
  "/admin/inspiration/:slug",
  verifyToken,
  inspiration.deleteRugsInspirationBySlug
);

router.get("/admin/all-inspiration", inspiration.getRugsInspirationByAdmin); // get id name and slug

//user side
router.get("/inspiration", inspiration.getRugsInspiration);

module.exports = router;
