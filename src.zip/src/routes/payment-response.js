const express = require("express");
const router = express.Router();
const paymentController = require("../controllers/paymentResponse");
router.post("/transaction", paymentController.payment_response);

router.post("/create-payment", paymentController.createPayment);
router.put("/update-payment", paymentController.updatePayment);

module.exports = router;
