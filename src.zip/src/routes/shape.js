const express = require("express");
const router = express.Router();
const shapes = require("../controllers/shape");

// Import verifyToken function
const verifyToken = require("../config/jwt");

router.post("/admin/shapes", verifyToken, shapes.createShape);

router.get("/admin/shapes",verifyToken, shapes.getShapes);
router.get("/admin/single-shape/:id", verifyToken, shapes.getShapeById);


router.put("/admin/shapes/:id", verifyToken, shapes.updateShapesById);
router.delete("/admin/shapes/:id", verifyToken, shapes.deleteShapesById);

//without token  get all room - name
router.get("/admin/all-shape", shapes.getShapesName);

module.exports = router;
