const express = require("express");
const router = express.Router();
const menus2 = require("../controllers/menu");

// Import verifyToken middleware
const verifyToken = require("../config/jwt");

// Admin Routes
router.post("/admin/menus", verifyToken, menus2.createMenu); // Create a new menu
router.get("/admin/menus", verifyToken, menus2.getMenus); // Get all menus
router.put("/admin/menus/:id", verifyToken, menus2.updateMenuById); // Update menu by ID
router.delete("/admin/menus/:id", verifyToken, menus2.deleteMenuById); // Delete menu by ID

// Add submenu to a specific menu
router.post("/admin/menus/:id/submenus", verifyToken, menus2.addSubmenu); // Updated for plural "submenus"

// User Routes
router.get("/menus", menus2.getMenus); // Get all menus for users

module.exports = router;
