const express = require("express");
const router = express.Router();
const patterns = require("../controllers/pattern");

// Import verifyToken function
const verifyToken = require("../config/jwt");

router.post("/admin/patterns", verifyToken, patterns.createPattern);

router.get("/admin/patterns",verifyToken, patterns.getPatterns);
router.get("/admin/single-pattern/:id", verifyToken, patterns.getPatternById);


router.put("/admin/patterns/:id", verifyToken, patterns.updatePatternsById);
router.delete("/admin/patterns/:id", verifyToken, patterns.deletePatternsById);

//without token  get all pattern - name
router.get("/admin/all-pattern", patterns.getPatternsName);

module.exports = router;
