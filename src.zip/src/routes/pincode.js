const express = require("express");
const router = express.Router();
const pincodeController = require("../controllers/pincodeController.js");
const multer = require("multer");
const fs = require("fs");
const path = require("path");
// Import verifyToken function
const verifyToken = require("../config/jwt");

// Create a new Pincode
router.post("/admin/pincode", pincodeController.createPincode);

// Get all Pincodes
router.get("/pincodes", pincodeController.getAllPincodes);

// Get a single Pincode by ID
router.get("/pincode/:id", pincodeController.getPincodeById);

// Update a Pincode by ID
router.put("/pincode/:id", pincodeController.updatePincode);

// Delete a Pincode by ID
router.delete("/pincode/:id", pincodeController.deletePincode);

//
// Route to check pincode availability
router.post("/check-pincode", pincodeController.checkPincodeAvailability);

// upload csv pincode
// Set up multer for file upload

const uploadPath = path.join(__dirname, "../uploads");
if (!fs.existsSync(uploadPath)) {
  fs.mkdirSync(uploadPath, { recursive: true }); // Ensure uploads directory exists
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadPath); // Save files in the "uploads" directory
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`); // Rename file to prevent conflicts
  },
});

const upload = multer({ storage });

// Define the route
router.post(
  "/upload-csv-pincode",
  upload.single("file"),
  pincodeController.uploadCsvFile
);

module.exports = router;
