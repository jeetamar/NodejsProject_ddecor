const express = require("express");
const router = express.Router();
const stores = require("../controllers/storeLocator");

const multer = require("multer");
const fs = require("fs");
const path = require("path");

// Import verifyToken function
const verifyToken = require("../config/jwt");

router.post("/admin/stores", verifyToken, stores.CreateStores);

router.get("/admin/stores", verifyToken, stores.getStores);
router.get("/admin/stores/:id", verifyToken, stores.getStoresById);

router.put("/admin/stores/:id", verifyToken, stores.updateStoresById);
router.delete("/admin/stores/:id", verifyToken, stores.deleteStoresById);

//without token  get all store - name
router.get("/admin/stores-names", stores.getStoresName);

//user routes
router.get("/stores", stores.getStores);

router.get("/seach-store", stores.getStorebySeach);


// upload csv stores
// Set up multer for file upload

const uploadPath = path.join(__dirname, "../uploads");
if (!fs.existsSync(uploadPath)) {
  fs.mkdirSync(uploadPath, { recursive: true }); // Ensure uploads directory exists
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadPath); // Save files in the "uploads" directory
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`); // Rename file to prevent conflicts
  },
});

const upload = multer({ storage });

// Define the route
router.post("/upload-csv-stores", upload.single("file"), stores.uploadCsvFile);



module.exports = router;
