

/*const express = require("express");
const router = express.Router();
const { uploadCsvPro } = require("../config/multerS3"); // Multer setup for CSV upload
const csv = require("csv-parser"); // CSV parser
const fs = require("fs");
const path = require("path");
const moment = require("moment"); // For timestamps
const axios = require("axios");
const { PutObjectCommand } = require("@aws-sdk/client-s3"); // AWS S3 client
const s3 = require("../config/s3"); // AWS S3 config
const Product = require("../models/Product"); // Product model
const Collection = require("../models/Collection");
const Category = require("../models/Category");

// Helper function to extract image URL headers from normalized headers
function extractImageUrls(normalizedHeaders) {
  return normalizedHeaders.filter((header) => header.includes("image"));
}

// Function to convert Dropbox URL to direct download link
function convertDropboxUrlToDirectLink(dropboxUrl) {
  if (dropboxUrl.includes("dropbox.com")) {
    return dropboxUrl
      .replace("www.dropbox.com", "dl.dropboxusercontent.com")
      .replace("?dl=0", "?dl=1");
  }
  throw new Error("Invalid Dropbox URL");
}

// Function to check if URL is a valid image URL (ends with .jpg, .png, etc.)
function isValidImageUrl(url) {
  const imageExtensions = [
    ".jpg",
    ".jpeg",
    ".png",
    ".gif",
    ".bmp",
    ".tiff",
    ".webp",
  ];
  return imageExtensions.some((ext) => url.endsWith(ext));
}

// Function to download image and upload to AWS S3
async function processImage(url) {
  try {
    // If URL is from Dropbox, convert to direct download link
    let directUrl = url;
    if (url.includes("dropbox.com")) {
      directUrl = convertDropboxUrlToDirectLink(url);
    } else if (!isValidImageUrl(url)) {
      throw new Error("Invalid image URL");
    }

    const response = await axios.get(directUrl, {
      responseType: "arraybuffer",
    });

    const fileName = path.basename(directUrl).split("?")[0];
    const params = {
      Bucket: process.env.AWS_BUCKET_NAME,
      Key: `images/${Date.now()}-${fileName}`,
      Body: Buffer.from(response.data),
      ContentType: response.headers["content-type"],
      ACL: "public-read",
    };

    await s3.send(new PutObjectCommand(params));
    const fileUrl = `https://${process.env.AWS_BUCKET_NAME}.s3.amazonaws.com/${params.Key}`;

    return { fileUrl, fileKey: params.Key };
  } catch (error) {
    console.error("Error downloading/uploading image:", error);
    throw new Error("Error processing the image.");
  }
}

// Function to validate Dropbox URL
function isValidDropboxUrl(url) {
  const regex = /^https:\/\/www\.dropbox\.com\/scl\/fi\//;
  return regex.test(url);
}

// Function to normalize slug (replace spaces with hyphens)
function normalizeSlug(slug) {
  return slug
    ? slug
        .trim()
        .toLowerCase()
        .replace(/\s+/g, "-")
    : ""; // Replace spaces with hyphens
}

// Function to format sizes (e.g., '3 x 5' becomes '3-x-5-ft')
function formatSize(size) {
  if (size) {
    // Replace spaces with hyphens and append '-ft'
    const formattedSize = size.trim().replace(/\s+/g, "-");
    return `${formattedSize}-ft`;
  }
  return size; // Return as is if no size is provided
}

// Function to process CSV file and return updated rows
async function processCsvFile(filePath) {
  const updatedRows = [];
  const csvStream = fs
    .createReadStream(filePath)
    .pipe(csv({ skipEmptyLines: true }));

  const imageHeaders = [];
  csvStream.on("headers", (headers) => {
    const normalizedHeaders = headers.map((header) =>
      header.trim().toLowerCase()
    );
    imageHeaders.push(...extractImageUrls(normalizedHeaders));
  });

  // Fetch existing categories and collections from the database
  let categories, collections;
  try {
    categories = await Category.find().lean();
    collections = await Collection.find().lean();
  } catch (err) {
    console.error("Error fetching categories/collections from DB:", err);
    throw new Error("Error fetching categories/collections from database.");
  }

  // Create a map for faster lookup
  const categoryMap = {};
  categories.forEach((category) => {
    categoryMap[category.name.toLowerCase()] = category._id; // Map by name
    categoryMap[category.slug.toLowerCase()] = category._id; // Map by slug
  });

  const collectionMap = {};
  collections.forEach((collection) => {
    collectionMap[collection.name.toLowerCase()] = collection._id; // Map by name
    collectionMap[collection.slug.toLowerCase()] = collection._id; // Map by slug
  });

  for await (const row of csvStream) {
    const productErrors = []; // Store errors for this product

    // Process images
    const images = [];
    for (let i = 0; i < 5; i++) {
      const imageUrl = row[`images[${i}].url`];
      const imageKey = row[`images[${i}].key`];

      if (imageUrl) {
        const trimmedUrl = imageUrl.trim();
        try {
          if (isValidDropboxUrl(trimmedUrl)) {
            const { fileUrl, fileKey } = await processImage(trimmedUrl);
            images.push({ url: fileUrl, key: fileKey });
          } else if (isValidImageUrl(trimmedUrl)) {
            const { fileUrl, fileKey } = await processImage(trimmedUrl);
            images.push({ url: fileUrl, key: fileKey });
          } else {
            throw new Error("Invalid image URL");
          }
        } catch (error) {
          productErrors.push(
            `Error processing image ${trimmedUrl}: ${error.message}`
          );
        }
      }
    }

    // Process sizes
    const sizes = [];
    for (let i = 0; i < 5; i++) {
      const size = row[`sizes[${i}].size`];
      if (size) {
        const formattedSize = formatSize(size);
        sizes.push({
          size: formattedSize,
          price: row[`sizes[${i}].price`]
            ? parseFloat(row[`sizes[${i}].price`])
            : undefined,
        });
      }
    }

    if (!sizes.length) {
      productErrors.push("Missing size or price");
    }

    // Category and Collection Validation
    const categoriesForProduct = row.category
      ? row.category
          .split(",")
          .map((cat) => {
            const trimmedCat = cat.trim().toLowerCase();
            return categoryMap[trimmedCat] || null; // Store ID or null if not found
          })
          .filter(Boolean)
      : [];

    if (!categoriesForProduct.length) {
      productErrors.push("Category not found or invalid");
    }

    const collectionsForProduct = row.collection
      ? row.collection
          .split(",")
          .map((coll) => {
            const trimmedColl = coll.trim().toLowerCase();
            return collectionMap[trimmedColl] || null; // Store ID or null if not found
          })
          .filter(Boolean)
      : [];

    if (!collectionsForProduct.length) {
      productErrors.push("Collection not found or invalid");
    }

    // Prepare the row for insertion
    if (productErrors.length) {
      updatedRows.push({
        product: row,
        errors: productErrors,
      });
      continue; // Skip this row and move to the next
    }

    const productData = {
      name: row.name,
      code: row.code,
      status: row.status,
      isFeatured: row.isFeatured === "TRUE", // Convert string to boolean
      isArrival: row.isArrival === "TRUE",
      isBestSeller: row.isBestSeller === "TRUE",
      likes: row.likes ? parseInt(row.likes) : 0,
      description: row.description,
      metaTitle: row.metaTitle,
      metaDescription: row.metaDescription,
      EAN: row.EAN,
      slug: normalizeSlug(row.slug), // Normalize the slug
      sku: row.sku,
      price: parseFloat(row.price),
      priceSale: row.priceSale ? parseFloat(row.priceSale) : undefined,
      available: row.available ? parseInt(row.available) : undefined,
      images: images, // Set images array
      sizes: sizes, // Set sizes array
      colors: row.colors ? row.colors.trim().toLowerCase() : "", // Ensure non-null and trimmed
      shapes: row.shapes ? row.shapes.trim().toLowerCase() : "",
      patterns: row.patterns ? row.patterns.trim().toLowerCase() : "",
      rooms: row.rooms ? row.rooms.trim().toLowerCase() : "",
      composition: row.composition,
      technique: row.technique,
      category: categoriesForProduct,
      collection: collectionsForProduct,
      similarProductIds: row.similarProduct
        ? row.similarProduct.split(",").map((id) => id.trim())
        : [],
      similarColorProductIds: row.similarColorProduct
        ? row.similarColorProduct.split(",").map((id) => id.trim())
        : [],
    };

    updatedRows.push({ product: productData });
  }

  return updatedRows;
}

// Main CSV upload route
router.post("/upload-csv", uploadCsvPro.single("csvFile"), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({
      status: false,
      message: "No CSV file uploaded.",
    });
  }

  const filePath = path.join(__dirname, `../uploads/${req.file.filename}`);

  try {
    const updatedRows = await processCsvFile(filePath);

    const successfulInserts = [];
    const errors = [];

    // Process the products with errors or successful insertions
    for (const { product, errors: productErrors } of updatedRows) {
      if (productErrors && productErrors.length) {
        errors.push({
          product,
          errors: productErrors,
        });
      } else {
        try {
          // Check for required fields
          const missingFields = [];
          if (!product.sku) missingFields.push("sku");
          if (!product.name) missingFields.push("name");
          if (!product.price) missingFields.push("price");
          if (!product.images.length) missingFields.push("images");
          if (!product.sizes.length) missingFields.push("sizes");

          if (missingFields.length) {
            errors.push({
              product,
              errors: `Skipping product due to missing fields: ${missingFields.join(
                ", "
              )}`,
            });
            continue;
          }

          await Product.create(product);
          successfulInserts.push(product);
        } catch (error) {
          console.error("Error inserting product:", error);
          errors.push({
            product,
            errors: `Error inserting product: ${error.message}`,
          });
        }
      }
    }

    // Clean up the original uploaded CSV file
    try {
      fs.unlinkSync(filePath);
    } catch (err) {
      console.error("Error deleting original file:", err);
    }

    // Final response logic
    if (successfulInserts.length === 0) {
      // If no products were inserted, show an error
      return res.status(400).json({
        status: false,
        message: "No products were successfully inserted.",
        errors: errors.length > 0 ? errors : ["No valid products to insert."],
      });
    }

    // If there are successful inserts, show success
    res.status(200).json({
      status: true,
      message: "CSV file processed.",
      productsInserted: successfulInserts.length,
      errors: errors.length > 0 ? errors : null,
    });
  } catch (error) {
    console.error("Error processing CSV file:", error);
    res.status(500).json({
      status: false,
      message: `Error processing CSV file: ${error.message}`,
    });
  }
});

module.exports = router;*/


// new code 

const express = require("express");
const router = express.Router();
const { uploadCsvPro } = require("../config/multerS3"); // Multer setup for CSV upload
const csv = require("csv-parser"); // CSV parser
const fs = require("fs");
const path = require("path");
const moment = require("moment"); // For timestamps
const axios = require("axios");
const { PutObjectCommand } = require("@aws-sdk/client-s3"); // AWS S3 client
const s3 = require("../config/s3"); // AWS S3 config
const Product = require("../models/Product"); // Product model
const Collection = require("../models/Collection");
const Category = require("../models/Category");

// Helper function to extract image URL headers from normalized headers
function extractImageUrls(normalizedHeaders) {
  return normalizedHeaders.filter((header) => header.includes("image"));
}

// Function to convert Dropbox URL to direct download link
function convertDropboxUrlToDirectLink(dropboxUrl) {
  if (dropboxUrl.includes("dropbox.com")) {
    return dropboxUrl
      .replace("www.dropbox.com", "dl.dropboxusercontent.com")
      .replace("?dl=0", "?dl=1");
  }
  throw new Error("Invalid Dropbox URL");
}

// Function to check if URL is a valid image URL (ends with .jpg, .png, etc.)
function isValidImageUrl(url) {
  const imageExtensions = [
    ".jpg",
    ".jpeg",
    ".png",
    ".gif",
    ".bmp",
    ".tiff",
    ".webp",
  ];
  return imageExtensions.some((ext) => url.endsWith(ext));
}

// Function to download image and upload to AWS S3
async function processImage(url) {
  try {
    // If URL is from Dropbox, convert to direct download link
    let directUrl = url;
    if (url.includes("dropbox.com")) {
      directUrl = convertDropboxUrlToDirectLink(url);
    } else if (!isValidImageUrl(url)) {
      throw new Error("Invalid image URL");
    }

    const response = await axios.get(directUrl, {
      responseType: "arraybuffer",
    });

    const fileName = path.basename(directUrl).split("?")[0];
    const params = {
      Bucket: process.env.AWS_BUCKET_NAME,
      Key: `images/${Date.now()}-${fileName}`,
      Body: Buffer.from(response.data),
      ContentType: response.headers["content-type"],
      ACL: "public-read",
    };

    await s3.send(new PutObjectCommand(params));
    const fileUrl = `https://${process.env.AWS_BUCKET_NAME}.s3.amazonaws.com/${params.Key}`;

    return { fileUrl, fileKey: params.Key };
  } catch (error) {
    console.error("Error downloading/uploading image:", error);
    throw new Error("Error processing the image.");
  }
}

// Function to validate Dropbox URL
function isValidDropboxUrl(url) {
  const regex = /^https:\/\/www\.dropbox\.com\/scl\/fi\//;
  return regex.test(url);
}

// Function to normalize slug (replace spaces with hyphens)
function normalizeSlug(slug) {
  return slug
    ? slug
        .trim()
        .toLowerCase()
        .replace(/\s+/g, "-")
    : ""; // Replace spaces with hyphens
}

// Function to format sizes (e.g., '3 x 5' becomes '3-x-5-ft')
function formatSize(size) {
  if (size) {
    // Replace spaces with hyphens and append '-ft'
    const formattedSize = size.trim().replace(/\s+/g, "-");
    return `${formattedSize}-ft`;
  }
  return size; // Return as is if no size is provided
}



//new
// Function to process CSV file and return updated rows
// Function to check if an image URL exists (returns true if exists, false if not)
// Function to check if an image URL exists (either locally or on a server)
async function checkImageExists(url) {
  try {
    const response = await axios.head(url);
    return response.status === 200; // Check if the status is OK (200)
  } catch (error) {
    console.error(`Error checking image URL: ${url}`, error);
    return false; // Return false if the URL does not exist or there is an error
  }
}

// Function to process CSV file and return updated rows
async function processCsvFile(filePath) {
  const updatedRows = [];
  const csvStream = fs
    .createReadStream(filePath)
    .pipe(csv({ skipEmptyLines: true }));

  const imageHeaders = [];
  csvStream.on("headers", (headers) => {
    const normalizedHeaders = headers.map((header) =>
      header.trim().toLowerCase()
    );
    imageHeaders.push(...extractImageUrls(normalizedHeaders));
  });

  // Fetch existing categories and collections from the database
  let categories, collections;
  try {
    categories = await Category.find().lean();
    collections = await Collection.find().lean();
  } catch (err) {
    console.error("Error fetching categories/collections from DB:", err);
    throw new Error("Error fetching categories/collections from database.");
  }

  // Create a map for faster lookup
  const categoryMap = {};
  categories.forEach((category) => {
    categoryMap[category.name.toLowerCase()] = category._id; // Map by name
    categoryMap[category.slug.toLowerCase()] = category._id; // Map by slug
  });

  const collectionMap = {};
  collections.forEach((collection) => {
    collectionMap[collection.name.toLowerCase()] = collection._id; // Map by name
    collectionMap[collection.slug.toLowerCase()] = collection._id; // Map by slug
  });

  for await (const row of csvStream) {
    const productErrors = []; // Store errors for this product

    // Process images
    const images = [];
    const invalidImages = []; // Track invalid images
    let validImageFound = false; // Flag to track if a valid image is found

    // Check for all image URLs
    for (let i = 0; i < 5; i++) {
      const imageUrl = row[`images[${i}].url`];
      if (imageUrl) {
        const trimmedUrl = imageUrl.trim();
        try {
          // Check if Dropbox URL is valid
          if (isValidDropboxUrl(trimmedUrl)) {
            const { fileUrl, fileKey } = await processImage(trimmedUrl);
            images.push({ url: fileUrl, key: fileKey });
            validImageFound = true;
          }
          // Check if direct image URL is valid
          else if (isValidImageUrl(trimmedUrl)) {
            // Check if the image URL exists
            const imageExists = await checkImageExists(trimmedUrl);
            if (imageExists) {
              const { fileUrl, fileKey } = await processImage(trimmedUrl);
              images.push({ url: fileUrl, key: fileKey });
              validImageFound = true;
            } else {
              invalidImages.push(trimmedUrl); // Store invalid image URLs
            }
          } else {
            invalidImages.push(trimmedUrl); // Store invalid image URLs
          }
        } catch (error) {
          invalidImages.push(trimmedUrl); // Store invalid image URLs if error occurs
          productErrors.push(
            `Error processing image ${trimmedUrl}: ${error.message}`
          );
        }
      }
    }

    // If no valid images are found, flag an error
    if (!validImageFound) {
      productErrors.push("No valid image URL found.");
    }

    // If there are invalid images, log the specific error
    if (invalidImages.length) {
      productErrors.push(
        `The following image URLs do not exist: ${invalidImages.join(", ")}`
      );
    }

    // Process sizes
    const sizes = [];
    for (let i = 0; i < 5; i++) {
      const size = row[`sizes[${i}].size`];
      if (size) {
        const formattedSize = formatSize(size);
        sizes.push({
          size: formattedSize,
          price: row[`sizes[${i}].price`]
            ? parseFloat(row[`sizes[${i}].price`])
            : undefined,
        });
      }
    }

    if (!sizes.length) {
      productErrors.push("Missing size or price");
    }

    // Category and Collection Validation
    const categoriesForProduct = row.category
      ? row.category
          .split(",")
          .map((cat) => {
            const trimmedCat = cat.trim().toLowerCase();
            return categoryMap[trimmedCat] || null;
          })
          .filter(Boolean)
      : [];

    if (!categoriesForProduct.length) {
      productErrors.push("Category not found or invalid");
    }

    const collectionsForProduct = row.collection
      ? row.collection
          .split(",")
          .map((coll) => {
            const trimmedColl = coll.trim().toLowerCase();
            return collectionMap[trimmedColl] || null;
          })
          .filter(Boolean)
      : [];

    if (!collectionsForProduct.length) {
      productErrors.push("Collection not found or invalid");
    }

    // If no valid images found and invalid images are present, skip product insertion
    if (!validImageFound) {
      updatedRows.push({
        product: row,
        errors: productErrors,
      });
      continue; // Skip this row and move to the next
    }

    // Product data for insertion
    const productData = {
      name: row.name,
      code: row.code,
      status: row.status,
      isFeatured: row.isFeatured === "TRUE",
      isArrival: row.isArrival === "FALSE",
      isBestSeller: row.isBestSeller === "TRUE",
      likes: row.likes ? parseInt(row.likes) : 0,
      description: row.description,
      metaTitle: row.metaTitle,
      metaDescription: row.metaDescription,
      EAN: row.EAN,
      slug: normalizeSlug(row.slug),
      sku: row.sku,
      price: parseFloat(row.price),
      priceSale: row.priceSale ? parseFloat(row.priceSale) : undefined,
      available: row.available ? parseInt(row.available) : undefined,
      images: images, // Insert valid images only
      sizes: sizes, // Insert sizes array
      colors: row.colors ? row.colors.trim().toLowerCase() : "",
      shapes: row.shapes ? row.shapes.trim().toLowerCase() : "",
      patterns: row.patterns ? row.patterns.trim().toLowerCase() : "",
      rooms: row.rooms ? row.rooms.trim().toLowerCase() : "",
      composition: row.composition,
      technique: row.technique,
      category: categoriesForProduct,
      collection: collectionsForProduct,
      similarProductIds: row.similarProduct
        ? row.similarProduct.split(",").map((id) => id.trim())
        : [],
      similarColorProductIds: row.similarColorProduct
        ? row.similarColorProduct.split(",").map((id) => id.trim())
        : [],
    };

    // Push product data to updatedRows
    updatedRows.push({ product: productData });
  }

  return updatedRows;
}

// Main CSV upload route
router.post("/upload-csv", uploadCsvPro.single("csvFile"), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({
      status: false,
      message: "No CSV file uploaded.",
    });
  }

  const filePath = path.join(__dirname, `../uploads/${req.file.filename}`);

  try {
    const updatedRows = await processCsvFile(filePath);

    const successfulInserts = [];
    const errors = [];

    // Process the products with errors or successful insertions
    for (const { product, errors: productErrors } of updatedRows) {
      if (productErrors && productErrors.length) {
        errors.push({
          product,
          errors: productErrors,
        });
      } else {
        try {
          // Check for required fields
          const missingFields = [];
          if (!product.sku) missingFields.push("sku");
          if (!product.name) missingFields.push("name");
          if (!product.price) missingFields.push("price");
          if (!product.images.length) missingFields.push("images");
          if (!product.sizes.length) missingFields.push("sizes");

          if (missingFields.length) {
            errors.push({
              product,
              errors: `Skipping product due to missing fields: ${missingFields.join(
                ", "
              )}`,
            });
            continue;
          }

          await Product.create(product);
          successfulInserts.push(product);
        } catch (error) {
          console.error("Error inserting product:", error);
          errors.push({
            product,
            errors: `Error inserting product: ${error.message}`,
          });
        }
      }
    }

    // Clean up the original uploaded CSV file
    try {
      fs.unlinkSync(filePath);
    } catch (err) {
      console.error("Error deleting original file:", err);
    }

    // Final response logic
    if (successfulInserts.length === 0) {
      // If no products were inserted, show an error
      return res.status(400).json({
        status: false,
        message: "No products were successfully inserted.",
        errors: errors.length > 0 ? errors : ["No valid products to insert."],
      });
    }

    // If there are successful inserts, show success
    res.status(200).json({
      status: true,
      message: "CSV file processed.",
      productsInserted: successfulInserts.length,
      errors: errors.length > 0 ? errors : null,
    });
  } catch (error) {
    console.error("Error processing CSV file:", error);
    res.status(500).json({
      status: false,
      message: `Error processing CSV file: ${error.message}`,
    });
  }
});

module.exports = router;














