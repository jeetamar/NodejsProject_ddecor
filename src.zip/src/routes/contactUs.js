const express = require("express");
const router = express.Router();
const contact = require("../controllers/contactUs.js");

// Import verifyToken function
const verifyToken = require("../config/jwt");

router.post("/contactUs", contact.createContactUs);

router.get("/admin/contactUs", verifyToken, contact.getContactUs);
router.get("/admin/contactUsr/:id", verifyToken, contact.getContactUsById);

router.put("/admin/contactUs/:id", verifyToken, contact.updateContactUsById);
router.delete("/admin/contactUs/:id", verifyToken, contact.deleteContactUsById);

module.exports = router;
