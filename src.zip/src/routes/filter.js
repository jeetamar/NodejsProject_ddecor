// routes/fileRoutes.js
const express = require("express");
const router = express.Router();
const filter = require("../controllers/filter");

// filter product api
router.get("/products-filter/:slug", filter.getFilteredProducts);

module.exports = router;
