const express = require("express");
const router = express.Router();
const logo = require("../controllers/logo_featured");

// Import verifyToken function
const verifyToken = require("../config/jwt");

// admin

router.post("/admin/logo", verifyToken, logo.createLogo);
router.get("/admin/logo", verifyToken, logo.getLogo);
router.get("/admin/logo/:slug", verifyToken, logo.getLogoBySlug);
router.get("/admin/logo-all", verifyToken, logo.getLogo);

router.put("/admin/logo/:slug", verifyToken, logo.updateLogoBySlug);
router.delete("/admin/logo/:slug", verifyToken, logo.deleteLogoBySlug);

router.get("/admin/all-logo", logo.getLogoByAdmin); // get id name and slug

//user side
router.get("/logo", logo.getLogo);

module.exports = router;
