const express = require("express");
const router = express.Router();
const colors = require("../controllers/color.js");

// Import verifyToken function
const verifyToken = require("../config/jwt");

router.post("/admin/colors", verifyToken, colors.createColor);

router.get("/admin/colors",verifyToken, colors.getColors);
router.get("/admin/single-color/:id", verifyToken, colors.getColorById);


router.put("/admin/colors/:id", verifyToken, colors.updateColorById);
router.delete("/admin/colors/:id", verifyToken, colors.deleteColorById);

//without token  get all color - name
router.get("/admin/all-color", colors.getColorsName);


module.exports = router;
