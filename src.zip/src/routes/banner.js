const express = require("express");
const router = express.Router();
const banners = require("../controllers/banner");

// Import verifyToken function
const verifyToken = require("../config/jwt");

router.post("/admin/banner", verifyToken, banners.createBanner);
router.put("/admin/banner/:slug", verifyToken, banners.updateBannerBySlug);
router.delete("/admin/banner/:slug", verifyToken, banners.deleteBannersBySlug);
router.get("/admin/banner", verifyToken, banners.getBanners);
router.get("/admin/banner/:slug", verifyToken, banners.getBannerBySlug);


//user side
router.get("/banner", banners.getBanners);

module.exports = router;
