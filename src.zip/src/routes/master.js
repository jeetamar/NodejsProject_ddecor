const express = require("express");
const router = express.Router();
//master - means - size , color , room , shape and patterns- datas
const msters = require("../controllers/master");

// Import verifyToken function
const verifyToken = require("../config/jwt");

router.get("/masters", msters.getMasterData);

module.exports = router;
