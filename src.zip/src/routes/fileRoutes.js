// routes/fileRoutes.js
const express = require("express");
const router = express.Router();
// const upload = require("../config/multerS3");

const { upload } = require("../config/multerS3"); // Correctly import both

const {
  DeleteObjectCommand,
  DeleteObjectsCommand,
} = require("@aws-sdk/client-s3");
const s3 = require("../config/s3");









// Upload single file
router.post("/upload/single", upload.single("file"), (req, res) => {
  if (!req.file) {
    return res.status(400).send("No file uploaded.");
  }
  res.status(200).json({
    key: req.file.key,
    url: req.file.location,
  });
});

// Upload multiple files
router.post("/upload/multi", upload.array("files", 10), (req, res) => {
  if (!req.files) {
    return res.status(400).send("No files uploaded.");
  }
  const fileData = req.files.map((file) => ({
    key: file.key,
    url: file.location,
  }));
  res.status(200).json(fileData);
});

// Delete single file
router.delete("/delete/single", async (req, res) => {
  const { key } = req.query;
  const deleteParams = {
    Bucket: process.env.AWS_BUCKET_NAME,
    Key: key,
  };
  try {
    await s3.send(new DeleteObjectCommand(deleteParams));
    res.status(200).send("File deleted successfully.");
  } catch (err) {
    res.status(500).send("Error deleting file.");
  }
});

// Delete multiple files
router.delete("/delete/multi", async (req, res) => {
  const { keys } = req.body;
  const deleteParams = {
    Bucket: process.env.AWS_BUCKET_NAME,
    Delete: {
      Objects: keys.map((key) => ({ Key: key })),
    },
  };
  try {
    await s3.send(new DeleteObjectsCommand(deleteParams));
    res.status(200).send("Files deleted successfully.");
  } catch (err) {
    res.status(500).send("Error deleting files.");
  }
});

module.exports = router;
