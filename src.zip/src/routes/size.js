const express = require("express");
const router = express.Router();
const sizes = require("../controllers/size.js");

// Import verifyToken function
const verifyToken = require("../config/jwt");

router.post("/admin/sizes", verifyToken, sizes.createSize);

router.get("/admin/sizes",verifyToken, sizes.getSizes);
router.get("/admin/single-sizes/:id", verifyToken, sizes.getSizeById);

router.put("/admin/sizes/:id", verifyToken, sizes.updateSizeById);
router.delete("/admin/sizes/:id", verifyToken, sizes.deleteSizeById);

//without token  get all size - name
router.get("/admin/all-sizes", sizes.getSizesName);

//user routes
router.get("/sizes", sizes.getSizes);

module.exports = router;
