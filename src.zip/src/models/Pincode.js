// models/Pincode.js

const mongoose = require("mongoose");

const PincodeSchema = new mongoose.Schema(
  {
    pincode: { type: String, required: true, unique: true },
    city: { type: String, required: true },
  },
  {
    timestamps: true,
  }
);

const Pincode =
  mongoose.models.Pincode || mongoose.model("Pincode", PincodeSchema);
module.exports = Pincode;
