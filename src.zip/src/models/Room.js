const mongoose = require("mongoose");

const RoomSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "roomName Hex Code is required."],
    },
    slug: {
      type: String,
      unique: true,
      required: [true, "Slug is required."],
    },
  },
  {
    timestamps: true,
  }
);

const Room = mongoose.models.Room || mongoose.model("Room", RoomSchema);
module.exports = Room;
