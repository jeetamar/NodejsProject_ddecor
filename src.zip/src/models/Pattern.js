const mongoose = require("mongoose");

const PatternSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "patternType is required."],
    },
    slug: {
      type: String,
      unique: true,
      required: [true, "Slug is required."],
    },
  },
  {
    timestamps: true,
  }
);

const Pattern =
  mongoose.models.Pattern || mongoose.model("Pattern", PatternSchema);
module.exports = Pattern;
