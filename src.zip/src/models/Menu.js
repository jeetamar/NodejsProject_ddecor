const mongoose = require("mongoose");


const submenuSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String },
  metaTitle: { type: String },
  metaDescription: { type: String },
  url: { type: String },
  slug: { type: String },
  dataCollection: [
    {
      name: { type: String, required: true },
      metaTitle: { type: String },
      metaDescription: { type: String },
      url: { type: String, required: true },
      slug: { type: String, required: true },
      imageUrl: { type: String },
    },
  ],
});

const menuSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String },
  metaTitle: { type: String },
  metaDescription: { type: String },
  url: { type: String },
  slug: { type: String },
  submenus: [submenuSchema],
});

const Menu = mongoose.models.Menu || mongoose.model("Menu", menuSchema);
module.exports = Menu;
