const mongoose = require("mongoose");

/*const productSchema = new mongoose.Schema(
  {
    name: {
      type: String,
    },
    code: {
      type: String,
    },
    status: {
      type: String,
    },
    isFeatured: {
      type: Boolean,
    },
    brand: {
      type: mongoose.Types.ObjectId,
      ref: "Brand",
    },
    likes: {
      type: Number,
    },
    description: {
      type: String,
    },
    metaTitle: {
      type: String,
    },
    metaDescription: {
      type: String,
    },
    slug: {
      type: String,
      unique: true,
    },
    category: {
      type: mongoose.Types.ObjectId,
      ref: "Category",
      required: [true, "please provide a category id"],
    },
    subCategory: {
      type: mongoose.Types.ObjectId,
      ref: "SubCategory",
      required: [true, "please provide a sub category id"],
    },
    gender: {
      type: String,
    },
    tags: [String],
    sku: {
      type: String,
      required: [true, "SKU is required."],
    },
    price: {
      type: Number,
      required: [true, "Price is required."],
    },
    priceSale: {
      type: Number,
      required: [true, "Sale price is required."],
    },
    oldPriceSale: {
      type: Number,
    },
    available: {
      type: Number,
      required: [true, "Available quantity is required."],
    },
    sold: {
      type: Number,
      default: 0,
    },
    reviews: [
      {
        type: mongoose.Types.ObjectId,
        ref: "ProductReview",
      },
    ],

    shop: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Shop",
      required: true,
    },
    images: [
      {
        url: {
          type: String,
          required: [true],
        },
        key: {
          type: String,
          required: [true],
        },
      },
    ],

    colors: [String],
    sizes: [String],
  },
  { timestamps: true, strict: true }
);*/

const productSchema = new mongoose.Schema(
  {
    // _id: { type: String },
    name: {
      type: String,
    },
    code: {
      type: String,
    },
    status: {
      type: String,
    },
    isFeatured: {
      type: Boolean,
    },
    isArrival: {
      type: Boolean,
    },
    isBestSeller: {
      type: Boolean,
    },
    // brand: {
    //   type: mongoose.Types.ObjectId,
    //   ref: "Brand",
    // },
    likes: {
      type: Number,
    },
    description: {
      type: String,
    },
    metaTitle: {
      type: String,
    },
    metaDescription: {
      type: String,
    },
    EAN: {
      type: String,
    },
    slug: {
      type: String,
      unique: true,
    },
    category: {
      type: mongoose.Types.ObjectId,
      ref: "Category",
      required: [true, "please provide a category id"],
    },
    // subCategory: {
    //   type: mongoose.Types.ObjectId,
    //   ref: "SubCategory",
    //   required: [true, "please provide a sub category id"],
    // },
    // gender: {
    //   type: String,
    // },
    tags: [String],
    sku: {
      type: String,
      required: [false, "SKU is required."],
    },
    price: {
      type: Number,
      required: [true, "Price is required."],
    },
    priceSale: {
      type: Number,
      required: [false, "Sale price is required."],
    },
    oldPriceSale: {
      type: Number,
    },
    available: {
      type: Number,
      required: [false, "Available quantity is required."],
    },
    sold: {
      type: Number,
      default: 0,
    },
    reviews: [
      {
        type: mongoose.Types.ObjectId,
        ref: "ProductReview",
      },
    ],

    collection: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Collection",
      required: true,
    },
    images: [
      {
        url: {
          type: String,
          required: [true],
        },
        key: {
          type: String,
          required: [true],
        },
      },
    ],

    // colors: [String],
    // sizes: [String],
    colors: {
      type: String,
    },
    // sizes: {
    //   type: String,
    // },
    sizes: [
      {
        size: {
          type: String,
          required: true,
        },
        price: {
          type: Number,
          required: true,
        },
       
      },
    ],
    
    shapes: {
      type: String,
    },
    patterns: {
      type: String,
    },
    rooms: {
      type: String,
    },
     composition: {
      type: String,
    },
    technique: {
      type: String,
    },
    similarProductIds: {
      type: [String], // Array of IDs for similar products
      default: [],
    },
    similarColorProductIds: {
      type: [String], // Array of IDs for similar color products
      default: [],
    },
  },
  { timestamps: true, strict: true }
);

const Product =
  mongoose.models.Product || mongoose.model("Product", productSchema);
module.exports = Product;
