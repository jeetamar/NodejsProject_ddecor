const mongoose = require("mongoose");

const InspirationSchema = new mongoose.Schema(
  {
    cover: {
      key: {
        type: String,
        required: [true, "image-key-required-error"],
      },
      url: {
        type: String,
        required: [true, "image-url-required-error"],
      },
    },
    name: {
      type: String,
      required: [true, "Name is required."],
      maxlength: [100, "Name cannot exceed 100 characters."],
    },

    slug: {
      type: String,
      unique: true,
      required: true,
    },
    status: {
      type: Boolean,
      default: true, // Default value
    },
  },
  {
    timestamps: true,
  }
);

const Inspiration =
  mongoose.models.Inspiration ||
  mongoose.model("Inspiration", InspirationSchema);
module.exports = Inspiration;
