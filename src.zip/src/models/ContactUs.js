const mongoose = require("mongoose");

const ContactUsSchema = new mongoose.Schema(
  {
    firstName: {
      type: String,
      required: [false, "First Name is required."],
    },
    lastName: {
      type: String,
      required: [false, "Last Name  is required."],
    },
    email: {
      type: String,
    //   unique: true,
      required: [true, "Email is required."],
    },
    phone: {
      type: String,

      required: [false, "Phone is required."],
    },
    subject: {
      type: String,

      required: [false, "Subject is required."],
    },
    city: {
      type: String,

      required: [false, "City is required."],
    },
    message: {
      type: String,

      required: [false, "Message is required."],
    },
  },
  {
    timestamps: true,
  }
);

const ContactUs =
  mongoose.models.ContactUs || mongoose.model("ContactUs", ContactUsSchema);
module.exports = ContactUs;
