const mongoose = require("mongoose");

const ShapeSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "shapeName is required."],
    },
    slug: {
      type: String,
      unique: true,
      required: [true, "Slug is required."],
    },
  },
  {
    timestamps: true,
  }
);

const Shape = mongoose.models.Shape || mongoose.model("Shape", ShapeSchema);
module.exports = Shape;
