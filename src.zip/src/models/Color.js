const mongoose = require("mongoose");

const ColorSchema = new mongoose.Schema(
  {
    colorHexCode: {
      type: String,
      required: [true, "Color Hex Code is required."],
    },
    name: {
      type: String,
      required: [true, "Color Name  is required."],
    },
    slug: {
      type: String,
      unique: true,
      required: [true, "Slug is required."],
    },
  },
  {
    timestamps: true,
  }
);

const Color = mongoose.models.Color || mongoose.model("Color", ColorSchema);
module.exports = Color;
