const mongoose = require("mongoose");

const SizeSchema = new mongoose.Schema(
  {
    height: {
      type: String,
      required: [false, "Height is required."],
    },
    width: {
      type: String,
      required: [false, "Width  is required."],
    },
    units: {
      type: String,
    },
    slug: {
      type: String,
      unique: true,
      required: [true, "Slug is required."],
    },
    name:{
        type:String,
    },
  },
  {
    timestamps: true,
  }
);

const Size = mongoose.models.Size || mongoose.model("Size", SizeSchema);
module.exports = Size;
