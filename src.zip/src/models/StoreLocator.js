
//

const mongoose = require("mongoose");

const storeLocatorSchema = new mongoose.Schema({
  code: { type: String },
  name: { type: String, required: false },
  addressLine1: { type: String, required: false },
  addressLine2: { type: String, required: false },
  addressLine3: { type: String, required: false },
  addressLine4: { type: String, required: false },
  city: { type: String, required: false },
  state: { type: String, required: false },
  postalCode: { type: String, required: true }, // Postal code is required
  latitude: { type: Number, required: true }, // Latitude is required for GeoJSON location
  longitude: { type: Number, required: true }, // Longitude is required for GeoJSON location
  location: { type: { type: String }, coordinates: [Number] }, // GeoJSON format
  googleMapLink: { type: String }, //
});

// Create a 2dsphere index to support geospatial queries
storeLocatorSchema.index({ location: "2dsphere" });

// Model definition
const StoreLocator =
  mongoose.models.StoreLocator ||
  mongoose.model("StoreLocator", storeLocatorSchema);

module.exports = StoreLocator;
