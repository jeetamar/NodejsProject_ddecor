const mongoose = require("mongoose");

const BannerSchema  = new mongoose.Schema(
  {
    cover: {
      key: {
        type: String,
        required: [true, "image-key-required-error"],
      },
      url: {
        type: String,
        required: [true, "image-url-required-error"],
      },
    },
    title: {
      type: String,
      required: [true, "title is required."],
      maxlength: [100, "title cannot exceed 100 characters."],
    },
    
    description: {
      type: String,
      required: [true, "Description is required."],
      maxlength: [500, "Description cannot exceed 500 characters."],
    },
    
    slug: {
      type: String,
      unique: true,
      required: true,
    },
    buttonText: { type: String, required: true },
    buttonAction: { type: String, required: true } // URL or action
   
    
  },
  {
    timestamps: true,
  }
);

const Banner =
  mongoose.models.Banner || mongoose.model("Banner", BannerSchema );
module.exports = Banner;
