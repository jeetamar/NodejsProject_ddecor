const mongoose = require("mongoose");

const paymentSchema = new mongoose.Schema(
  {
    // order: {
    //   type: mongoose.Schema.Types.ObjectId,
    //   ref: "Order", // Reference to a single Order model
    //   required: true, // Make this field required
    // },
    orderNo: {
      type: String,
      required: true,
    },
    total: {
      type: Number,
      required: true,
    },
    referenceNo: {
      type: String, // Reference number from payment gateway
    },
    paymentMethod: {
      type: String, // Payment method (e.g. credit card, PayPal, etc.)
    },

    status: {
      type: String,
      enum: ["processing", "paid", "hold", "failed"],
      default: "processing",
    },
    paidAt: {
      type: Date,
    },

    date: {
      type: Date,
      default: Date.now,
    },
  },
  {
    timestamps: true, // This will automatically add createdAt and updatedAt fields
  }
);

paymentSchema.pre("save", function(next) {
  // Set the paidAt date when the status changes to 'paid'
  if (this.status === "paid" && !this.paidAt) {
    this.paidAt = new Date();
  }
  next();
});

const PaymentModel = mongoose.model("PaymentModel", paymentSchema);

module.exports = PaymentModel;
