const mongoose = require("mongoose");

const LogoSchema = new mongoose.Schema(
  {
    cover: {
      key: {
        type: String,
        required: [true, "image-key-required-error"],
      },
      url: {
        type: String,
        required: [true, "image-url-required-error"],
      },
    },
    name: {
      type: String,
      required: [true, "Name is required."],
      maxlength: [100, "Name cannot exceed 100 characters."],
    },

    slug: {
      type: String,
      unique: true,
      required: true,
    },
    status: {
      type: Boolean,
      default: true, // Default value
    },
  },
  {
    timestamps: true,
  }
);

const Logo = mongoose.models.Logo || mongoose.model("Logo", LogoSchema);
module.exports = Logo;
